module Seeding
  class Simulator
    #! Eventually turn this into a real daily rake routine
    def self.prep(company_id)
      Customer.by_company(company_id).each do |customer|
        # Prep **********************
        ## Cart: Make an appointment to pickup items from customer (Pickup)
        ## (optional)
        plan = customer.product.plans.first
        cart = [{"action": "new_plan", "quantity": 5, "request_type": "packed", "transit_type": "pickup", "plan_id": plan.id}]
        pickup_appointments = []
        5.times do
          appointment = FactoryGirl.create(:appointment, customer: customer, address_id: customer.last_appointment_address_id)
          appointment.process_cart(cart.as_json, customer.user_id, customer.product.company_id)
          pickup_appointments << appointment
        end
        pickup_appointments.each do |aptmt|
          AppointmentCutoff.move_appointment_to_confirmed(aptmt.id)
        end
        ## Cart: Make an appointment to retrieve items back from storage for that customer (Delivery)
        cart = []
        ### Must be for customer_items that are already :in_storage (will be null first time around)
        inventories = Inventory.by_company(company_id)
        customer_items = customer.subscriptions.first.customer_items.select do |ci|
          inventories.map(&:sku).include?(ci.barcode)
        end
        customer_items.each do |ci|
          cart << {
            "customer_item_id": ci.id,
            "request_type": "packed",
            "transit_type": "delivery",
            "action": "update_customer_item"
          }
        end
        unless cart.empty?
          appointment = FactoryGirl.create(:appointment, customer: customer, address_id: customer.last_appointment_address_id)
          appointment.process_cart(cart.as_json, customer.user_id, customer.product.company_id)
          ## Force confirmation of appointment (will autocreate warehouse_tasks, payloads, and route)
          AppointmentCutoff.move_appointment_to_confirmed(appointment.id)
        end
      end
    end

    def self.run_routes(company_id, datetime = nil)
      puts "datetime #{datetime}"
      # Run ops: Iterate through each route
      routes = Route.by_company(company_id).where('status = ? OR status = ?', Route.statuses[:draft], Route.statuses[:confirmed])
      puts "routes #{routes.map(&:datetime_range)}"
      if datetime
        routes = routes.select do |route|
          if route.datetime_range.dig(:start)
            puts "in dig"
            route.datetime_range[:start] >= datetime &&
                route.datetime_range[:end] <= (datetime + 24.hours)
          end
        end
      end
      puts "further refined routes #{routes.inspect}"
      routes.each do |route|
        ## Confirm route (update status to confirmed)
        route.status = :confirmed if route.status == 'draft'
        route.save!
        ### Picking flow ========
        ### Move all requested customer_items (inventories) to staging
        inventories = []
        WarehouseTask.by_route(route.id).each do |wt|
          inventories << {
            warehouse_task_id: wt.id,
            sku: wt.sku,
            quantity: 1
          }
        end
        staging_location_id = route.company.warehouses.first.locations
          .where(location_type: Location.location_types[:staging]).first.id
        inventories_moved_to_staging = Inventory.mass_transfer(inventories,
        staging_location_id, route.company_id) #! Don't quite trust the inventory.mass_transfer method yet
        ## Start route (update status to outbound) (assumes van loaded)
        route.status = :outbound; route.save!
        ## Iterate through each appointment
        route.appointments.each do |aptmt|
          ## Start appointment (update status to started)
          aptmt.status = :started; aptmt.save!
          aptmt.appointment_details.each do |ad|
            ## Pickup items (mass assign barcodes to each payload item)
            ad.payloads.each do |payload|
              if ad.transit_type == 'pickup'
                payload.sku = rand(100000..999999); payload.save!
                puts "payload *** #{payload.inspect}"
              end
            end
            ## Deliver items (nothing needs to be done)
          end
          ## Confirmation of appointment (add signature file) (update status to completed)
          aptmt.approved_signature_url = File.open(Rails.root.join('spec', 'factories', 'signature.png'))
          aptmt.status = :completed
          aptmt.save!
        end
        ## Return to warehouse (update status to inbound)
        route.status = :inbound; route.save!
        ## Unload van (create inventory records for each payload)
        payloads = []
        route.appointments.each do |aptmt|
          aptmt.appointment_details.where(transit_type: AppointmentDetail.transit_types[:pickup]).each do |ad|
            if ad.transit_type == 'pickup'
              payloads += ad.payloads
            end
          end
        end
        inventories = []
        payloads.each do |payload|
          #Create inventory record and assign it to only staging location
          inventories << Inventory.create!(
            location_id: staging_location_id, #assuming 1 staging location per company,
            inventory_type: :customer_item,
            inventory_name: payload.name,
            sku: payload.sku, #The barcode ID
            quantity: 1, #assuming no empty containers
            created_by: 1,
            modified_by: 1
          )
        end
        ## Complete route (update status to completed)
        route.status = :completed; route.save!
        # Receiving flow ==========
        ## Iterate through each of the inventories currently in staging
        permanent_location = Location.by_company(company_id).where(location_type: Location.location_types[:permanent]).first
        inventories.map!{|inventory| {sku: inventory.sku, quantity: inventory.quantity}}
          inventories_moved_to_storage = Inventory.mass_transfer(inventories, permanent_location.id, route.company_id)
      end
    end
  end
end
