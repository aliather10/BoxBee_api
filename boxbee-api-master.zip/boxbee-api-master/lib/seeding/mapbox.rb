module Seeding
  class Mapbox
    def self.generate_addresses(zip) #!!! Add in country to args
      geo_grid(10, 10) do
        latlong_from_zip(zip)
      end
    end

    def self.generate_zips(city, state, country)
      addresses = geo_grid(20, 15) do
        latlong_from_city(city, state, country)
      end
      zips = addresses.map{|addr| addr[:zip_code]}.uniq
      zips.delete nil
      puts zips
      return zips
    end

    def self.geo_grid(grid_width, resolution)
      center = yield
      puts center
      puts differential = latlong_differential_for_1km(center[1])
      #Generate a random grid X km to a side, to start generating addresses
      #grid_width km
      #resolution number of points in the given width
      addresses = []
      #Iterate through random possible addresses in the 5km box
      for x in 1..resolution
        for y in 1..resolution
          puts "long"
          puts long = center[0] + rand(-resolution..resolution) * (1.0/resolution) * 0.5 * grid_width * differential[0]
          puts "lat"
          puts lat = center[1] + rand(-resolution..resolution) * (1.0/resolution) * 0.5 * grid_width * differential[1]

          addresses << address_reverse_geocode([long, lat])
        end
      end
      return addresses
    end

    def self.latlong_from_city(city, state, country)
      city.gsub!(" ","+")
      state = find_state_abbrev(state)
      country.gsub!(" ","+")
      response = HTTParty.get("#{Figaro.env.MAPBOX_GEOCODING_API_BASE_PATH}/mapbox.places/#{city}+#{state}+#{country}.json",
      :query => {
        "type" => "postcode",
        "access_token" => Figaro.env.MAPBOX_ACCESS_TOKEN
      }
      )
      JSON.parse(response)['features'].first['center']
    end

    private
    def self.latlong_from_zip(zip)
      response = HTTParty.get("#{Figaro.env.MAPBOX_GEOCODING_API_BASE_PATH}/mapbox.places/#{zip}.json",
        :query => {
          "type" => "postcode",
          "access_token" => Figaro.env.MAPBOX_ACCESS_TOKEN
        }
      )
      JSON.parse(response)['features'].first['center']
    end

    def self.latlong_differential_for_1km(latitude)
      #Approximate differentials
      #Latitude: 1 deg = 110.574 km
      latitude_diff = 0.009043717329571148
      #Longitude: 1 deg = 111.320*cos(latitude) km
      longitude_diff = 1 / (111.32 * Math.cos(latitude))
      return [longitude_diff, latitude_diff]
    end

    def self.address_reverse_geocode(latlong)
      response = HTTParty.get("#{Figaro.env.MAPBOX_GEOCODING_API_BASE_PATH}/mapbox.places/#{latlong[0]},#{latlong[1]}.json",
        :query => {
          "type" => "address",
          "access_token" => Figaro.env.MAPBOX_ACCESS_TOKEN
        }
      )
      address = JSON.parse(response)['features'].first
      hproc = Proc.new {|context, context_type| context['id'].include? context_type}
      address_obj = {
        address1: "#{address['address']} #{address['text']}",
        city: geo_context(address, hproc, 'place.'),
        state_name: geo_context(address, hproc, 'region.'),
        zip_code: geo_context(address, hproc, 'postcode.'),
        country_name: geo_context(address, hproc, 'country.'),
        latitude: latlong[1],
        longitude: latlong[0]
      }
    end

    def self.zip_reverse_geocode(latlong)
      #Returns a zip code based on lat/long coordinates
      response = HTTParty.get("#{Figaro.env.MAPBOX_GEOCODING_API_BASE_PATH}/mapbox.places/#{latlong[0]},#{latlong[1]}.json",
        :query => {
          "type" => "postcode",
          "access_token" => Figaro.env.MAPBOX_ACCESS_TOKEN
        }
      )
      address = JSON.parse(response)['features'].first
      hproc = Proc.new {|context, context_type| context['id'].include? context_type}
      return geo_context(address, hproc, 'postcode.')
    end

    def self.geo_context(address, hproc, context_type)
      context_selector = address['context'].select{|context| hproc.call(context, context_type)}
      unless context_selector.empty?
        context_selector.first['text']
      end
    end

    def self.find_state_abbrev(full_state_name)
      state = Seeding::STATES.select{|state| state.include?(full_state_name)}.first[0]
    end
  end
end
