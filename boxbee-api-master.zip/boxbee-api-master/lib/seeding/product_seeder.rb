module Seeding
  class ProductSeeder
    def self.draft(company_id)
      company = Company.find(company_id)
      Product.new(
        company: company,
        name: "My Storage",
        description: "Full Service Storage",
        status: :draft,
        meta_tags: "on demand storage, full service storage",
        theme: "yellow",
        hero_text: "Fast, easy full-service storage.  We pick up and store your stuff and deliver it back to you when you need it.",
        description_text: "It just takes a few minutes.",
        what_we_store: "We’ll store the things you don’t need at home all the time.",
        how_it_works1: "",
        how_it_works2: "",
        how_it_works3: "",
        our_plans: "Pickup is free.  Deliveries are $20.",
        closing_cta: "Start Packing",
        terms_title: "Terms and Conditions",
        terms_body: "(Fill this in)",
        faq_title: "Frequently Asked Questions",
        support_phone: "888-888-8888",
        support_email: "support@#{company.name.parameterize}.com",
        twitter_url: "http://twitter.com",
        facebook_url: "http://facebook.com",
        instagram_url: "http://instagram.com",
        pinterest_url: "http://pinterest.com",
        yelp_url: "http://yelp.com",
        currency: 'usd',
        created_by: 1,
        modified_by: 1
      )
    end

    def self.static_content(product_id)
      5.times do
        Faq.create!(
          product_id: product_id,
          question: Faker::Lorem.sentence,
          answer: Faker::Lorem.sentence
        )
      end
    end
  end
end
