module Reports
  class Revenues
    def self.start(start_date, end_date, company_id, requester_id)
      #Fetch balance transactions
      balance_transactions = BalanceTransaction.by_company(company_id)
      bt_in_date_range = BalanceTransaction
        .by_date(balance_transactions, start_date, end_date)
      #Run generator routine to output csv file
      report = generator(start_date, end_date, company_id, bt_in_date_range, requester_id)
      #Send email with csv_file as attachment
      CompanyMailer.revenue_report(requester_id, report.csv_file, start_date, end_date, company_id).deliver_now
      #Fetch user from UMS
    end

    def self.generator(start_date, end_date, company_id, balance_transactions, user_id)
      #get all array that took place between start and end dates
      revenues_hash = iterate_balance_transactions(balance_transactions, start_date, end_date, company_id)
      #Generate CSV file and store it in /tmp
      csv_file = create_csv(revenues_hash, start_date, end_date, company_id)
      report = Report.new(
          company_id: company_id,
          report_type: :revenue,
          name: "Revenue Report for #{Company.find(company_id).name}, #{Time.at(start_date.to_i).utc.to_date.to_s} to #{Time.at(end_date.to_i).utc.to_date.to_s}",
          created_by: user_id,
          modified_by: user_id
      )
      puts "report #{report.inspect}"
      puts "csv file #{csv_file.inspect}"
      report.csv_file = File.open(csv_file)
      puts "report csv #{report.csv_file}"
      report.save!
      return report
    end
    def self.charge_routine(balance_transaction, company_id)
      #find and store all of the charges to array with paid:true status
      charge = Charge.by_company(company_id)
        .select{|charge| charge['id'] == balance_transaction['source']}.first
      #locate the corresp. invoice item and corresp. invoice
      invoice = Invoice.by_company(company_id)
        .select{|inv| inv['id'] == charge['invoice']}.first
      invoice_lines = invoice['lines']['data']
      invoice_lines.each do |ii|
        obj = {}
        #determine accounting code from invoice item meta data
        obj[:product_id] = ii['metadata']['product_id']
        obj[:accounting_code] = ii['metadata']['accounting_code']
        #>determine discount and store it in array (by accounting code)
        #will only apply to line items where invoice_item_discountable="true" #check nightly routine to see if these were set to true
        if ii['discountable'] == true
          unless invoice['discount'].nil?
            #if a discount is present on the invoice and consists of a coupon_percent_off:
            if invoice['discount']['coupon']['percent_off']
              #>determine discount by invoice_item_amount*coupon_percent_off
              obj[:discount] = ii['amount'] * invoice['discount']['coupon']['percent_off']
              #if a discount is present on the invoice and consists of an coupon_amount_off
            elsif invoice['discount']['coupon']['amount_off']
              #>determine discount by: invoice_item_amount/(sum of invoice_item_amount where invoice_item_discountable = true)* coupon_amount_off
              sum_discountable_invoice_lines = invoice_lines.select {|il| il['discountable'] == true}
                .map {|dil| dil['amount']}.sum
                #ARE TAXES CALCULATED PRE OR POST DISCOUNT?
              obj[:discount] = ii['amount'] * invoice['discount']['coupon']['amount_off'] / sum_discountable_invoice_lines
            else
              obj[:discount] = 0
            end
          else
            obj[:discount] = 0
          end
        end
        #>determine the tax and store it in array (by accounting code)
        #tax is determined by: invoice_item_amount * invoice_tax / invoice_subtotal
        invoice['tax'] ? obj[:tax] = ii['amount'] * invoice['tax'] / invoice['subtotal'] : obj[:tax] = 0
        #>determine revenue contribution via invoice_item_amount and store to array (by accounting code)
        obj[:revenue] = ii['amount']
        #>determine stripe fee contribution and store it in array (by accounting code)
        obj[:stripe_fee_contrib] = balance_transaction['fee_details'].select {|fd| fd['type']=='stripe_fee'}.map {|fds| fds['amount']}.sum * ii['amount'] / invoice['subtotal']
        obj[:refund] = 0
        return obj
      end
    end

    def self.refund_routine(balance_transaction, start_date, company_id)
      refunds_hash = {past_time_window: nil, this_time_window: nil} #initialize hash
      refund = Refund.by_company(company_id)
        .select{|charge| charge['id'] == balance_transaction['source']}.first
      charge = Charge.by_company(company_id)
        .select{|charge| charge['id'] == refund['charge']}.first
      invoice = Invoice.by_company(company_id)
        .select{|invoice| invoice['id'] == charge['invoice']}.first
      #if created outside of current time window, store it in refunds_hash[:past_time_window]
      if charge['created'].to_i < start_date.to_i
        #determine total refunded
        refunds_hash[:past_time_window] = {product_id: invoice['metadata']['product_id'], amount: refund['amount'] * -1} #keep numbers positive
      #else, store it in refunds_hash[:this_time_window]
      else
        #determine total refunded for this balance transaction
        obj = {}
        obj[:product_id] = refund['metadata']['product_id']
        obj[:refund] = refund['amount']
        #subtract out fees
        obj[:stripe_fee_contrib] = balance_transaction['fee_details'].select {|r| r['type'] == 'stripe_fee'}.map {|rt| rt['amount']}.sum #This will return a negative number to "refund" fees
        #subtract out taxes
        percent_tax = (invoice['tax'] ||= 0) / invoice['subtotal']
        obj[:tax] = -1 * obj[:refund] * percent_tax / (1 + percent_tax) # * -1 to "refund" taxes
        #Determine accounting_code
        obj[:accounting_code] = refund['metadata']['accounting_code']
        #Set irrelevant keys to 0
        obj[:discount] = 0
        obj[:revenue] = 0
        refunds_hash[:this_time_window] = obj
      end
      return refunds_hash
    end

    def self.create_revenues_hash(balance_transaction_array, back_dated_refunds_array, start_date, end_date, company_id)
      #Initialize hash
      revenues_hash = {
        products: {},
        start_date: "#{Time.at(start_date.to_i).utc.to_date.to_s}",
        end_date: "#{Time.at(end_date.to_i).utc.to_date.to_s}"
      }
      hproc = Proc.new {|key, old_val, new_val| old_val + new_val} #Generate a Proc (aka 'closure') for repetitive merge tasks below
      balance_transaction_array.each do |bt|
        product_id = bt[:product_id]
        accounting_code = bt[:accounting_code]

        revenues_hash[:products]["#{product_id}"] ||= {accounting_codes: {}, back_dated_refunds: {}} #preload nested subhashes
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"] ||= {name: nil} #preload nested subhash
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:name] ||= Product.find(product_id).accounting_codes.find_by_code(bt[:accounting_code]).name
        #Cumulatively tallie up all of the quantities below
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"].merge!({revenue: bt[:revenue]}, &hproc)
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"].merge!({discount: bt[:discount]}, &hproc)
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"].merge!({tax: bt[:tax]}, &hproc)
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"].merge!({stripe_fees: bt[:stripe_fee_contrib]}, &hproc)
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"].merge!({refund: bt[:refund]}, &hproc)
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:gross_revenues] = revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:revenue] - revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:discount]
        revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:net_revenues] = revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:gross_revenues] - revenues_hash[:products]["#{product_id}"][:accounting_codes]["#{accounting_code}"][:stripe_fees]
      end
      unless back_dated_refunds_array.empty?
        back_dated_refunds_array.each do |ref|
          # revenues_hash[:products]["#{ref['product_id']}"] ||= {accounting_codes: nil, back_dated_refunds: nil} #preload nested subhashes
          revenues_hash[:products]["#{ref['product_id']}"].merge!({back_dated_refunds: ref['amount']}, &hproc)
        end
      end
      return revenues_hash
    end

    def self.iterate_balance_transactions(balance_transactions, start_date, end_date, company_id)
      balance_transaction_array = []
      back_dated_refunds_array = []
      balance_transactions.select {|t| t['type'] == 'charge' || 'adjustment' || 'refund'}.each do |bt|
        case bt['type']
        when 'charge'
          balance_transaction_array << charge_routine(bt, company_id)
        when 'refund'
          refund_hash = refund_routine(bt, start_date, company_id)
          balance_transaction_array << refund_hash[:this_time_window]
          back_dated_refunds_array << refund_hash[:past_time_window] unless refund_hash[:past_time_window].nil?
        else
        end
      end
      revenues_hash = create_revenues_hash(balance_transaction_array, back_dated_refunds_array,
        start_date, end_date, company_id)
    end

    def self.create_csv(revenues_hash, start_date, end_date, company_id)
      attributes = %w{accounting_code name revenues discounts gross_revenues cc_processing_fees net_revenues taxes refunds}
      csv_path = "#{Rails.root}/tmp/revenues-company-#{company_id}-#{start_date}-#{end_date}.csv"
      puts "csv_path #{csv_path}"
      csv_file = CSV.open(csv_path, 'wb') do |csv|
        csv << attributes
        revenues_hash[:products].keys.each do |product_id|
          csv << ["Product ID: #{product_id}, Name: #{Product.find(product_id).name}"]
          revenues_hash[:products]["#{product_id}"][:accounting_codes].keys.each do |key|
            arr = []
            arr << key
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:name]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:revenue]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:discount]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:gross_revenues]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:stripe_fees]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:net_revenues]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:tax]
            arr << revenues_hash[:products]["#{product_id}"][:accounting_codes][key][:refund]
            csv << arr
          end
          csv << [] #create blank row
          csv << ["Report start date: ", revenues_hash[:start_date]]
          csv << ["Report end date: ", revenues_hash[:end_date]]
          csv << ["Refunds from charges in the past: ", revenues_hash[:back_dated_refunds]]
          csv << [] #create blank row
        end
      end
      puts "csv_file #{csv_file}"
      return csv_path
    end
  end
end
