module Billing
  class Biller
    def self.bill(customer_id)
      #Find the invoice_items that are outstanding for that customer
      customer = Customer.find(customer_id)
      invoice_items = InvoiceItem.by_customer(customer.id)
      ii_subtotal = invoice_items.map{|ii| ii['amount']}.sum
      ii_taxes = invoice_items.map{|ii| ii.dig('metadata', 'tax') ? ii['metadata']['tax'].to_i : 0}.sum
      ##Apply a blended tax percentage that is based on all of the taxes for the indiv. invoice_items
      tax_percent = ((ii_taxes.to_f / ii_subtotal.to_f) * 100).round(2)
      metadata = {product_id: customer.product_id}
      ##Generate a Stripe Fee based on the invoice total (in cents)
      company = customer.product.company
      stripe_fee = (ii_subtotal * company.license_fee_percentage).to_i
      #Generate an invoice for that customer
      invoice = Invoice.create(customer.id, metadata, tax_percent,
        company.id, stripe_fee)
      #Create new invoice_items for the current month (for each subscription)
      create_ii_for_current_mo(customer)
      #Account for taxes (and non taxable items in Global settings)

    end

    def self.create_ii_for_current_mo(customer)
      customer.subscriptions.each do |subscription|
        plan = subscription.plan
        product = plan.product
        quantity = subscription.customer_items.count
        accounting_code = Product.storage_code
        zip = Address.find(customer.last_appointment_address_id).zip_code
        tax_by_zip = product.taxes.select{|tax| tax.zips.include?(zip)}.first
        tax_percent = product.taxed_accounting_codes.include?(accounting_code.to_s) ? (tax_by_zip ? tax_by_zip.tax_percent : product.default_tax) : 0
        amount = plan.price_per_plan * quantity
        tax = tax_percent * amount
        metadata = {
            plan_id: plan.id,
            product_id: product.id,
            tax: tax,
            accounting_code: accounting_code,
            quantity: quantity
        }
        description = "Storage subscription for #{plan.name} plan through #{Date::MONTHNAMES[Date.today.month]} end, QTY: #{quantity}"
        currency = product.currency
        InvoiceItem.create(customer.id, amount, description, currency, metadata, product.company_id)
      end
    end
  end
end
