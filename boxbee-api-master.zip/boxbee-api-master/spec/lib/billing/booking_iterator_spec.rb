require 'rails_helper'
require 'booking_iterator'

module Billing
  RSpec.describe BookingIterator do
    let(:booking_iterator) {described_class.new(FactoryGirl.create(:job_state).id, booking, product_price, bms_plans)}
    let(:booking) {JSON.parse(File.read("#{Rails.root}/spec/lib/billing/bookings.json"))["data"].first}
    let(:product_price) {@product_price}
    let(:bms_plans) {JSON.parse(File.read("#{Rails.root}/spec/lib/billing/plans.json"))["data"]}
    let(:resque) {Resque}
    let(:customer_stripe_subscriptions) {[{"plan": {"id": 1}}]}
    before do
      #Stop test before proceeding to next classes (StripeTransitBiller and StripeSubscriptionBiller)
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
      token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
      stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
      # @stripe_plan = Stripe::Plan.retrieve('1', {stripe_account: @rms_client.stripe_account_id})
      @stripe_plan = Stripe::Plan.create({id: 1, amount: 5000, currency: 'usd', interval: 'month',
        name: 'Big test plan'}, {stripe_account: @rms_client.stripe_account_id})
      @stripe_plan = Stripe::Plan.create({id: 2, amount: 5000, currency: 'usd', interval: 'month',
        name: 'Big test plan'}, {stripe_account: @rms_client.stripe_account_id})
      @stripe_subscription = stripe_customer.subscriptions.create(plan: 1)
      @stripe_subscription = stripe_customer.subscriptions.create(plan: 2)
      puts "stripe_customer #{stripe_customer}"
      @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price,
        stripe_customer_id: stripe_customer['id'])
      @tax = FactoryGirl.create(:tax, zip:'10001', product_price: @product_price)
      allow(resque).to receive(:enqueue).and_return(true)

      # stripe_subscription_mock = double('stripe_subscription_mock')
      # Billing::StripeSubscriptionBiller.stub(:new) {stripe_subscription_mock}
      # allow(stripe_subscription_mock).to receive(:process).and_return(true)


    end

    describe "#process" do
      subject {booking_iterator.process}
      before :each do
        allow(booking_iterator).to receive(:get_active_form_factors).with(@product_user_price.user_id).and_return(JSON.parse(File.read("#{Rails.root}/spec/lib/billing/activeformfactors.json"))["data"])
        allow(booking_iterator).to receive(:get_active_plans).with(@product_price.company_id).and_return(JSON.parse(File.read("#{Rails.root}/spec/lib/billing/activeplans.json"))["data"])
      end
      after :each do
        subject
      end
      it "receives get_active_form_factors" do
        expect(booking_iterator).to receive(:get_active_form_factors)
      end
      before do

      end
      it "calls the Transit biller the appropriate number of times" do
        # expect(Billing::StripeSubscriptionBiller).to receive(:new).with(1, anything, anything, anything, anything, anything, anything, anything, anything, anything, anything).twice
        expect(Resque).to receive(:enqueue)
          .with(StripeTransitBillerJob, anything, anything, anything, anything, anything, anything)
      end
      it "gets active plans" do
        expect(booking_iterator).to receive(:get_active_plans)
      end
      it "successfully determines the Stripe subscription for the given form factor" do
      end
      it "finds the right Stripe Customer Id, user Id, client Id, and product Id" do
        # expect(Billing::StripeSubscriptionBiller).to receive(:new).with(anything, anything, an_instance_of(Stripe::Customer), 1, 1, anything, anything, anything, anything, 1, anything)
      end
      it "finds the right active_plan each time" do
      end
      it "gets the right zip and tax table" do
      end
      it "successfully finds a bms_plans array" do
      end
      it "calls the Subscription biller the appropriate number of times" do
        expect(Resque).to receive(:enqueue)
          .with(StripeSubscriptionBillerJob, anything, anything, anything, anything, anything, anything, anything, anything, anything)
      end
      it "calls the Invoice Sweeper with the appropriate arguments" do
        expect(Resque).to receive(:enqueue)
          .with(InvoiceSweeperJob, anything, anything, anything, anything, anything, anything, anything)
      end
    end
  end
end
