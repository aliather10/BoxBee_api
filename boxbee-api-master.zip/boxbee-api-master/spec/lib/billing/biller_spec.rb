require 'rails_helper'
require 'biller'

module Billing
  RSpec.describe Biller do
    let(:biller)                {described_class}
    let(:resque) {Resque}

    describe "#bill" do
      subject {biller.bill(@job_state.id, Date.new(2015,12,29))}
      before do
        @job_state = FactoryGirl.create(:job_state)
        puts "@job_state #{@job_state.inspect}"
        booking_arr = JSON.parse(File.read("#{Rails.root}/spec/lib/billing/bookings.json"))["data"]
        rms_client = FactoryGirl.create(:rms_client)
        for ii in 1..4
          FactoryGirl.create(:product_price, company_id: rms_client.company_id, product_id: ii)
        end
        allow(biller).to receive(:get_bookings).with(1, anything, anything).and_return(booking_arr.slice(0,2))
        allow(biller).to receive(:get_bookings).with(2, anything, anything).and_return([])
        allow(biller).to receive(:get_bookings).with(3, anything, anything).and_return([booking_arr[2]])
        allow(biller).to receive(:get_bookings).with(4, anything, anything).and_return([booking_arr[3]])
        plan_arr = JSON.parse(File.read("#{Rails.root}/spec/lib/billing/plans.json"))["data"]
        allow(biller).to receive(:get_plans).with(1).and_return([plan_arr.slice(0,3)])
        allow(biller).to receive(:get_plans).with(2).and_return([plan_arr[3]])
        #Stop test before calling BookingIterator class
        booking_iterator_mock = double('booking_iterator_mock')
        Billing::BookingIterator.stub(:new) {booking_iterator_mock}
        allow(booking_iterator_mock).to receive(:process).and_return(true)

        allow(resque).to receive(:enqueue).and_return(true)
      end
      after :each do
        subject
      end
      it "iterates through the appropriate number of bookings" do
        expect(biller).to receive(:get_bookings).exactly(4).times
      end
      it "iterates through the appropriate number of bookings with correct arguments" do
        expect(biller).to receive(:get_bookings).with(1, anything, anything).once
        expect(biller).not_to receive(:get_bookings).with(2, anything, anything).once
        expect(biller).to receive(:get_bookings).with(3, anything, anything).once
        expect(biller).to receive(:get_bookings).with(4, anything, anything).once
      end
      it "fetches bms plans for each client correctly" do
        expect(biller).to receive(:get_plans).with(1).exactly(4).times
        expect(biller).to_not receive(:get_plans).with(2)
      end
    end

    context "errors" do
      it "sends an email with error context if at least one error occurs"
      it "logs error in failed_billings table"
    end
  end
end
