require 'rails_helper'

RSpec.describe Api::V1::ZipsController, :type => :controller do

end
