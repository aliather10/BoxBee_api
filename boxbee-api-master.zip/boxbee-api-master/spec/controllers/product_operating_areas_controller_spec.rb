require 'rails_helper'

RSpec.describe Api::V1::ProductOperatingAreasController, :type => :controller do

end
