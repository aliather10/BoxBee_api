require 'rails_helper'

RSpec.describe Api::V1::TaxesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
  end

  describe "POST #Create" do
    before :each do
      @tax = FactoryGirl.attributes_for(:tax)
      @tax[:company_id] = @rms_client.company_id
    end
    context "for valid attributes" do
      it "creates a new Tax record" do
        expect{post :create, {zip: '10001', product_id: @product_price.product_id,
          tax_percent: 10, accounting_codes: "1000, 1100, 1200"}}.to change(Tax, :count).by(1)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        post :create, {zip: '10001', product_id: @product_price.product_id,
          tax_percent: 10, accounting_codes: "1000, 1100, 1200"}
        expect(response).to have_http_status(:success)
        tax_response = JSON.parse(response.body, symbolize_names: true)
        expect(tax_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah', accounting_codes: "1000, 1100, 1200"}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end

  describe "GET #Index" do
    context "for valid attributes" do
      before :each do
        @tax1 = FactoryGirl.create(:tax, zip: '10001', product_price: @product_price)
        @tax2 = FactoryGirl.create(:tax, zip: '10036', product_price: @product_price)
        get :index, company_id: @rms_client.company_id
        @taxes_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "retrieves all Tax records" do
        expect(@taxes_response[:data].size).to eq(2)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Index" do
    context "for valid attributes" do
      before :each do
        @tax1 = FactoryGirl.create(:tax, zip: '10001', product_price: @product_price)
        @tax2 = FactoryGirl.create(:tax, zip: '10036', product_price: @product_price)
        get :index, company_id: @rms_client.company_id
        @taxes_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "retrieves all Tax records" do
        expect(@taxes_response[:data].size).to eq(2)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Product" do
    context "for valid attributes" do
      before :each do
        @tax1 = FactoryGirl.create(:tax, zip: '10001', product_price: @product_price)
        @tax2 = FactoryGirl.create(:tax, zip: '10036', product_price: @product_price)
        get :product, {product_id: @product_price.product_id, type: 'storage', zip: '10001'}
        @taxes_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #product_anonymous" do
    context "for valid attributes" do
      before :each do
        allow(controller).to receive(:current_product).and_return({id: 1}.as_json)
        @tax1 = FactoryGirl.create(:tax, zip: '10001', product_price: @product_price)
        @tax2 = FactoryGirl.create(:tax, zip: '10036', product_price: @product_price)
        get :product, {product_id: @product_price.product_id, type: 'storage', zip: '10001'}
        @taxes_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "DELETE #Destroy" do
    context "for valid attributes" do
      before :each do
        @tax = FactoryGirl.create(:tax, zip: '10001', product_price: @product_price)
      end
      it "deletes a Tax record" do
        expect{delete :destroy, {id: @tax.id}}.to change(Tax, :count).by(-1)
      end
      it "renders an Tax record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
