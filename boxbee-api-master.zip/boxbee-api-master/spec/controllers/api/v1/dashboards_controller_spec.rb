require 'rails_helper'

RSpec.describe Api::V1::DashboardsController, type: :controller do

end
