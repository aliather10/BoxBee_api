require 'rails_helper'

RSpec.describe Api::V1::OnboardingController, type: :controller do

end
