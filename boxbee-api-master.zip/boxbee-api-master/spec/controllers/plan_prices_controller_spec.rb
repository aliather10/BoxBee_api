require 'rails_helper'

RSpec.describe Api::V1::PlanPricesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)

    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new PlanPrice record" do
        expect{post :create, FactoryGirl.attributes_for(:plan_price, plan_id: "#{Faker::Number.number(5)}").merge({product_id: @product_price.product_id})}.to change(PlanPrice, :count).by(1)
      end
      it "renders an PlanPrice record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:plan_price, plan_id: "#{Faker::Number.number(5)}").merge({product_id: @product_price.product_id})
        expect(response).to have_http_status(:success)
        plan_price_response = JSON.parse(response.body, symbolize_names: true)
        expect(plan_price_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      before do
        allow(controller).to receive(:sync_to_stripe_plan).and_return(true)
      end
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah', product_id: @product_price.product_id, company_id: @rms_client.company_id}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end

  describe "GET #Show" do
    before :each do
      @plan_price = FactoryGirl.create(:plan_price, product_price: @product_price)
      get :show, id: @plan_price.id, format: :json
      @plan_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a PlanPrice record" do
        expect(@plan_price_response[:data][:id]).to eq(@plan_price.id)
      end
      it "renders an PlanPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Plan" do
    before :each do
      @plan_price = FactoryGirl.create(:plan_price, product_price: @product_price)
      get :plan, plan_id: @plan_price.plan_id, format: :json
      @plan_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a PlanPrice record" do
        expect(@plan_price_response[:data][:plan_id]).to eq(@plan_price.plan_id)
      end
      it "renders an PlanPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  context "Integration test: sync_to_stripe_plan" do
    describe "Post #Create" do
      it "successfully returns a created stripe plan" do
        expect(:sync_to_stripe_plan).to be_truthy
      end
    end
  end
end
