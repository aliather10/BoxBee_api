require 'rails_helper'

RSpec.describe Api::V1::ActivePlansController, :type => :controller do

end
