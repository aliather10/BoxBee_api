require 'rails_helper'

RSpec.describe Api::V1::BookingActionDetailsController, :type => :controller do

end
