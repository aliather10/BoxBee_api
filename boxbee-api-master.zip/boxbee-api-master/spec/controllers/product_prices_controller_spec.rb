require 'rails_helper'

RSpec.describe Api::V1::ProductPricesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)
  end

  describe "POST #Create" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
    end
    context "for valid attributes" do
      it "creates a new ProductPrice record" do
        expect{post :create, FactoryGirl.attributes_for(:product_price)}.to change(ProductPrice, :count).by(1)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:product_price)
        expect(response).to have_http_status(:success)
        product_price_response = JSON.parse(response.body, symbolize_names: true)
        expect(product_price_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah'}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end

  describe "GET #Show" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price)
      get :show, id: @product_price.id, format: :json
      @product_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a new ProductPrice record" do
        expect(@product_price_response[:data][:id]).to eq(@product_price.id)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "PUT #Update" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price)
      put :update, {id: @product_price.id, empty_delivery_price: 3000}, format: :json
      @product_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "updates a ProductPrice record" do
        expect(@product_price_response[:data][:empty_delivery_price]).to eq(3000)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "PUT #update_by_product" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price)
      put :update, {id: @product_price.id, empty_delivery_price: 3000}, format: :json
      @product_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "updates a ProductPrice record" do
        expect(@product_price_response[:data][:empty_delivery_price]).to eq(3000)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Client" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price)
      get :client, company_id: @product_price.company_id, format: :json
      @product_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a new ProductPrice record by company_id" do
        expect(@product_price_response[:data][0][:company_id]).to eq(@product_price.company_id)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Product" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price)
      get :product, {product_id: @product_price.product_id, company_id: @product_price.company_id}, format: :json
      @product_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a new ProductPrice record by product_id" do
        expect(@product_price_response[:data][:product_id]).to eq(@product_price.product_id)
      end
      it "renders an ProductPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Index" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @rms_client = FactoryGirl.create(:rms_client, company_id: 2)
      @product_price1 = FactoryGirl.create(:product_price, company_id: 2, product_id: 2)
      @product_price2 = FactoryGirl.create(:product_price, company_id: 2, product_id: 3)
      get :index
      @product_prices_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves all ProductPrice records" do
        expect(@product_prices_response[:data].size).to eq(2)
        expect([@product_prices_response[:data][0][:id], @product_prices_response[:data][1][:id]]).to eq([@product_price1.id, @product_price2.id])
      end
      it "renders ProductPrice records in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
