require 'rails_helper'

RSpec.describe Api::V1::ActivePlanPricesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)
  end

  describe "POST #Create" do
    before do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
      @plan_price = FactoryGirl.create(:plan_price, product_price: @product_price)
    end
    context "for valid attributes" do
      it "creates a new ActivePlanPrice record" do
        expect{post :create, FactoryGirl.attributes_for(:active_plan_price)}.to change(ActivePlanPrice, :count).by(1)
      end
      it "renders an ActivePlanPrice record in JSON format w/ status: 'success'" do
        post :create, {company_id: @rms_client.company_id, plan_id: @plan_price.plan_id,
          active_plan_id: 1, user_id: 1, price_per_plan: 3070}
        puts "response #{response.inspect}"
        expect(response).to have_http_status(:success)
        active_plan_price_response = JSON.parse(response.body, symbolize_names: true)
        expect(active_plan_price_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "with incorrect fields, renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah', plan_id: 1}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end

  describe "GET #Show" do
    context "for valid attributes" do
      before :each do
        @active_plan_price = FactoryGirl.create(:active_plan_price)
        get :show, id: @active_plan_price.id, format: :json
        @active_plan_price_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "retrieves an ActivePlanPrice record" do
        expect(@active_plan_price_response[:data][:id]).to eq(@active_plan_price.id)
      end
      it "renders an ActivePlanPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #active_plan" do
    context "for valid attributes" do
      before :each do
        @active_plan_price = FactoryGirl.create(:active_plan_price)
        get :active_plan, active_plan_id: @active_plan_price.active_plan_id, format: :json
        @active_plan_price_response = JSON.parse(response.body, symbolize_names: true)
      end
      it "retrieves an ActivePlanPrice record" do
        expect(@active_plan_price_response[:data][:active_plan_id]).to eq(@active_plan_price.active_plan_id)
      end
      it "renders an ActivePlanPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
