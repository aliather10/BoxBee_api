require 'rails_helper'

RSpec.describe Api::V1::PlanFormFactorAssetsController, :type => :controller do

end
