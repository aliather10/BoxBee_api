require 'rails_helper'

RSpec.describe Api::V1::FilledSlotsController, :type => :controller do

end
