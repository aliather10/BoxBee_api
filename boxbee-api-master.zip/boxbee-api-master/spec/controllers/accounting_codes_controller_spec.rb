require 'rails_helper'

RSpec.describe Api::V1::AccountingCodesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
  end

  describe "GET #Index" do
    before :each do
      @rms_client = FactoryGirl.create(:rms_client)
      @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    end
    context "for valid attributes" do
      it "retrieves all AccountingCode records" do
        get :index, {product_id: @product_price.product_id, company_id: @rms_client.company_id}
        accounting_code_response = JSON.parse(response.body, symbolize_names: true)
        expect(accounting_code_response.size).to eq 3
      end
      it "renders AccountingCode records in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
