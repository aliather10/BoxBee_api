require 'rails_helper'

RSpec.describe Api::V1::Stripe::RefundsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price,
      stripe_customer_id: @stripe_customer['id'])
    #use Faker to generate random IDs, for plan uniqueness
    @invoice_item_params = {amount: Faker::Number.between(5600,9700), currency: 'usd', description: 'hello test', discountable: true, customer: @product_user_price.stripe_customer_id}
    @invoice_items = []; 3.times {@invoice_items << Stripe::InvoiceItem.create(@invoice_item_params, {stripe_account: @rms_client.stripe_account_id})['id']}
    @invoice_params = {customer: @product_user_price.stripe_customer_id, description: 'Hello test', tax_percent: 5}
    @invoice = Stripe::Invoice.create(@invoice_params, {stripe_account: @rms_client.stripe_account_id})
    @invoice.pay
    @refund_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, reason: 'requested_by_customer'}
    # @refund = Stripe::Refund.create(@refund_params.except(:company_id, :user_id).merge({id: Faker::Lorem.word}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new Refund" do
        controller.stub(:sanitize).and_return true
        post :create, {invoice_items: @invoice_items.join(", "), company_id: @product_price.company_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
      it "creates a new Refund for an invoice_item that has been attached to an invoice that has not been paid yet" do
        invoice_item = Stripe::InvoiceItem.create(@invoice_item_params, {stripe_account: @rms_client.stripe_account_id})['id']
        invoice = Stripe::Invoice.create(@invoice_params, {stripe_account: @rms_client.stripe_account_id})
        controller.stub(:sanitize).and_return true
        post :create, {invoice_items: invoice_item, company_id: @product_price.company_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
end
