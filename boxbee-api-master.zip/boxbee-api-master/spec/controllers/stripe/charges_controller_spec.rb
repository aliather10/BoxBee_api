require 'rails_helper'

RSpec.describe Api::V1::Stripe::ChargesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)

    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
    # @charge_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, amount: 10000, currency: 'usd', customer: @product_user_price.stripe_customer_id}
    # @charge = Stripe::Charge.all({limit: 30}, {stripe_account: @rms_client.stripe_account_id}).as_json['data'].last['id']
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @charge = Stripe::Charge.create({amount: 7777, currency: 'usd', customer: @stripe_customer['id']},
      {stripe_account: @rms_client.stripe_account_id})
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a Charge" do
        get :show, {id: @charge['id'], company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        puts "response #{response.inspect}"
        expect(response).to have_http_status(:success)
      end
    end
  end
end
