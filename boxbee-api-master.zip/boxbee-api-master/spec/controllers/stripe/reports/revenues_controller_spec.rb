require 'rails_helper'

RSpec.describe Api::V1::Stripe::Reports::RevenuesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return true
    # allow(controller).to receive(:check_users_client).and_return true
    allow(controller).to receive(:is_super_user?).and_return true
    h = Hash.new; h["email"] = "client_user@test.com"
    allow(controller).to receive(:get_user).and_return h
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @start_date = Date.new(2015,12,1).to_time.to_i
    @end_date = Date.new(2015,12,31).to_time.to_i
    @report = FactoryGirl.create(:report)
    @csv_path = "#{Rails.root}/tmp/testfile.csv"
    @csv_file = CSV.open(@csv_path, "wb") {|csv| csv << [1,2,3]}
  end

  describe "GET get_revenues" do
    before :each do
      Reports::Revenues.stub(:generator).and_return @report
      ut = {"id": 1}
      controller.instance_variable_set(:@user, ut)
      CsvMailer.stub_chain(:revenue_report, :deliver_now).and_return true
    end
    after :each do
      get :revenues, {product_id: @product_price.product_id, company_id: @rms_client.company_id, start_date: @start_date,
        end_date: @end_date}, format: :json
    end
    it "renders JSON successfully and notifies requester that request is pending" do
      expect(response).to have_http_status(:success)
    end
  end
end
