require 'rails_helper'

RSpec.describe Api::V1::Stripe::Webhooks::CustomersController, :type => :controller do
  before :each do
    allow(controller).to receive(:set_ceilings).and_return true
  end

  describe "POST" do
    it "renders JSON successfully" do
      post :webhook, {object: {}}, format: :json
      expect(response).to have_http_status(:success)
    end
  end
end
