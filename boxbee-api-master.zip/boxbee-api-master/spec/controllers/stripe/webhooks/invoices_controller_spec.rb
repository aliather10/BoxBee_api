require 'rails_helper'

RSpec.describe Api::V1::Stripe::Webhooks::InvoicesController, :type => :controller do
  before :each do
    allow(controller).to receive(:set_ceilings).and_return true
  end

  describe "GET get_revenues" do
    it "renders JSON successfully and notifies requester that request is pending" do
      post :webhook, {object: {}}, format: :json
      expect(response).to have_http_status(:success)
    end
  end
end
