require 'rails_helper'

RSpec.describe Api::V1::Stripe::InvoiceItemsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price,
      stripe_customer_id: @stripe_customer['id'])
    @invoice_item_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, amount: 5700, currency: 'usd', description: 'hello test', discountable: true, product_id: @product_price.product_id}
    @invoice_item = Stripe::InvoiceItem.create(@invoice_item_params.except(:id, :company_id, :user_id, :product_id).merge({customer: @product_user_price.stripe_customer_id}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new InvoiceItem" do
        post :create, @invoice_item_params
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a InvoiceItem" do
        get :show, {id: @invoice_item, company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Index" do
    context "for valid attributes" do
      it "retrieves all InvoiceItems for a particular product" do
        get :index, {company_id: @product_price.company_id, user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
      it "retrieves all InvoiceItems for a particular invoice" do
        get :index, {company_id: @product_price.company_id, user_id: @product_user_price.user_id, product_id: @product_price.product_id, invoice_id: 'in_17SavOGtWBbsCJcoCdCsuQpj'}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "PUT #Update" do
    context "for valid attributes" do
      it "updates a InvoiceItem" do
        put :update, @invoice_item_params.merge({id: @invoice_item})
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "DELETE #Destroy" do
    context "for valid attributes" do
      it "deletes an InvoiceItem" do
        delete :destroy, {id: @invoice_item, company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
end
