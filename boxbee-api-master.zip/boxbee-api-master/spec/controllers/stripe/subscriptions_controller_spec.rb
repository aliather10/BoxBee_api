require 'rails_helper'

RSpec.describe Api::V1::Stripe::SubscriptionsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)

    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price,
      stripe_customer_id: @stripe_customer['id'])
    @plan_params = {company_id: @product_price.company_id, id: Faker::Number.number(5), name: Faker::Lorem.sentence, amount: 5600, trial_period_days: 30, currency: 'usd', interval: 'month'}
    @plan = Stripe::Plan.create(@plan_params.except(:company_id, :user_id).merge({id: Faker::Number.number(5)}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
    plan_id = Stripe::Plan.all({limit: 30}, {stripe_account: @rms_client.stripe_account_id}).as_json['data'].last['id']
    @subscription_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, plan: plan_id, quantity: 9, state_code: 'NY', prorate: false, product_id: @product_price.product_id}
    customer = Stripe::Customer.retrieve(@product_user_price.stripe_customer_id, {stripe_account: @rms_client.stripe_account_id})
    customer.subscriptions.create({plan: @plan}, {stripe_account: @rms_client.stripe_account_id})
    @subscription = customer.subscriptions.all({limit: 30}, {stripe_account: @rms_client.stripe_account_id}).as_json['data'].last['id']
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a Subscription" do
        get :show, {id: @subscription, company_id: @product_price.company_id, user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Index" do
    context "for valid attributes" do
      it "retrieves all Subscriptions" do
        get :index, {company_id: @product_price.company_id, user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
end
