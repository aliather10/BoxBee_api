require 'rails_helper'

RSpec.describe Api::V1::Stripe::CardsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @card_params = {company_id: 1, user_id: 1, product_id: 1, stripe_token: token}
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new Card" do
        controller.stub_chain(:get_stripe_customer, :sources, :create).and_return({}) #because we can't randomly generate a token on the fly
        post :create, @card_params
        expect(response).to have_http_status(:success)
      end
    end
  end
  before do
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @product_user_price.update_attributes!(stripe_customer_id: @stripe_customer['id'])
    @card_id = @stripe_customer.sources.all({limit:1}, {stripe_account: @rms_client.stripe_account_id})['data'].first['id']
    puts "rms_client #{@rms_client.inspect}"
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a Card" do
        puts "@card #{@card_id}"
        get :show, {id: @card_id, company_id: @rms_client.company_id,
          user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Index" do
    context "for valid attributes" do
      it "retrieves all Cards" do
        get :index, {company_id: @rms_client.company_id, user_id: @product_user_price.user_id,
          product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "PUT #Update" do
    context "for valid attributes" do
      it "updates a Card" do
        put :update, @card_params.merge({id: @card_id})
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "DELETE #Destroy" do
    context "for valid attributes" do
      it "deletes a Card" do
        delete :destroy, {id: @card_id, company_id: @rms_client.company_id,
          user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
end
