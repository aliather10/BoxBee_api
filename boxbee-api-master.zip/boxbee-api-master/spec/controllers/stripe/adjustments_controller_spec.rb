require 'rails_helper'

RSpec.describe Api::V1::Stripe::AdjustmentsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    @adj_params = {company_id: 1, user_id: 1, product_id: 1, zip: '10001',
      adjustments: [{amount:1000, description: 'Tape and boxes'}]}
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @tax = FactoryGirl.create(:tax, product_price: @product_price, zip: '10001')
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new Card" do
        # controller.stub_chain(:get_stripe_customer, :sources, :create).and_return({}) #because we can't randomly generate a token on the fly
        post :create, @adj_params
        expect(response).to have_http_status(:success)
      end
    end
  end
end
