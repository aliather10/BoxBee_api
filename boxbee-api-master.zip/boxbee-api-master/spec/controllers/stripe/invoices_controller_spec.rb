require 'rails_helper'

RSpec.describe Api::V1::Stripe::InvoicesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price,
      stripe_customer_id: @stripe_customer['id'])
    @invoice_item_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, amount: 5700, currency: 'usd', description: 'hello test', discountable: true}
    @invoice_item = Stripe::InvoiceItem.create(@invoice_item_params.except(:id, :company_id, :user_id).merge({customer: @product_user_price.stripe_customer_id}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
    @invoice_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, description: 'Hello test', tax_percent: 7.5, closed: true, product_id: @product_price.product_id}
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new Invoice" do
        post :create, @invoice_params
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a Invoice" do
        invoice = Stripe::Invoice.create(@invoice_params.except(:id, :company_id, :user_id, :starting_after, :state_code, :closed, :product_id).merge({customer: @product_user_price.stripe_customer_id}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
        get :show, {id: invoice, company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Index" do
    context "for valid attributes" do
      it "retrieves Invoices when only product_id is specified" do
        get :index, {company_id: @product_price.company_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
      it "retrieves Invoices when also user_id is specified" do
        get :index, {company_id: @product_price.company_id, product_id: @product_price.product_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "PUT #Update" do
    context "for valid attributes" do
      it "updates a Invoice" do
        invoice = Stripe::Invoice.create(@invoice_params.except(:id, :company_id, :user_id, :starting_after, :state_code, :closed, :product_id).merge({customer: @product_user_price.stripe_customer_id}), {stripe_account: @rms_client.stripe_account_id}).as_json['id']
        put :update, @invoice_params.merge({id: invoice})
        expect(response).to have_http_status(:success)
      end
    end
  end
end
