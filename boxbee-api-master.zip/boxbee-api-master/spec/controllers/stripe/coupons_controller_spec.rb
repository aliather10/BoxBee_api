require 'rails_helper'

RSpec.describe Api::V1::Stripe::CouponsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_client_cs).and_return(true)
    allow(controller).to receive(:is_super_user?).and_return(true)
    Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_KEY
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
    @coupon_params = {company_id: @product_price.company_id, user_id: @product_user_price.user_id, id: Faker::Name.first_name, duration: 'once', amount_off: 500, max_redemptions: 100, redeem_by: Date.new(2019, 10, 15).to_time.to_i, currency: 'usd', product_id: @product_price.product_id}
    Stripe::Coupon.create(@coupon_params.except(:company_id, :product_id, :user_id).merge({id: "#{Faker::Name.first_name}-#{Faker::Number.number(5)}"}), {stripe_account: @rms_client.stripe_account_id})
    @coupon = Stripe::Coupon.all({limit: 30}, {stripe_account: @rms_client.stripe_account_id}).as_json['data'].last['id']
  end
  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new Coupon" do
        post :create, @coupon_params
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Show" do
    context "for valid attributes" do
      it "retrieves a Coupon" do
        get :show, {id: @coupon, company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "GET #Index" do
    context "for valid attributes" do
      it "retrieves all Coupons" do
        get :index, {company_id: @product_price.company_id, user_id: @product_user_price.user_id, product_id: @product_price.product_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
  describe "DELETE #Destroy" do
    context "for valid attributes" do
      it "deletes a Coupon" do
        delete :destroy, {id: @coupon, company_id: @product_price.company_id, user_id: @product_user_price.user_id}
        expect(response).to have_http_status(:success)
      end
    end
  end
end
