require 'rails_helper'

RSpec.describe Api::V1::FormFactorsController, :type => :controller do

end
