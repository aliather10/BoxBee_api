require 'rails_helper'

RSpec.describe Api::V1::ActiveFormFactorsController, :type => :controller do

end
