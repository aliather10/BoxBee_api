require 'rails_helper'

RSpec.describe Api::V1::RmsClientsController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)
  end

  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new RmsClient record" do
        expect{post :create, FactoryGirl.attributes_for(:rms_client)}.to change(RmsClient, :count).by(1)
      end
      it "renders an RmsClient record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:rms_client)
        expect(response).to have_http_status(:success)
        rms_client_response = JSON.parse(response.body, symbolize_names: true)
        expect(rms_client_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah'}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end
end
