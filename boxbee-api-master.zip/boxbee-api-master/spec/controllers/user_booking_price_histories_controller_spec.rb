require 'rails_helper'

RSpec.describe Api::V1::UserBookingPriceHistoriesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)

    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
  end

  describe "POST #Create" do
    context "for valid attributes" do
      it "creates a new UserBookingPriceHistory record" do
        expect{post :create, FactoryGirl.attributes_for(:user_booking_price_history).merge({product_id: 1, user_id: 1, company_id: 1})}.to change(UserBookingPriceHistory, :count).by(1)
      end
      it "renders an UserBookingPriceHistory record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:user_booking_price_history).merge({product_id: 1, user_id: 1, company_id: 1})
        expect(response).to have_http_status(:success)
        user_booking_price_history_response = JSON.parse(response.body, symbolize_names: true)
        expect(user_booking_price_history_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah', product_id: 1, user_id: 1, company_id: 1}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end

  describe "PUT #Update" do
    before :each do
      @user_booking_price_history = FactoryGirl.create(:user_booking_price_history, product_user_price: @product_user_price)
      put :update, {id: @user_booking_price_history.id, empty_delivery_price: 3000, company_id: 1}, format: :json
      @user_booking_price_history_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "updates a UserBookingPriceHistory record" do
        expect(@user_booking_price_history_response[:data][:empty_delivery_price]).to eq(3000)
      end
      it "renders an UserBookingPriceHistory record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #Booking" do
    before :each do
      @user_booking_price_history = FactoryGirl.create(:user_booking_price_history, product_user_price: @product_user_price)
      get :booking, {booking_id: @user_booking_price_history.booking_id, company_id: @product_price.company_id}, format: :json
      @user_booking_price_history_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a new UserBookingPriceHistory record by booking_id" do
        expect(@user_booking_price_history_response[:data][:booking_id]).to eq(@user_booking_price_history.booking_id)
      end
      it "renders an UserBookingPriceHistory record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end

  describe "GET #User" do
    before :each do
      @user_booking_price_history = FactoryGirl.create(:user_booking_price_history, product_user_price: @product_user_price)
      get :user, {user_id: @product_user_price.user_id, company_id: @product_price.company_id}, format: :json
      @user_booking_price_history_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a new UserBookingPriceHistory record by booking_id" do
        expect(@user_booking_price_history_response[:data].first[:user_id].to_i).to eq(@product_user_price.user_id.to_i)
      end
      it "renders an UserBookingPriceHistory record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
