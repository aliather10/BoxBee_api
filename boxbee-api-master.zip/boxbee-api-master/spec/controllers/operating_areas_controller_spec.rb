require 'rails_helper'

RSpec.describe Api::V1::OperatingAreasController, :type => :controller do

end
