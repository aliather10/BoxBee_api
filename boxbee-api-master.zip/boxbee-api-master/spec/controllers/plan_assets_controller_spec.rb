require 'rails_helper'

RSpec.describe Api::V1::PlanAssetsController, :type => :controller do

end
