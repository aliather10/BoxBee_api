require 'rails_helper'

RSpec.describe Api::V1::ProductUserPricesController, :type => :controller do
  before :each do
    allow(controller).to receive(:authenticate_user).and_return(true)
    allow(controller).to receive(:require_super_user).and_return(true)
    ut = {"id": 1}
    controller.instance_variable_set(:@user, ut.as_json)
    token = Stripe::Token.create(card: {number: 4242424242424242, exp_month: 3, exp_year: 2018, cvc:222})
    @rms_client = FactoryGirl.create(:rms_client)
    @product_price = FactoryGirl.create(:product_price, company_id: @rms_client.company_id)
    @stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: @rms_client.stripe_account_id})
  end

  describe "POST #Create" do
    before :each do
      controller.stub(:create_stripe_customer_from_token).and_return(@stripe_customer)
    end
    context "for valid attributes" do
      it "creates a new ProductUserPrice record" do
        expect{post :create, FactoryGirl.attributes_for(:product_user_price, product_id: @product_price.product_id).merge({booking_id: 1})}.to change(ProductUserPrice, :count).by(1)
      end
      it "renders an ProductUserPrice record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:product_user_price, product_id: @product_price.product_id).merge({booking_id: 1})
        expect(response).to have_http_status(:success)
        product_user_price_response = JSON.parse(response.body, symbolize_names: true)
        expect(product_user_price_response[:status]).to eq("SUCCESS")
      end
    end
    context "for valid attributes with booking_id" do
      it "creates a new ProductUserPrice record" do
        expect{post :create, FactoryGirl.attributes_for(:product_user_price, product_id: @product_price.product_id).merge({booking_id: 1})}.to change(ProductUserPrice, :count).by(1)
      end
      it "renders an ProductUserPrice record in JSON format w/ status: 'success'" do
        post :create, FactoryGirl.attributes_for(:product_user_price, product_id: @product_price.product_id).merge({booking_id: 1})
        expect(response).to have_http_status(:success)
        product_user_price_response = JSON.parse(response.body, symbolize_names: true)
        expect(product_user_price_response[:status]).to eq("SUCCESS")
      end
    end
    context "for invalid attributes" do
      it "renders an internal_server_error with status: 'failed'" do
        post :create, {wrong_field: 'blah', company_id: @product_price.company_id, product_id: @product_price.product_id, booking_id: 1}
        expect(response).to have_http_status(:internal_server_error)
      end
    end
  end
  describe "GET User" do
    before :each do
      @product_user_price = FactoryGirl.create(:product_user_price, product_price: @product_price)
      get :user, user_id: @product_user_price.user_id, format: :json
      @product_user_price_response = JSON.parse(response.body, symbolize_names: true)
    end
    context "for valid attributes" do
      it "retrieves a ProductUserPrice record" do
        expect(@product_user_price_response[:data].first[:product_user_price][:user_id]).to eq(@product_user_price.user_id)
      end
      it "renders an ProductUserPrice record in JSON format w/ status: 'success'" do
        expect(response).to have_http_status(:success)
      end
    end
  end
end
