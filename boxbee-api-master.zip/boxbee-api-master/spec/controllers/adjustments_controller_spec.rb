require 'rails_helper'

RSpec.describe Api::V1::AdjustmentsController, :type => :controller do

end
