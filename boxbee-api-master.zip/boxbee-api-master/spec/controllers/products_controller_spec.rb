require 'rails_helper'

RSpec.describe Api::V1::ProductsController, :type => :controller do

end
