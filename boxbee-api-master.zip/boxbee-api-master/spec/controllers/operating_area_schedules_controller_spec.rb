require 'rails_helper'

RSpec.describe Api::V1::OperatingAreaSchedulesController, :type => :controller do

end
