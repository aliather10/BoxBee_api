FactoryGirl.define do
  factory :appointment_cutoff do
    product
    cutoff_type :creation
    lead_time 48
    active true
    created_by 1
    modified_by 1
  end
end
