FactoryGirl.define do
  factory :report do |f|
    f.company_id 1
    f.report_type :revenue
    f.created_by 1
    f.modified_by 1
  end
end
