FactoryGirl.define do
  factory :item_type do |f|
    f.company
    f.name {"#{Faker::Company.name} - #{rand(1..100)}"}
    f.image Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/largebox.png')))
    f.requires_empty_pickup true
    f.requires_empty_delivery true
    f.created_by 1
    f.modified_by 1
  end
end
