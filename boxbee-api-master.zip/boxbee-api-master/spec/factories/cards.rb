FactoryGirl.define do
  factory :card do
    
  end
end
