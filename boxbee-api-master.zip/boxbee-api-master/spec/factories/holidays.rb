FactoryGirl.define do
  factory :holiday do |f|
    f.company
    f.name "Christmas"
    f.date DateTime.new(Time.now.year, 12, 25)
    f.created_by 1
    f.modified_by 1
  end
end
