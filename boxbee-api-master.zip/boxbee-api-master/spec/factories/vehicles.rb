FactoryGirl.define do
  factory :vehicle do |f|
    f.company
    f.name {"SF Sprinter Van #{Faker::Number.number(4)}"}
    f.make 'Mercedes'
    f.model 'Sprinter'
    f.vin_num {Faker::Lorem.characters(17)}
    f.license_plate_num {Faker::Lorem.characters(7)}
    f.created_by 1
    f.modified_by 1
  end
end
