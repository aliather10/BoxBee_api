FactoryGirl.define do
  factory :invoice_item do
    
  end
end
