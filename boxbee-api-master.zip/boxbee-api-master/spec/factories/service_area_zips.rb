FactoryGirl.define do
  factory :service_area_zip do |f|
    f.service_area
    f.zip {Faker::Address.zip_code}
    f.active true
    f.created_by 1
    f.modified_by 1
  end
end
