FactoryGirl.define do
  factory :warehouse do |f|
    f.company
    f.name {Faker::Lorem.word}
    f.address_id 1
    f.created_by 1
    f.modified_by 1
  end

end
