FactoryGirl.define do
  factory :refund do
    
  end
end
