FactoryGirl.define do
  factory :failed_billing do |f|
    f.date 0.days.ago.to_time.to_i
    f.user_id 1
    f.booking_id 1
    f.company_id 1
    f.product_id 1
    f.contextual_error_message 'Error: Invalid Format'
  end
end
