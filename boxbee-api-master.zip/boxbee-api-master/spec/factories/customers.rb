FactoryGirl.define do
  factory :customer do |f|
    f.product
    f.user 
    f.preferred_address_id 1
    f.standing :current
    f.created_by 1
    f.modified_by 1
  end
end
