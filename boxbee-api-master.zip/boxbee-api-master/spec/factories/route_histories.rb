FactoryGirl.define do
  factory :route_history do |f|
    f.company_id 2
    f.history_key :transit_event
    f.history_value 1
    f.current_status :in_transit
    f.created_by 1
    f.modified_by 1
  end
end
