FactoryGirl.define do
    factory :customer_item do |f|
      f.subscription
      f.item_type
      f.status :scheduled
      f.name 'Yellow box'
      f.description 'Sturdy plastic yellow totes to keep your items safe in storage'
      f.created_by 1
      f.modified_by 1
    end
end
