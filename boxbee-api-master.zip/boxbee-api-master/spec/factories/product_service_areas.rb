FactoryGirl.define do
  factory :product_service_area do
    
  end
end
