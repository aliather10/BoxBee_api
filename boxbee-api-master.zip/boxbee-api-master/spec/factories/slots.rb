FactoryGirl.define do
  factory :slot do
    service_area_schedule
    start_datetime DateTime.now
    end_datetime (DateTime.now + 2.hours)
    created_by 1
    modified_by 1
  end
end
