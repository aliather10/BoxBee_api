FactoryGirl.define do
  factory :route do |f|
    f.company
    f.vehicle_id 1
    f.driver_id 1
    f.name {"Route #{Faker::Address.city}"}
    f.status :confirmed
    f.created_by 1
    f.modified_by 1
  end
end
