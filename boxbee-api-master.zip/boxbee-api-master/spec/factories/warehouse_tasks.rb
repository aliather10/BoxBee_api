FactoryGirl.define do
  factory :warehouse_task do
    location
    inventory_type :customer_item
    inventory_name 'Yellow box'
    sku "osafj0832408324j"
    quantity 1
    created_by 1
    modified_by 1
    status :created
  end
end
