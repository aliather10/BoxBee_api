FactoryGirl.define do
  factory :schedule_adjustment do |f|
    f.service_area_schedule
    f.name {Faker::Lorem.word}
    f.date {DateTime.now + 2.days}
    f.new_max_appointments_per_slot 5
    f.new_duration_value_mins 180
    f.active true
    f.created_by 1
    f.modified_by 1
  end
end
