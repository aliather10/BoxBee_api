FactoryGirl.define do
  factory :product do
    company

    name {"#{Faker::Lorem.word}-#{rand(1..99)}"}
    description {Faker::Lorem.sentence}
    status :active
    customer_portal_url {"https://customer.#{name}.com"}
    default_customer_portal_url {"https://#{name}.boxbee.com"}

    meta_tags {"on demand storage, full service storage"}
    theme "yellow"
    hero_text {Faker::Lorem.sentence}
    description_text {Faker::Lorem.paragraph}
    what_we_store {Faker::Lorem.sentence}
    how_it_works1 {Faker::Lorem.sentence}
    how_it_works2 {Faker::Lorem.sentence}
    how_it_works3 {Faker::Lorem.sentence}
    our_plans {Faker::Lorem.sentence}
    list_of_service_areas {"Manhattan, Queens, Bronx, Brooklyn"}
    closing_cta "Start Packing"

    terms_title {Faker::Lorem.sentence}
    terms_body {Faker::Lorem.paragraph}
    storage_terms {Faker::Lorem.paragraph}

    about_us_title {Faker::Lorem.sentence}
    about_us_body {Faker::Lorem.paragraph}
    about_us_image Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/test-image.jpg')))


    faq_title {Faker::Lorem.sentence}

    default_slot_duration 60
    default_max_appointments_per_slot 2
    default_daily_start 28800
    default_daily_end 72000
    default_days_of_week ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']

    # logo_image_url {Faker::Company.logo}
    logo_image_url Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/test-image.jpg')))
    support_phone {Faker::PhoneNumber.phone_number}
    support_email {Faker::Internet.email}

    twitter_url {Faker::Internet.url}
    facebook_url {Faker::Internet.url}
    instagram_url {Faker::Internet.url}
    pinterest_url {Faker::Internet.url}
    yelp_url {Faker::Internet.url}

    packed_pickup_price 0
    packed_delivery_price 3000
    empty_pickup_price 0
    currency 'usd'
    default_tax 5.2

    created_by 1
    modified_by 1
  end
end
