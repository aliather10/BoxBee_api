FactoryGirl.define do
  factory :contact_detail do |f|
    f.user
    f.mode_key :phone
    f.mode_value Faker::PhoneNumber.phone_number
    f.created_by 1
    f.modified_by 1
    f.active true
  end
end
