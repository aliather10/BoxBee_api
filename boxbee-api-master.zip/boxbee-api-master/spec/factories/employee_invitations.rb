FactoryGirl.define do
  factory :employee_invitation do |f|
    f.company
    f.email Faker::Internet.email
    f.roles "supervisor, driver"
    f.created_by 1
    f.modified_by 1
  end
end
