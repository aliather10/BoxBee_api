FactoryGirl.define do
  factory :appointment do
    customer
    address_id 1
    preferred_phone '881-756-3248'
    preferred_email {Faker::Internet.email}
    status :scheduled
    window_start_datetime {Date.today + rand(8..15).hours + rand(1..5).days}
    window_end_datetime {window_start_datetime + 1.hour}
    created_by 1
    modified_by 1
  end
end
