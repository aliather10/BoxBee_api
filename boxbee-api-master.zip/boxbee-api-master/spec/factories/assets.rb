FactoryGirl.define do
  factory :asset do |f|
  f.customer_item
  f.asset_type :image
  f.asset_value Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/test-image.jpg')))
  f.sort_order 1
  f.created_by 1
  f.modified_by 1
  end
end
