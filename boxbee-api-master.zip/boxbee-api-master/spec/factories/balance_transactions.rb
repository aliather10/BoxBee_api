FactoryGirl.define do
  factory :balance_transaction do
    
  end
end
