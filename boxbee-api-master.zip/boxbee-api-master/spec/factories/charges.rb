FactoryGirl.define do
  factory :charge do
    
  end
end
