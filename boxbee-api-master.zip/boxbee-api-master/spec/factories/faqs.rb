FactoryGirl.define do
  factory :faq do |f|
    f.product
    f.question {Faker::Lorem.sentence}
    f.answer {Faker::Lorem.paragraph}
  end
end
