FactoryGirl.define do
  factory :service_area_schedule do |f|
    f.service_area
    f.name {"#{Faker::Lorem.word} schedule #{rand(1..99)}"}
    f.day_of_week :monday
    f.start_time {28800} #08:00
    f.end_time {72000} #20:00
    f.duration_value_mins 60
    f.max_appointments_per_slot 2
    f.active true
    f.created_by 1
    f.modified_by 1
  end
end
