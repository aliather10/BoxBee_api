FactoryGirl.define do
  factory :onboarding do
    
  end
end
