FactoryGirl.define do
  factory :accounting_code do |f|
    f.product
    f.name {"Special storage #{rand(1..100)}"}
    f.code 1050
    f.description 'Storage Revenue special'
    f.created_by 1
    f.modified_by 1
  end
end
