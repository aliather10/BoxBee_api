FactoryGirl.define do
  factory :address do |f|
    f.gps_latitude_point {Faker::Address.latitude}
    f.gps_longitude_point {Faker::Address.longitude}
    f.address1 {Faker::Address.street_address}
    f.city {Faker::Address.city}
    f.state_name {Faker::Address.state}
    f.state_code "New York"
    f.zip_code {Faker::Address.zip}
    f.country_name "United States"
    f.created_by 1
    f.modified_by 1
    f.association :addressable, factory: :user
  end
end
