FactoryGirl.define do
  factory :job_state do
    arguments ["2015-12-30"]
    completed_methods [{name: 1}, {name: 2}]
    job_type :daily_biller
    is_dry_run true
  end
end
