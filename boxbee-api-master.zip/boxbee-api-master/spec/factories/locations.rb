FactoryGirl.define do
  factory :location do
    warehouse
    name {"#{Faker::Commerce.color}-#{Faker::Number.between(10,100)}"}
    created_by 1
    modified_by 1
    location_type :permanent
  end
end
