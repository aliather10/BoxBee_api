FactoryGirl.define do
  factory :address_note_option do |f|
    f.company
    f.note {Faker::Lorem.paragraph}
    f.active true
    f.created_by 1
    f.modified_by 1
  end
end
