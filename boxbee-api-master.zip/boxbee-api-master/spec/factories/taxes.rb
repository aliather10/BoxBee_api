FactoryGirl.define do
  factory :tax do
    product
    zips ['10001', '100036']
    tax_percent {Faker::Number.decimal(2)}
    created_by 1
    modified_by 1
  end
end
