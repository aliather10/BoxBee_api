FactoryGirl.define do
  factory :company_detail do
    company
    ssn '546-78-0932'
    dob '01/28/1981'
    government_id Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/driver_license.jpg')))
    entity_type :llc
    entity_name 'McLovin LLC'
    address1 {Faker::Address.street_address}
    city {Faker::Address.city}
    state_name {Faker::Address.state}
    zip_code {Faker::Address.zip_code}
    currency 'usd'
    ein '84-9872193'
    bank_routing_no '9273497235987'
    bank_account_no '082340-8235098235'
    country_name 'United States'
    accepted_terms true
    accepted_terms_ip '17.68.99.34'
  end
end
