FactoryGirl.define do
  factory :invoice do
    
  end
end
