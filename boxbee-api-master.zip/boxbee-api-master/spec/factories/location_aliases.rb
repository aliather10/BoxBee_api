FactoryGirl.define do
  factory :location_alias do
    warehouse
    location_type :permanent
    area {Faker::Lorem.characters(1).capitalize}
    name {"#{Faker::Commerce.color.capitalize} Zone"}
  end
end
