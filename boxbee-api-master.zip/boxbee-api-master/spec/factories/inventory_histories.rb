FactoryGirl.define do
  factory :inventory_history do
    inventory_action :pick
    sku "9283749570"
    inventory_type :customer_item
    quantity 1
    location_id 1
    customer_id 1
    created_by 1
  end
end
