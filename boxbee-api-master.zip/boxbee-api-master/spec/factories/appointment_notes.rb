FactoryGirl.define do
  factory :appointment_note do
    appointment
    note {Faker::Lorem.paragraph.truncate(140)}
    internal false
    created_by 1
    modified_by 1
  end
end
