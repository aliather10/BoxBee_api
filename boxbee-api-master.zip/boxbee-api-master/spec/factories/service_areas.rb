FactoryGirl.define do
  factory :service_area do |f|
    f.company
    f.name {Faker::Address.city}
    f.active true
    f.time_zone 'America/New_York'
    f.created_by 1
    f.modified_by 1
  end
end
