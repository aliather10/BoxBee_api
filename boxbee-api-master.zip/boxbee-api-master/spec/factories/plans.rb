FactoryGirl.define do
  factory :plan do |f|
    f.product
    f.item_type
    f.name {Faker::Lorem.word}
    f.description {Faker::Lorem.sentence}
    f.active true
    f.created_by 1
    f.modified_by 1
  end
end
