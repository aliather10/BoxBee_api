FactoryGirl.define do
  factory :barcode do
    company
    code {Faker::Number.between(10000,12000)}
    created_by 1
  end
end
