FactoryGirl.define do
  factory :inventory do
    location
    inventory_type :customer_item
    inventory_name "Big box"
    sku {Faker::Number.between(170000, 200000)}
    quantity 1
    created_by 1
    modified_by 1
  end

end
