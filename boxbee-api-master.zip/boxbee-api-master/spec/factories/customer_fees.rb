FactoryGirl.define do
  factory :customer_fee do |f|
    f.appointment
    f.customer
    f.empty_delivery_price 0
    f.packed_pickup_price 0
    f.packed_delivery_price 4000
    f.empty_pickup_price 0
    f.created_by 1
    f.modified_by 1
  end
end
