FactoryGirl.define do
  factory :customer_item_history do
    # Should only be used for model testing
    customer_item
    appointment_id 1
    current_status :with_user
    created_by 1
    modified_by 1
  end
end
