FactoryGirl.define do
  factory :address_note do |f|
    f.address
    f.address_note_option
    f.note {Faker::Lorem.sentence}
    f.created_by 1
    f.modified_by 1
  end
end
