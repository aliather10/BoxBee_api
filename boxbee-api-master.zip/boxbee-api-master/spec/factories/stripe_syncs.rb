FactoryGirl.define do
  factory :stripe_sync do
    
  end
end
