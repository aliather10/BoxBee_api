FactoryGirl.define do
  factory :payload do |f|
    f.appointment_detail
    f.warehouse_id 1
    f.name {Faker::Lorem.word}
    f.status :scheduled
    f.added_on_spot false
    f.created_by 1
    f.modified_by 1
  end
end
