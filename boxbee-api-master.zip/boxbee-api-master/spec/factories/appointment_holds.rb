FactoryGirl.define do
  factory :appointment_hold do
    slot
    email {Faker::Internet.email}
  end
end
