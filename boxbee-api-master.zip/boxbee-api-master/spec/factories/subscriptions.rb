FactoryGirl.define do
  factory :subscription do |f|
    f.plan
    f.customer
    f.price_per_plan 5000
    f.active true
    f.quantity 5
    f.created_by 1
    f.modified_by 1
  end
end
