FactoryGirl.define do
  factory :company do
    name {"#{Faker::Company.name} Storage"}
    country 'us'
    contact_name {Faker::Name.name}
    contact_number {Faker::PhoneNumber.phone_number}
    license_fee_percentage 10
    created_by 1
    modified_by 1
    logo Rack::Test::UploadedFile.new(File.open(File.join(Rails.root, '/spec/factories/test-image.jpg')))
    custom_admin_url {"https://admin.#{Faker::Internet.domain_name}"}
  end
end
