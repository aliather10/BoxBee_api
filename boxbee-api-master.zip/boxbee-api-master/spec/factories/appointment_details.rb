FactoryGirl.define do
  factory :appointment_detail do |f|
    f.appointment
    f.customer_item
    f.transit_type :delivery
    f.request_type :empty
    f.created_by 1
    f.modified_by 1
  end
end
