class SlackPreviewSignupJob
  @queue = :default

  def self.perform(admin_user_id)
    admin_user = User.find(admin_user_id)
    company = admin_user.company
    company_detail = company.company_detail
    if SLACK_SIGNUP_NOTIFIER
      SLACK_SIGNUP_NOTIFIER.ping "A new person has registered for the Boxbee Preview. *Name:* #{admin_user.full_name}, *Company:* #{company.name}, " \
                        "*Email:* #{admin_user.email}, *Currently offers storage:* #{company_detail.try(:currently_offer_storage)}, " \
                        "*Currently offers pickup and delivery: #{company_detail.try(:currently_offer_pickup_delivery)}"
    end
  end
end