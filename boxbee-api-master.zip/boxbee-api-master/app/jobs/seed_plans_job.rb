class SeedPlansJob
  @queue = :default

  def self.perform(prototype_item_type_ids, company_id)
    company = Company.find(company_id)
    #Check to see if item_type replication is done for newly created company
    company_it_status = REDIS.hgetall "replicate_item_types:company:#{company.id}"
    timer = 0
    while (company_it_status['status'] != 'completed') && timer < 120
      sleep 2
      timer += 2
    end
    if company_it_status['status'] == 'completed'
      item_type_ids = prototype_item_type_ids.map do |it_id|
        company.item_types.find_by_name(ItemType.find(it_id).name).id
      end
      Onboarding.new(item_type_ids, company.products.first)
    else
      raise "Timed out!"
    end
  end
end
