class UpdateStandingJob
  @queue = :default

  def self.perform(customer_id, standing)
    customer = Customer.find(customer_id)
    customer.standing = standing
    customer.save!
  end
end
