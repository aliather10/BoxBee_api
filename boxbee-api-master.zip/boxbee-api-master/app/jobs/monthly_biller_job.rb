class MonthlyBillerJob
  @queue = :monthly_biller

  def self.perform
    Customer.all.each do |customer|
      Resque.enqueue(MonthlyBillerCustomerIteratorJob, customer.id)
    end
  end
end
