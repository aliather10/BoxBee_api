# This file can be safely deleted
class SeedPrototypeItemTypesJob
  @queue = :default

  def self.perform(company_id)
    Company.find(company_id).replicate_item_types
  end
end
