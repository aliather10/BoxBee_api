class AppointmentIteratorJob
  @queue = :daily_biller

  def self.perform(job_state_id, appointment, product_price_id, bms_plans)
    Billing::AppointmentIterator.new(job_state_id, appointment, product_price_id, bms_plans).process
  end


end
