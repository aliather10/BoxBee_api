class RevenueReportJob
  @queue = :high

  def self.perform(start_date, end_date, company_id, stripe_account_id,
    requester_id, client_user_email)
    Reports::Revenues.start(start_date, end_date, company_id, requester_id)
  end
end
