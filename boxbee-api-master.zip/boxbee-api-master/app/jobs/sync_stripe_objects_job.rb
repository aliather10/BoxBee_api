class SyncStripeObjectsJob
  @queue = :default

  def self.perform
    Resque.enqueue(SyncStripeBalanceTransactionsJob)
    Resque.enqueue(SyncStripeChargesJob)
    Resque.enqueue(SyncStripeCustomersJob)
    Resque.enqueue(SyncStripeRefundsJob)
    Resque.enqueue(SyncStripeInvoicesJob)
    Resque.enqueue(SyncStripeInvoiceItemsJob)
  end
end
