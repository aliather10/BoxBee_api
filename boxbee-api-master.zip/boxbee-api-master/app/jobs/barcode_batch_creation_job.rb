class BarcodeBatchCreationJob
  @queue = :default

  def self.perform(quantity, user)
    barcodes = Barcode.generate(quantity, user['company_id'])
    csv_path = Barcode.make_csv(barcodes, user['company_id'])
    pdf_path = Barcode.make_pdf(barcodes, user['company_id'])
    BarcodeMailer.generated_barcodes_mailer(pdf_path, csv_path, user).deliver_now
  end
end
