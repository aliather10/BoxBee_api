class SyncStripeInvoiceItemsJob
  @queue = :default

  def self.perform
    Company.all.each do |company|
      api_key = company.apply_stripe_api_key
      if api_key
        InvoiceItem.sync(company.id)
      end
    end
  end
end
