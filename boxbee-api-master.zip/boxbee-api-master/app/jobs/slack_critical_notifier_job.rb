class SlackCriticalNotifierJob
  @queue = :default

  def self.perform
    percent_mem_used = (REDIS.info['used_memory'].to_f / Figaro.env.REDISTOGO_MAX_MEM.to_f) * 100
    if Figaro.env.REDISTOGO_MAX_MEM
      if percent_mem_used > 60 && percent_mem_used <= 90 
        SLACK_CRITICAL_NOTIFIER.ping "*WARNING:* REDIS is currently using #{percent_mem_used}% of available memory (Max: #{Figaro.env.REDISTOGO_MAX_MEM.to_f / 1000000} MB). Please upgrade capacity."
      elsif percent_mem_used > 90
        SLACK_CRITICAL_NOTIFIER.ping "*CRITICAL WARNING:* REDIS is currently using #{percent_mem_used}% of available memory (Max: #{Figaro.env.REDISTOGO_MAX_MEM.to_f / 1000000} MB). Please upgrade capacity."
      end
    end
  end
end
