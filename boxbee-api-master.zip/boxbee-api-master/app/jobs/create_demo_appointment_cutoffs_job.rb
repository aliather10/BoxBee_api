class CreateDemoAppointmentCutoffsJob
  @queue = :default

  def self.perform(product_id)
    # Generate some basic appointment cutoffs for demo purposes
    product = Product.find(product_id)
    creation_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :creation)
    modification_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :modification,
      lead_time: creation_cutoff.lead_time)
    cancellation_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :cancellation)
  end
end
