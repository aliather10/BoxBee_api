class DeleteSearchSuggestionIndexJob
  @queue = :default

  def self.perform(model_name, object_id, company_id)
    SearchSuggestion.delete_indices(model_name, object_id, company_id)
  end
end
