class StripeWebhookSyncJob
  @queue = :default

  # Store new or modified Stripe objects locally
  # Notice that Stripe doesn't create a webhook for each of these events below.
  #A better practice is to trigger syncing of related objects to the original object
  #E.g. if charge or refund is generated, sync the corresponding balance transaction
  def self.perform(stripe_object_id, stripe_account_id)
    company = Company.find_by_stripe_account_id(stripe_account_id)
    if company
      if company.products.first.status == 'active'
        Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
      else
        Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
      end
      case stripe_object_id[0..1]
      when 'tx'
        BalanceTransaction.save_or_replace(stripe_object_id, stripe_account_id)
      when 'ch'
        Charge.save_or_replace(stripe_object_id, stripe_account_id)
        # when 'cu'
        # Customer.save_or_replace(stripe_object_id, stripe_account_id)
      when 're'
        Refund.save_or_replace(stripe_object_id, stripe_account_id)
      when 'in'
        Invoice.save_or_replace(stripe_object_id, stripe_account_id)
        Resque.enqueue(SearchSuggestionIndexJob, 'invoice', stripe_object_id, company.id)
      when 'ii'
        InvoiceItem.save_or_replace(stripe_object_id, stripe_account_id)
      else
        puts "no relevant Stripe objects to store locally from webhook"
      end
    end
  end
end
