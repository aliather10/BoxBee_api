class SyncStripeChargesJob
  @queue = :default

  def self.perform
    Company.all.each do |company|
      api_key = company.apply_stripe_api_key
      if api_key
        Charge.sync(company.id)
      end
    end
  end
end
