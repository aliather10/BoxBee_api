class DeleteSubdomainJob
  @queue = :default

  def self.perform(subdomain)
    Onboarding.delete_subdomain(subdomain)
  end
end
