class SearchSuggestionIndexJob
  @queue = :default

  def self.perform(model_name, object_id, company_id)
    case model_name
      when 'customer'
        customer = Customer.find(object_id)
        SearchSuggestion.index_customer_name(customer, company_id)
      when 'invoice'
        invoice = Invoice.by_company(company_id).select{|inv| inv ? inv['id'] == object_id : false}.first
        SearchSuggestion.index_invoice(invoice, company_id)
      when 'location'
        location = Location.find(object_id)
        SearchSuggestion.index_location_name(location, company_id)
      when 'appointment'
        appointment = Appointment.find(object_id)
        SearchSuggestion.index_appointment(appointment, company_id)
      when 'barcode'
        customer_item = CustomerItem.find(object_id)
        SearchSuggestion.index_barcode(customer_item, company_id)
    end
  end
end
