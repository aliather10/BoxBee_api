class CreateFutureSlotsJob
  @queue = :default

  def self.perform(duration, override_time_check = false, product_id = nil)
    #Will generate slots over the duration specified. Should be run before midnight
    #Unless it's for a brand new company
    #Iterate through each client
    if product_id
      Product.find(product_id).service_areas.each do |sa|
        Slot.create_future_slots_by_service_area(sa, duration, override_time_check)
      end
    else
      Slot.create_future_slots(duration, override_time_check)
    end
  end
end
