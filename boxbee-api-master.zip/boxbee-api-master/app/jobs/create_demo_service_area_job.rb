class CreateDemoServiceAreaJob
  @queue = :default

  def self.perform(city, state, country, company_id)
    puts "starting create demo service area job"
    service_area = FactoryGirl.create(:service_area, company_id: company_id,
      name: city)
    latlong = Seeding::Mapbox.latlong_from_city(city, state, country)
    time_zone = nil
    begin
      time_zone = Timezone.lookup(latlong[1], latlong[0]).name
    rescue
      time_zone = 'America/New_York' # Change this to your default Time Zone 
    end
    puts "time_zone #{time_zone}"
    service_area.time_zone; service_area.save!
    Company.find(company_id).products.first.service_areas += [service_area]
    zips = Seeding::Mapbox.generate_zips(city, state, country)
    zips.each do |zip|
      FactoryGirl.create(:service_area_zip, service_area: service_area, zip: zip)
    end
  end
end
