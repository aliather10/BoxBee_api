class UpdateAppointmentStatusJob
  @queue = :default

  def self.perform(appointment_id)
    AppointmentCutoff.move_appointment_to_confirmed(appointment_id)
  end
end
