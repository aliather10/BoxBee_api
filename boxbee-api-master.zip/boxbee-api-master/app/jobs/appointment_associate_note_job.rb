class AppointmentAssociateNoteJob
  @queue = :default

  def self.perform(note = nil, address_note_option_id = nil, company_id, appointment, created_by)
    raise "Note and address_note_option_id cannot both be nil. One or the other must be provided" if note.nil? && address_note_option_id.nil?
    if address_note_option_id
      note = AddressNoteOption.where(company_id: company_id).find(address_note_option_id).note
    end
    appointment_note = AppointmentNote.where(note: note, appointment_id: appointment['id']).first
    if appointment_note
      appointment_note.note = note;
    else
      appointment_note = AppointmentNote.create(note: note, created_by: created_by,
        modified_by: created_by)
    end
    appointment_note.appointment_id = appointment['id']
    appointment_note.save!
  end
end
