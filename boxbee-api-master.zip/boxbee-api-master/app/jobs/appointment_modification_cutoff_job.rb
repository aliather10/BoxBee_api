class AppointmentModificationCutoffJob
  @queue = :default

  def self.perform
    appointments = Appointment.where(status: 'scheduled')
    appointments.each do |appointment|
      product = appointment.customer.product
      modification_cutoff = product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types[:modification]).first

      time_zone = ServiceArea.by_product(product.id)
        .by_zip(Address.find(appointment.address_id).zip_code.to_s).first.time_zone
      Time.use_zone(time_zone) do
        if appointment.window_start_datetime <= modification_cutoff.lead_time.hours.from_now
          Resque.enqueue(UpdateAppointmentStatusJob, appointment.id)
        end
      end
    end
  end
end
