class CreateBillingDetailsJob
  @queue = :default

  def self.perform(customer_id, stripe_token)
    #Create a stripe customer using the token, and put the ID in the customers table
    Customer.find(customer_id).create_and_associate_stripe_customer(stripe_token)
  end
end
