class IndexSearchJob
  @queue = :default

  def self.perform
    #Indexes customers, appointments, and invoices.
    SearchSuggestion.index_main
  end
end
