class SlackFailedResqueNotifierJob
  @queue = :default

  def self.perform
    if Figaro.env.SLACK_PREVIEW_SIGNUP_URL
      unless Resque::Failure.all(0, -1).empty?
        SLACK_CRITICAL_NOTIFIER.ping "*WARNING:* Background tasks have failed in Resque. Please open up https://developers.boxbee.com/resque/overview to learn more"
      end
    end
  end
end
