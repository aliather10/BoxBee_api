class AppointmentSyncContactDetailsJob
  @queue = :default

  def self.perform(appointment_id)
    appointment = Appointment.find(appointment_id)
    customer = Customer.find_by_id(appointment.customer_id)
    if customer
      contact_details = customer.user.contact_details.select{|cd| cd.mode_key == 'phone' && cd.mode_value == appointment['preferred_phone']}
      if contact_details.empty?
        primary_communication_id = ContactDetail.create!(user_id: customer.user_id, mode_key: :phone,
                                                       mode_value: appointment['preferred_phone'],
                                                       created_by: 1, modified_by: 1).id
      end
    end
  end
end
