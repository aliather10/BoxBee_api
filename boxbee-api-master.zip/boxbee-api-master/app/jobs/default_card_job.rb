class DefaultCardJob
  @queue = :default

  def self.perform(customer_id, default_card)
    customer = Customer.find(customer_id)
    user_id = customer.user_id
    product_id = customer.product_id
    company_id = customer.product.company_id
    stripe_account_id = Company.find(company_id).stripe_account_id
    stripe_customer = customer.stripe_customer
    stripe_customer.default_source = default_card
    stripe_customer.save
  end
end
