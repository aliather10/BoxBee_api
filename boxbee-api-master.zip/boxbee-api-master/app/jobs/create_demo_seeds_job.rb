class CreateDemoSeedsJob
  @queue = :default

  def self.perform(product_id, duration, override_time_check)
    #Generate seeds for demo
    ##Appointment cutoffs
    Resque.enqueue(CreateDemoAppointmentCutoffsJob, product_id)
    ##Slots
    Resque.enqueue(CreateFutureSlotsJob, 3.months, true, product_id)
  end
end
