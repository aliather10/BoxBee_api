class DemoRouteSimulatorJob
  @queue = :default

  def self.perform(company_id, time)
    #Runs route simulator in the background
    key = "demo_route_simulator:company:#{company_id}"
    REDIS.hmset(key, "status", "in_progress")
    datetime = DateTime.strptime("#{time}", "%s")
    Seeding::Simulator.run_routes(company_id, datetime)
    REDIS.hmset(key, "status", "completed", "completed_time", time)
  end
end
