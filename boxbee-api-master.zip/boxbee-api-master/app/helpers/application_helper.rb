module ApplicationHelper
  def convert_hhmm_to_sec(hhmm)
    hhmm[0..1].to_i*3600 + hhmm[2..3].to_i*60
  end

  def apply_prices_to_customer_fee(customer_fee, product)
    customer_fee.empty_delivery_price = product.empty_delivery_price
    customer_fee.packed_pickup_price = product.packed_pickup_price
    customer_fee.packed_delivery_price = product.packed_delivery_price
    customer_fee.empty_pickup_price = product.empty_pickup_price
    return customer_fee
  end

  def apply_prices_to_history(history, product)
    history.empty_delivery_price = product.empty_delivery_price
    history.packed_pickup_price = product.packed_pickup_price
    history.packed_delivery_price = product.packed_delivery_price
    history.empty_pickup_price = product.empty_pickup_price
    return history
  end

end
