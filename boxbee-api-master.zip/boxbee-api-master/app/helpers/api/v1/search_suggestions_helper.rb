module Api::V1::SearchSuggestionsHelper
end
