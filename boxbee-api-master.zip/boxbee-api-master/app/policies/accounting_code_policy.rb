class AccountingCodePolicy < ApplicationPolicy
  def index?
    user.admin? || user.super_user?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
