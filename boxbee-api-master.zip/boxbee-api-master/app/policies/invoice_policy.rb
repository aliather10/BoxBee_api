class InvoicePolicy < Struct.new(:user, :invoice)
  def show?
    user.customer? || user.customer_service? || user.admin?
  end

  def customer?
    show?
  end

  def index?
    user.customer_service? || user.admin?
  end

  def pay?
    index? || user.customer?
  end
end
