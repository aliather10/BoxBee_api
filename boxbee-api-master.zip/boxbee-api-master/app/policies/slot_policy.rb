class SlotPolicy < ApplicationPolicy
  def month?
    true
  end

  def date?
    true
  end

  def reserve?
    true
  end
end
