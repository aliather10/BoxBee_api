class CardPolicy < Struct.new(:user, :card)
  def create?
    true
  end

  def show?
    create?
  end

  def index?
    create?
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def customer?
    user.customer_service?
  end
end
