class AppointmentPolicy < ApplicationPolicy
  def create?
    user.customer? || user.customer_service? || user.admin?
  end

  def show?
    create?
  end

  def update?
    create?
  end

  def customer?
    user.admin? || user.customer?
  end

  def index?
    user.customer_service? || user.admin? || user.super_user?
  end

  def product?
    index?
  end

  def update_sort_order?
    create? || user.supervisor?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.customer_service? || user.admin? || user.ground_staff?
        scope.by_company(user.company.id)
      else
        scope.by_user(user.id)
      end
    end
  end
end
