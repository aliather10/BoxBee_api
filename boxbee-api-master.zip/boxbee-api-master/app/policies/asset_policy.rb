class AssetPolicy < ApplicationPolicy
  def create?
    true
  end

  def destroy?
    true
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.customer_service?
        scope.by_company(user.company.id)
      else
        scope.by_user(user.id)
      end
    end
  end
end
