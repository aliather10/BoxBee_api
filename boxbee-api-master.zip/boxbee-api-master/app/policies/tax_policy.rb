class TaxPolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def index?
    create?
  end

  def product?
    true
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
