class ItemTypePolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def update?
    create?
  end

  def show?
    create?
  end

  def destroy?
    create?
  end

  def index?
    create?
  end

  def plan?
    true
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
