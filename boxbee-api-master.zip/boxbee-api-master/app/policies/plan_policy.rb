class PlanPolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def show?
    true
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def index?
    true
  end

  def product?
    true
  end

  def mass_update?
    create?
  end

  def available_item_types?
    create?
  end

  def toggle_plans
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
