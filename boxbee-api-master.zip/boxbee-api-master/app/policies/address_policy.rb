class AddressPolicy < ApplicationPolicy
  def create?
    true
  end

  def index?
    true
  end

  def update?
    true
  end

  def show?
    true
  end

  def destroy?
    true
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.customer_service? || user.admin?
        scope.by_company(user.company.id)
      else
        scope.by_user(user.id)
      end
    end
  end
end
