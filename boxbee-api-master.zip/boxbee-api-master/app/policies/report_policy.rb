class ReportPolicy < Struct.new(:user, :report)
  def revenues?
    user.admin? || user.super_user?
  end
end
