class RoutePolicy < ApplicationPolicy
  def create?
    user.supervisor? || user.admin?
  end

  def show?
    user.ground_staff? || user.supervisor? || user.admin?
  end

  def update?
    create? || user.ground_staff?
  end

  def destroy?
    create?
  end

  def company?
    show?
  end

  def driver?
    show?
  end

  def simulate?
    user.admin?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
