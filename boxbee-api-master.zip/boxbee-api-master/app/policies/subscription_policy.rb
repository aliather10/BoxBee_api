class SubscriptionPolicy < ApplicationPolicy
  def update?
    user.customer_service?
  end

  def show?
    true
  end

  def customer?
    true
  end

  def plan?
    user.customer_service?
  end

  def product?
    user.customer_service?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.customer_service?
        scope.by_company(user.company.id)
      else
        scope.by_user(user.id)
      end
    end
  end
end
