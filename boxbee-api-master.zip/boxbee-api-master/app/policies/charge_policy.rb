class ChargePolicy < Struct.new(:user, :charge)
  def show?
    user.customer_service?
  end
end
