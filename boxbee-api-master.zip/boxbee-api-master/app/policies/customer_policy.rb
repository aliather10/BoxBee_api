class CustomerPolicy < ApplicationPolicy
  def create?
    true
  end

  def update?
    create?
  end

  def show?
    true
  end

  def product_user?
    index?
  end

  def index?
    user.admin? || user.customer_service?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.customer_service? || user.admin?
        scope.by_company(user.company.id)
      else
        scope.by_user(user.id)
      end
    end
  end
end
