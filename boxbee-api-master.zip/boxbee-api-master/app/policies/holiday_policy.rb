class HolidayPolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def index?
    create?
  end

  def update?
    create?
  end

  def show?
    create?
  end

  def destroy?
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.admin?
        scope.by_company(user.company.id)
      end
    end
  end
end
