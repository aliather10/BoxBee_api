class AppointmentCutoffPolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def update?
    create?
  end

  def show?
    create?
  end

  def product?
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
