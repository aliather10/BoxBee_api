class UserPolicy < ApplicationPolicy
  def show?
    true
  end

  def update?
    user.customer? || user.admin? || user.customer_service?
  end

  def check_email?
    true
  end

  def create?
    true
  end

  def new?
    create?
  end

  def index?
    user.admin? || user.super_user?
  end

  def drivers?
    user.supervisor? || index?
  end

  def destroy?
    user.admin?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      elsif user.admin? || user.supervisor? || user.customer_service?
        scope.by_company(user.company.id)
      else
        scope.where(id: user)
      end
    end
  end
end
