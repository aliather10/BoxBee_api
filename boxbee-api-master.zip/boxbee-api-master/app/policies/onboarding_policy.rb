class OnboardingPolicy < Struct.new(:user, :onboarding)
  def available_item_types?
    true
  end

  def new?
    true
  end

  def register?
    true
  end

  def cancel?
    true
  end

  def send_sms_to_mobile?
    true
  end

  def launch_product?
    user.admin?
  end

  def launch_demo?
    user.admin?
  end

  def request_invite?
    user.admin?
  end

  def setup?
    user.admin?
  end

  def checklist_progress?
    user.admin?
  end
end
