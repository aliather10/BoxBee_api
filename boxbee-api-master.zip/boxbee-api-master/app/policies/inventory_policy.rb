class InventoryPolicy < ApplicationPolicy
  def create?
    user.ground_staff? || user.supervisor?
  end

  def update?
    create?
  end

  def destroy?
    create?
  end

  def customer_item?
    create?
  end

  def container?
    create?
  end

  def move_to_staging?
    create?
  end

  def move_to_storage?
    create?
  end

  def load_cart?
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
