class CompanyPolicy < ApplicationPolicy
  def create?
    user.admin?
  end

  def show?
    create?
  end

  def update?
    user.admin?
  end

  def index?
    user.super_user?
  end

  def get_global_settings?
    user.admin?
  end

  def update_global_settings?
    get_global_settings?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_user(user.id)
      end
    end
  end
end
