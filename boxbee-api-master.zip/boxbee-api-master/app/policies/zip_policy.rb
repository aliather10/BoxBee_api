class ZipPolicy < ApplicationPolicy
  def current_product?
    true
  end
end
