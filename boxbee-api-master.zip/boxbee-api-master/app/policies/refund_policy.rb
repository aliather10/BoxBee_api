class RefundPolicy < Struct.new(:user, :refund)
  def create?
    user.customer_service? || user.admin?
  end
end
