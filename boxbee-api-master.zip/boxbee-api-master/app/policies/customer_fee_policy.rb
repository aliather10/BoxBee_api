class CustomerFeePolicy < ApplicationPolicy
  def create?
    user.super_user?
  end

  def user?
    create?
  end

  def appointment?
    create?
  end

  def update?
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
