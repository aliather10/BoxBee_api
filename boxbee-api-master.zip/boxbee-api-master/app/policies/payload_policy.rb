class PayloadPolicy < ApplicationPolicy
  def create?
    user.supervisor? || user.admin? || user.ground_staff?
  end

  def show?
    update?
  end

  def update?
    create?
  end

  def destroy?
    user.supervisor?
  end

  def company?
    user.super_user?
  end

  def route?
    update?
  end

  def unload_van?
    update?
  end

  def mass_assign_barcodes?
    create?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
