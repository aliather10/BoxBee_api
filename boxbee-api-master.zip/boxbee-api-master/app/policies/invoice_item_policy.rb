class InvoiceItemPolicy < Struct.new(:user, :invoice_item)
  def show?
    user.customer_service? || user.admin?
  end

  def index?
    show?
  end
end
