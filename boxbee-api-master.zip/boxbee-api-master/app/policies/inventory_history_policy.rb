class InventoryHistoryPolicy < ApplicationPolicy
  def user?
    user.supervisor?
  end

  def location?
    user.supervisor?
  end

  def customer_item?
    user.supervisor?
  end

  def item_type?
    user.supervisor?
  end

  def appointment?
    user.supervisor?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
