class BarcodePolicy < ApplicationPolicy
  def create?
    user.supervisor? || user.admin?
  end

  def index?
    create? || user.ground_staff? 
  end

  def change?
    create? || user.ground_staff?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
