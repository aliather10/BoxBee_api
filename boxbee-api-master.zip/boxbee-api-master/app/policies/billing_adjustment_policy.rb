class BillingAdjustmentPolicy < Struct.new(:user, :billing_adjustment)
  def create?
    user.customer_service? || user.admin?
  end
end
