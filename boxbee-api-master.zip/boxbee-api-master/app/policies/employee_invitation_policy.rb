class EmployeeInvitationPolicy < ApplicationPolicy
  def new?
    user.admin?
  end

  class Scope < ApplicationPolicy::Scope
    def resolve
      if user.super_user?
        scope.all
      else
        scope.by_company(user.company.id)
      end
    end
  end
end
