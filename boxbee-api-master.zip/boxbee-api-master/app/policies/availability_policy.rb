class AvailabilityPolicy < Struct.new(:user, :availability)
  def zip?
    true
  end

  def host?
    true
  end
end
