class BarcodeMailer < ApplicationMailer
  default from: 'api@boxbee.com'

  def generated_barcodes_mailer(pdf_path, csv_path, user)
    @user = user
    @csv_path = csv_path
    @pdf_path = pdf_path

    #format: attachments[filename] = path/to/file
    attachments["#{@csv_path.split('/').last}"] = open(@csv_path).read
    attachments["#{@pdf_path.split('/').last}"] = open(@pdf_path).read
    mail( to: @user.email,
      subject: '[Boxbee Warehouse Management] Your requested barcodes are now ready'
    )
  end
end
