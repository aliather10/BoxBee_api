class CompanyMailer < ApplicationMailer
  default :from => 'hello@boxbee.com'
  layout 'company_mailer'


  def card_declined(customer, invoice_of_charge)
    @charge = Charge.by_customer(customer.id).select{|charge| charge['id'] == invoice_of_charge['charge']}.first
    attach_card_logo(@charge['source']['brand'])
    @customer = customer
    @phone = @customer.user.contact_details.where(mode_key: ContactDetail.mode_keys[:phone]).first.mode_value
    @company = customer.user.company
    @invoice = invoice_of_charge
    @invoice_lines = []
    invoice_of_charge['lines']['data'].each do |line|
      quantity = line['quantity'] ||= 1
      amount = line['amount'] * 0.01
      @invoice_lines << {
          description: line['description'],
          fees: (amount / quantity).round(2),
          quantity: quantity,
          total: (quantity * amount).round(2)
      }
    end
    @total_fee = @invoice_lines.map{|line| line[:total]}.sum.to_i.round(2)
    @tax = (invoice_of_charge['lines']['data'].map{|line| line.dig('metadata', 'tax') ? line['metadata']['tax'] : 0}.sum.to_i * 0.01 ).round(2)
    add_inline_attachments!
    mail(
      to: @company.users.select{|u| u.admin?}.map(&:email),
      subject: "Credit Card Declined - #{@customer.user.full_name}"
    )
  end

  def revenue_report(recipient, csv_file, start_date, end_date, company_id)
    @recipient = User.find(recipient).email
    @csv_file = csv_file
    @start_date = start_date
    @end_date = end_date
    @company = Company.find(company_id)
    attachments["#{@csv_file.path.split('/').last}"] = open(@csv_file.url).read
    add_inline_attachments!
    mail(
        to: @recipient,
        subject: "Your Revenue Report"
    )
  end

  def employee_invitation(invitation)
    @invitation = invitation
    @company = invitation.company
    add_inline_attachments!
    mail(
        to: @invitation.email,
        subject: "Welcome to the #{@company.name} Team"
    )
  end

  def add_inline_attachments!
    logo_path
    attachments.inline[@attachment_file] = open(@url).read
  end

  def logo_path
    if @company.logo
      @url = @company.logo.url
    else
      @url = @company.products.first.logo_image_url.url
    end
    @attachment_file = @url.split('/').last
  end

  private
  def attach_card_logo(card_type)
    case card_type
      when 'Visa'
        attachments.inline['cc-logo.png'] = File.read('app/assets/images/visa.png')
      when 'American Express'
        attachments.inline['cc-logo.png'] = File.read('app/assets/images/amex.png')
      when 'Discover'
        attachments.inline['cc-logo.png'] = File.read('app/assets/images/discover.png')
      when 'MasterCard'
        attachments.inline['cc-logo.png'] = File.read('app/assets/images/mastercard.png')
    end
  end
end
