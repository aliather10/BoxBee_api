class BoxbeeMailer < ApplicationMailer
  before_action :add_boxbee_logo_inline!
  default :from => 'hello@boxbee.com'
  layout 'boxbee_home_mailer'

  def reset_password(customer, token)
    @customer = customer
    @product = @customer.product
    @token = token
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Please Reset Your Password"
    )
  end

  def unlock_account(customer, token)
    @customer = customer
    @product = @customer.product
    @token = token
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Please Reactivate Your Account"
    )
  end

  def go_live_mailer(company)
    @company = company
    mail(
        to: 'api@boxbee.com',
        subject: "A new company has requested to GO LIVE on Boxbee"
    )
  end

  def log_into_demo(company, password)
    @company = company
    @password = password
    mail(
        to: @company.users.first.email,
        subject: "Your Boxbee Preview Password - Please keep this email."
    )
  end
end
