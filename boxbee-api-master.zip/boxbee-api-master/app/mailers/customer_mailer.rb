class CustomerMailer < ApplicationMailer
  before_action :logo_path
  after_action :add_inline_attachments!
  default :from => 'hello@boxbee.com'
  layout 'company_mailer'


  def appointment_confirmation(appointment)
    @appointment = appointment
    @product = appointment.customer.product
    mail(
      to: @appointment.customer.preferred_email ||= @appointment.customer.user.email,
      subject: "Your Appointment Is Confirmed",
      from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def refund(refund, invoice, customer_id)
    @refund = refund
    @customer = Customer.find(customer_id)
    @product = customer.product
    @invoice = invoice
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Your Appointment Is Confirmed",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def first_appointment_confirmation(appointment)
    @appointment = appointment
    @product = appointment.customer.product
    mail(
        to: @appointment.customer.preferred_email ||= @appointment.customer.user.email,
        subject: "Welcome to #{@product.capitalize}",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def reset_password(customer, token)
    @customer = customer
    @product = @customer.product
    @token = token
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Please Reset Your Password",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def unlock_account(customer, token)
    @customer = customer
    @product = @customer.product
    @token = token
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Please Reactivate Your Account",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def appointment_cancellation(appointment)
    @appointment = appointment
    @product = appointment.customer.product
    mail(
        to: @appointment.customer.preferred_email ||= @appointment.customer.user.email,
        subject: "Your Appointment Is Canceled",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def appointment_completed(appointment)
    @appointment = appointment
    @product = appointment.customer.product
    mail(
        to: @appointment.customer.preferred_email ||= @appointment.customer.user.email,
        subject: "Your Appointment Has Been Completed",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def card_declined(card, customer)
    @customer = customer
    @card = card
    @product = @customer.product
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Your Credit Card Has Been Declined",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def invoice(invoice, customer)
    @customer = customer
    @product = @customer.product
    @invoice = invoice
    mail(
        to: @customer.preferred_email ||= @customer.user.email,
        subject: "Your Invoice",
        from: @product.company.contact_email ||= @product.company.users.select{|u| u.admin?}.first.email
    )
  end

  def add_inline_attachments!
    attachments.inline[@attachment_file] = File.read(@url)
  end

  def logo_path
    @url = "#{@product.logo_image_url.url}"
    @attachment_file = @url.split('/').last
  end
end
