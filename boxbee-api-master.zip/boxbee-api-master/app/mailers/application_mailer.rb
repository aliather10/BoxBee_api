class ApplicationMailer < ActionMailer::Base
  default from: "hello@boxbee.com"

  layout 'mailer'

  def add_boxbee_logo_inline!
    attachments.inline['boxbee-logo.png'] = File.read('app/assets/images/boxbee-logo.png')
  end
end
