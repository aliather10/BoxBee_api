class Api::V1::EmployeesController < Api::V1::UsersController
  swagger_controller :employees, "Manage employees"
  skip_before_action :authenticate_user, only: :create
  skip_after_action :verify_policy_scoped, only: [:new, :create]

  def create
    user = User.new(user_params.except(:address, :phone, :invitation_token))
    authorize user
    begin
      invitation = EmployeeInvitation.find_by_token(user_params[:invitation_token])
      user.company = invitation.company
      user.modified_by, user.created_by = invitation.created_by, invitation.modified_by
      invitation.roles.each {|role| user.add_role role}
      contact_detail = ContactDetail.create!(mode_key: ContactDetail.mode_keys[:phone],
        mode_value: user_params[:phone], user: user, created_by: invitation.created_by, modified_by: invitation.modified_by)
      address = Address.new((user_params[:address].except(:user_id)).merge({user: user,
        created_by: invitation.created_by, modified_by: invitation.modified_by}))
      if user.save!
        address.addressable_id = user.id
        address.addressable_type = 'User'
        render json: {status: 'SUCCESS', message: nil, data: user.detailed_object}, status: :ok
      end
    rescue => error
      user.destroy!
      invalid_request_or_unavailable(error)
    end
  end

  swagger_api :create do
    summary "Creates a new employee from an invitation token"
    notes "Permitted roles: admin"
    param :form, :invitation_token, :string, :required, "The invitation token originally sent to the employee via email when inviting to register"
    param :form, :first_name, :string, :required, "The first name of the user"
    param :form, :last_name, :string, :required, "The last name of the user"
    param :form, :email, :string, :required, "The user's email (for login). Can be omitted if invitation_token present."
    param :form, :password, :string, :required, "The user's password (for login). Must be at least 8 characters long"
    param :form, :password_confirmation, :string, :required, "Password confirmation"
    param :form, :address, :string, :optional, "A hash to construct the Address object (see Address#POST endpoint)"
    param :form, :phone, :string, :required, "A standard phone number (e.g. '555-555-5555')"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    user = policy_scope(User).find(user_params[:id])
    authorize user
    if user_params[:roles]
      added_roles = user_params[:roles] - user.roles_by_name
      removed_roles = user.roles_by_name - user_params[:roles]
      user = User.role_adjuster(user, added_roles, removed_roles)
    end
    if user_params[:phone]
      contact_detail = user.contact_details.where(mode_key: ContactDetail.mode_keys[:phone]).first
      contact_detail.update_attributes!(mode_value: user_params[:phone])
    end
    user.update_attributes!(user_params.slice(:first_name, :last_name, :email,
      :password, :password_confirmation))
    render json: {status: 'SUCCESS', message: nil, data: user.detailed_object.merge({modified_by: @user.id})}, status: :ok
  end

  swagger_api :update do
    summary "Updates a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the User to be updated. Can use 'current' for the current user"
    param :form, :first_name, :string, :optional, "The full URL of the company (e.g. http://storagesherpa.com)"
    param :form, :last_name, :string, :optional, "The primary contact's phone number"
    param :form, :email, :string, :optional, "Email used for login"
    param :form, :password, :string, :optional, "New password used for login"
    param :form, :password_confirmation, :string, :optional, "Retyped new password used for login"
    param :form, :roles, :string, :optional, "An array of roles to be added, format: '[warehouse_staff, driver]'"
    param :form, :phone, :string, :optional, "The contact number for the employee"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def new
    invitation = EmployeeInvitation.new(email: user_params[:email],
      company: @user.company)
    authorize invitation
    invitation.roles = user_params[:roles]
    invitation.modified_by, invitation.created_by = @user.id, @user.id
    if invitation.save!
      CompanyMailer.employee_invitation(invitation).deliver_now
      render json: {status: 'SUCCESS', message: nil, data: invitation}, status: :ok
    end
  end

  swagger_api :new do
    summary "Creates an invitation record and sends an email invitation to a new user"
    notes "This is usually reserved for employees and should not be used for customers."
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :email, :string, :required, "Email e.g. 'abc@xyz.com'"
    param :form, :roles, :string, :required, "An array of roles e.g. '[supervisor, driver]'. Enums available: 'admin', 'customer_service', 'supervisor', 'driver', 'warehouse_staff', 'customer'"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    users = policy_scope(User)
    users = users.by_company(user_params[:company_id]) if user_params[:company_id]
    authorize users
    employees = users.select do |user|
      !(user.roles_by_name & %w{customer_service supervisor driver warehouse_staff}).empty?
    end
    employees = !employees.empty? ? employees : []
    render json: {status: 'SUCCESS', message: nil, data: employees.map(&:detailed_object)},
        status: :ok
  end

  swagger_api :index do
    summary "Retrieves all employees for a company"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    param :query, :company_id, :integer, :optional, "Super users (roles: :system, :boxbee) may specify a company ID explicitly. All other level of users may not specify. Instead the company ID is inferred from the user token."
    response :ok
    response :not_found
    response :unauthorized
  end

  def drivers
    users = policy_scope(User)
    authorize users
    drivers = users.select do |user|
      user.has_role? :driver
    end
    drivers = !drivers.empty? ? drivers.paginate(page: page) : []
    render json: {status: 'SUCCESS', message: nil, data: drivers.map(&:detailed_object)},
        status: :ok
  end

  swagger_api :drivers do
    summary "Retrieves all drivers for a company"
    notes "Permitted roles: admin, supervisor, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    param :query, :company_id, :integer, :optional, "Super users (roles: :system, :boxbee) may specify a company ID explicitly. All other level of users may not specify. Instead the company ID is inferred from the user token."
    response :ok
    response :not_found
    response :unauthorized
  end

  def destroy
    user = policy_scope(User).find(user_params[:id])
    authorize user
    user.destroy!
    render json: {status: 'SUCCESS', message: nil, data: user}, status: :ok
  end

  swagger_api :destroy do
    summary "Deletes a user"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the User to be deleted."
    response :ok
    response :not_found
    response :unauthorized
  end
end
