class Api::V1::SlotsController < ApiController
  skip_before_action :authenticate_user
  skip_after_action :verify_policy_scoped
  swagger_controller :slots, "The slot engine: returns available slots by date and month, reserves and confirms slots"

  def month
    unavailable_days = Slot.unavail_slots_by_month(slot_params[:month].to_i, slot_params[:year].to_i, current_product, slot_params[:zip_code])
    authorize Slot.all
    if !unavailable_days.empty?
      render json: {status: 'SUCCESS', message: nil, data: {unavailable_days: unavailable_days,
        time_zone: time_zone, utc_offset: utc_offset(time_zone)}}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :month do
    summary "Lists all the days in a chosen month that are NOT available"
    param :query, :month, :string, :required, "The month to be checked, expressed as 'mm'"
    param :query, :year, :string, :required, "The year to be checked, expressed as 'YYYY'"
    param :query, :zip_code, :string, :required, "The zip code"
    response :ok
    response :not_found
    response :unauthorized
  end

  def date
    date = slot_params[:date]
    date_to_check = DateTime.strptime("#{date}", "%s")
    slots = Slot.avail_slots_by_date(date_to_check, current_product, slot_params[:zip_code])
    authorize Slot.all
      render json: {status: 'SUCCESS', message: nil, data: {slots: slots, time_zone: time_zone,
        utc_offset: utc_offset(time_zone)}}, status: :ok
  end

  swagger_api :date do
    summary "Lists all the slots for a chosen date with available: true/false status"
    param :query, :date, :integer, :required, "The date to be checked, expressed as a UNIX timestamp"
    param :query, :zip_code, :string, :required, "The zip code to be checked"
    response :ok
    response :not_found
    response :unauthorized
  end

  def reserve
    slot = Slot.by_product(current_product.id).find(slot_params[:id])
    authorize slot
    # When a new reservation is made, the old one for that email needs to be erased (if within the temp session window)
    AppointmentHold.delete_existing_holds(slot_params[:email])
    hold = AppointmentHold.new(slot.id, slot_params[:email])
    hold_id = hold.reserve
    if hold_id
      render json: {status: 'SUCCESS', message: 'Successfully created temporary hold (good for the next 10 minutes)',
        data: {appointment_hold_id: hold_id}}, status: :ok
    end
  end

  swagger_api :reserve do
    summary "Reserves a chosen time slot"
    notes "The system will then keep the slot reserved for the next 10 min. If a new slot is chosen, the existing one gets deleted."
    param :form, :id, :integer, :required, "The ID of the slot to be reserved"
    param :form, :email, :string, :required, "The email of the user to make the reservation for"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def slot_params
    params.permit(:id, :year, :month, :date, :temp_reservation_id, :email, :zip_code)
  end

  def time_zone
    ServiceArea.by_product(current_product.id).by_zip(slot_params[:zip_code]).first.time_zone
  end

  def utc_offset(time_zone)
    Time.now.in_time_zone(time_zone).utc_offset/3600
  end
end
