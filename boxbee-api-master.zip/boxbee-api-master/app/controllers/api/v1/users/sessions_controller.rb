class Api::V1::Users::SessionsController < ApiController
  skip_before_action :authenticate_user
  skip_after_action :verify_authorized #for Pundit
  skip_after_action :verify_policy_scoped #for Pundit

  swagger_controller :sessions, "Token based session authentication"

  def create
    user = auth_user_by_email
    if user
      # unless url_to_host(request.headers['HTTP_ORIGIN']) == url_to_host(Figaro.env.DEFAULT_ADMIN_PORTAL_URL) && !user.has_role? :customer
      TRACKER.people.increment(user.id, {no_of_logins: 1})
      if user.has_role? :customer
        customer = Customer.by_product(current_product.id).find_by_user_id(user.id)
        render json: {status: 'SUCCESS', message: nil, data: {user: user.detailed_object.merge({customer: customer})}}, status: :ok
      else
        if user.company.products.empty?
          render json: {status: 'SUCCESS', message: nil, data: {user: user}}, status: :ok
        else
          render json: {status: 'SUCCESS', message: nil, data: {user: user.detailed_object}}, status: :ok
        end
      end
    end
  end

  swagger_api :create do
    summary "Returns a user object with session token for a valid email and password combination."
    notes "Up to 10 failed attempts per hour per user are allowed. It is up to the frontend to further authorize based on role"
    param :form, :email, :string, :required, "abc@xyz.com"
    param :form, :password, :string, :required, "plain password"
    response :ok
    response :unauthorized
  end

  private
  def auth_user_by_email
    user = User.find_by_email(user_params[:email])

    if user && user.valid_password?(user_params[:password])
      user.update_attribute(:failed_attempts, 0) unless user.failed_attempts.zero?
      return user
    end
    return unauthorize
  end

  def user_params
    params.permit(:email, :password)
  end
end
