class Api::V1::Users::PasswordsController < Devise::PasswordsController
  skip_before_action :verify_authenticity_token
  skip_after_action :verify_authorized #for Pundit
  skip_after_action :verify_policy_scoped #for Pundit

  rescue_from NoMethodError, :with => :invalid_request
  swagger_controller :passwords, "For resetting passwords"

  #Submit email to a receive a reset password email
  def create
    user = User.find_by_email(password_params[:email])
    user.send_reset_password_instructions
    if successfully_sent?(user)
      render json: {status: 'SUCCESS', message: "An email has been sent", data: nil}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end

  swagger_api :create do
    summary "Sends reset password instructions to the users email"
    param :form, :email, :string, :required, "abc@xyz.com"
    response :ok
    response :unauthorized
  end

  def update
    user = User.with_reset_password_token(password_params[:reset_password_token])
    User.reset_password_by_token(password_params)
    if user.errors.empty?
    user.unlock_access! if unlockable?(user)
      render json: {status: 'SUCCESS', message: nil, data: user}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end

  swagger_api :update do
    summary "Updates a user's password and returns the user object with user token for immediate login."
    notes "Requires the reset password token, password, and password combination. If the account is locked, a successful transaction will unlock it."
    param :form, :reset_password_token, :string, :required, "This will be provided in the user's email that has the reset password instructions"
    param :form, :password, :string, :required, "plain password"
    param :form, :password_confirmation, :string, :required, "plain password (repeat)"
    response :ok
    response :unauthorized
  end

  private
  def password_params
    params.permit(:email, :password, :password_confirmation, :reset_password_token)
  end

  def invalid_request(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "There is no data matching your request", error: exception.inspect}, status: :bad_request and return false
    Honeybadger.notify(exception)
  end
end
