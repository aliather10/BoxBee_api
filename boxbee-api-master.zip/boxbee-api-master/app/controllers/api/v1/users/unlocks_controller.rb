class Api::V1::Users::UnlocksController < Devise::UnlocksController
  skip_before_action :verify_authenticity_token
  skip_after_action :verify_authorized #for Pundit
  skip_after_action :verify_policy_scoped #for Pundit


  def create
    self.resource = resource_class.send_unlock_instructions(resource_params)
    yield resource if block_given?

    if successfully_sent?(resource)
      # respond_with({}, location: after_sending_unlock_instructions_path_for(resource))
      render json: {status: 'SUCCESS', message: nil,
        data: resource.merge({token: resource.token})}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end

  # GET /resource/unlock?unlock_token=abcdef
  def show
    self.resource = resource_class.unlock_access_by_token(params[:unlock_token])
    yield resource if block_given?

    if resource.errors.empty?
      # respond_with_navigational(resource){ redirect_to after_unlock_path_for(resource) }
      render json: {status: 'SUCCESS', message: nil,
        data: resource.merge({token: resource.token})}, status: :ok
    else
      # respond_with_navigational(resource.errors, status: :unprocessable_entity){ render :new }
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end
end
