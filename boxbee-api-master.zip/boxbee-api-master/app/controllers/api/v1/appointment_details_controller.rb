class Api::V1::AppointmentDetailsController < ApiController
  swagger_controller :appointment_details, "Detailed events occurring during an appointment"

  def appointment
    appointment_details = policy_scope(AppointmentDetail)
      .by_appointment(detail_params[:appointment_id])
    authorize appointment_details
    appointment_details = appointment_details.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: appointment_details,
      pagination: with_paging_info(appointment_details)}, status: :ok
  end

  swagger_api :appointment do
    summary "Lists all appointment details belonging to a specified appointment"
    notes "Warning: Only for system users"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :appointment_id, :integer, :required, "The appointment ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def detail_params
    params.permit(:appointment_id, :page)
  end
end
