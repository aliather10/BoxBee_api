class Api::V1::AccountingCodesController < ApiController
  swagger_controller :accounting_codes, "Manages accounting codes by product"

  def index
    accounting_codes = policy_scope(AccountingCode)
    authorize accounting_codes
    accounting_codes = accounting_codes.by_company(accounting_code_params[:company_id]) if @user.super_user? && accounting_code_params[:company_id]
    if accounting_code_params[:product_id]
      accounting_codes = accounting_codes.by_product(accounting_code_params[:product_id])
    end
      render json: {status: 'SUCCESS', message: nil, data: accounting_codes}, status: :ok
  end

  swagger_api :index do
    summary "Lists all AccountingCode records"
    notes "Permitted roles: customer_service, admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :company_id, :integer, :optional, "Company Id (only required if super user)"
    param :query, :product_id, :integer, :optional, "Product Id. If a product_id is provided, only the accounting codes for that product will be returned. Otherwise, all accounting codes for a client will be returned"
    response :ok
  end

  private
  #Use strong parameters for security
  def accounting_code_params
    params.permit(:id, :company_id, :product_id)
  end
end
