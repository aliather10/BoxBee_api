class Api::V1::ItemTypesController < ApiController
  swagger_controller :item_types, "Manages item types"

  def create
    item_type = policy_scope(ItemType).new(it_params.except(:company_id))
    authorize item_type
    item_type.company_id = @user.company_id
    item_type.image = decode_picture_data(it_params[:image]) if @user.company_id == 1
    item_type.created_by, item_type.modified_by = @user.id, @user.id
    if item_type.save!
      render json: {status: 'SUCCESS', message: nil, data: item_type.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new item type record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-user-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of this item type, displayed to the user"
    param :form, :requires_empty_delivery, :boolean, :required, "Whether or not the item type requires an empty delivery at the beginning of its customer lifecycle"
    param :form, :requires_empty_pickup, :boolean, :required, "Whether or not the item type requires an empty pickup at the end of its customer lifecycle"
    param :form, :appointment_limit_qty, :integer, :optional, "Max # of item types that can be ordered in one appointment."
    param :form, :image, :string, :optional, "Optional base64 image of the item type (only for company 1 (system user))"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    item_type = policy_scope(ItemType).find(it_params[:id])
    authorize item_type
    render json: {status: 'SUCCESS', message: nil, data: item_type.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a item type record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The item type ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    item_type = policy_scope(ItemType).find(it_params[:id])
    authorize item_type
    item_type.modified_by = @user.id
    if item_type.update_attributes!(it_params.except(:company_id))
      item_type = item_type.detailed_object
      render json: {status: 'SUCCESS', message: nil, data: item_type}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a item type record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The item type ID"
    param :form, :name, :string, :optional, "The name of this item type, displayed to the user"
    param :form, :requires_empty_delivery, :boolean, :optional, "Whether or not the item type requires an empty delivery at the beginning of its customer lifecycle"
    param :form, :requires_empty_pickup, :boolean, :optional, "Whether or not the item type requires an empty pickup at the end of its customer lifecycle"
    param :form, :appointment_limit_qty, :integer, :optional, "Max # of item types that can be ordered in one appointment."
    response :ok
    response :bad_request
    response :unauthorized
  end


  def destroy
    item_type = policy_scope(ItemType).find(it_params[:id])
    authorize item_type
    if item_type.destroy!
      render json: {status: 'SUCCESS', message: nil, data: item_type}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a item type record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-user-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The item type ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    item_types = policy_scope(ItemType)
    authorize item_types
    item_types = item_types.map(&:detailed_object).paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: item_types, pagination: with_paging_info(item_types)},
      status: :ok
  end

  swagger_api :index do
    summary "Lists all item types"
    notes "Permitted roles: admin"
    param :header, 'X-user-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def plan
    item_types = policy_scope(ItemType).by_plan(it_params[:plan_id])
    authorize item_types
    item_types = item_types.map(&:detailed_object).paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: item_types, pagination: with_paging_info(item_types)},
      status: :ok
  end

  swagger_api :plan do
    summary "Lists all item types for a given plan"
    notes "Permitted roles: all"
    param :path, :plan_id, :integer, :required, "The plan ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def it_params
    params.permit(:id, :name, :company_id, :requires_empty_pickup, :requires_empty_delivery,
      :wms_on_hand_qty, :min_threshold_qty, :appointment_limit_qty, :plan_id, :image)
  end
end
