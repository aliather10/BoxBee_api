class Api::V1::FaqsController < ApiController
  swagger_controller :faqs, "Manages FAQs for each product"

  def create
    faq = Faq.new(faq_params.except(:product_id))
    authorize faq
    faq.product = policy_scope(Product).find(faq_params[:product_id])
    if faq.save!
      render json: {status: 'SUCCESS', message: nil, data: faq}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new plan record for a product"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :product_id, :integer, :required, "The ID of the product that this question-answer pair belongs to"
    param :form, :question, :string, :required, "The text for the question"
    param :form, :answer, :text, :required, "The text for the answer"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    faq = policy_scope(Faq).find(faq_params[:id])
    authorize faq
    faq.product = policy_scope(Product).find(faq_params[:product_id]) if faq_params[:product_id]
    if faq.update_attributes!(faq_params)
      render json: {status: 'SUCCESS', message: nil, data: faq}, status: :ok
    end
  end

  swagger_api :update do
    summary "Creates a new plan record for a product"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The faq ID"
    param :form, :product_id, :integer, :optional, "The ID of the product that this question-answer pair belongs to"
    param :form, :question, :string, :optional, "The text for the question"
    param :form, :answer, :text, :optional, "The text for the answer"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    faq = policy_scope(Faq).find(faq_params[:id])
    authorize faq
    if faq.destroy!
      render json: {status: 'SUCCESS', message: nil, data: faq}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a faq record for a client"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The faq ID"
    param :query, :product_id, :integer, :required, "The ID of the product that this question-answer pair belongs to"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def faq_params
    params.permit(:id, :product_id, :question, :answer)
  end
end
