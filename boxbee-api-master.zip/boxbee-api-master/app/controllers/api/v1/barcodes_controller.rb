class Api::V1::BarcodesController < ApiController
  swagger_controller :barcodes, "Manages barcodes"
  skip_after_action :verify_policy_scoped, only: [:index]

  def create
    authorize policy_scope(Barcode).new
    Resque.enqueue(BarcodeBatchCreationJob, barcode_params[:quantity].to_i, @user)
    render json: {status: 'SUCCESS', message: 'Your barcodes are currently being created. Please check your email in a few moments to download the associated PDFs and CSV files', data: nil}, status: :ok
  end

  swagger_api :create do
    summary "Creates a batch of new barcodes and returns a printable PDF of the barcodes as well as a CSV"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :quantity, :integer, :required, "How many barcodes to generate for a client"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def index
    authorize Barcode.new
    barcodes = Barcode.terms_for(barcode_params[:search], @user.company_id)
    render json: {status: 'SUCCESS', message: nil, data: barcodes}, status: :ok
  end

  swagger_api :index do
    summary "Autocomplete search for barcodes indexed in the system"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :search, :string, :required, "A substring or complete string of the barcode to be searched"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def change
    authorize Barcode.new
    customer_item = policy_scope(CustomerItem).find_by_barcode(barcode_params[:old_barcode])
    customer_item.barcode = barcode_params[:new_barcode]
    customer_item.save!
    render json: {status: 'SUCCESS', message: 'Customer Item successfully updated with new barcode', data: customer_item}, status: :ok
  end

  swagger_api :change do
    summary "Assigns new barcode to an existing customer item"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :old_barcode, :string, :required, "The barcode to be replaced"
    param :form, :new_barcode, :string, :required, "The new barcode"
    response :ok
    response :unauthorized
    response :bad_request
  end

  private
  def barcode_params
    params.permit(:quantity, :search, :old_barcode, :new_barcode)
  end
end
