class Api::V1::AddressesController < ApiController
  swagger_controller :addresses, "Manages addresses belonging to customers and warehouses"

  def create
    address = policy_scope(Address).new(address_params.except(:address_note_option_id, :note, user_id))
    authorize address
    address.modified_by, address.created_by = @user.id, @user.id
    address.addressable_id = @user.customer_service? ? policy_scope(User).find(address_params[:user_id]).id : @user.id
    address.addressable_type = 'User'
    address.save!

    address_note = AddressNote.new(address: address, created_by: address.created_by,
      modified_by: address.modified_by)
    associate_address_note(address_note, address)
    render json: {status: 'SUCCESS', message: nil, data: address}, status: :ok
  end

  swagger_api :create do
    summary "Creates a new address record for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :user_id, :integer, :optional, "User Id of the customer. If not specified, system will assume it is for the requesting user (from the user_token). Thus if it is a company portal user, you must specify the user_id"
    param :form, :address1, :string, :required, "Street address line 1"
    param :form, :address2, :string, :optional, "Street address line 2"
    param :form, :address3, :string, :optional, "Street address line 3"
    param :form, :address4, :string, :optional, "Street address line 4"
    param :form, :alt_business_name, :string, :optional, "Business name if applicable"
    param :form, :city, :string, :required, "City"
    param :form, :state_name, :string, :required, "State name, e.g. 'Massachusetts'"
    param :form, :zip_code, :string, :required, "Zip code e.g. '90210-4545'"
    param :form, :country_name, :string, :required, "E.g. 'Germany'"
    param :form, :gps_latitude_point, :decimal, :optional, "The latitude coordinate"
    param :form, :gps_longitude_point, :decimal, :optional, "The longitudinal coordinate"
    param :form, :address_note_option_id, :integer, :optional, "ID of preconfigured address note options for a company. Either this parameter or note is REQUIRED."
    param :form, :note, :string, :optional, "A custom note that doesn't fall into one of the preconfigured address note options above. REQUIRED if you don't specify a address_note_option_id"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    addresses = policy_scope(Address)
    authorize addresses
    addresses = addresses.by_user(address_params[:customer_id]) if @user.customer_service? && address_params[:customer_id]
    customer = address_params[:customer_id] ? Customer.find_by_id(address_params[:customer_id]) : current_customer
    addresses = addresses.map(&:detailed_object)
    addresses = addresses.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil,
      data: {addresses: addresses, default_address: Address.find(customer.preferred_address_id)},
      pagination: with_paging_info(addresses)}, status: :ok
  end

  swagger_api :index do
    summary "Shows all address records for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :optional, "ID of the customer. If a customer himself is making the request, this parameter is not accepted"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def update
    address = policy_scope(Address).find(address_params[:id])
    authorize address
    address.update_attributes!(address_params.except(:address_note_option_id, :note)
      .merge({modified_by: @user.id}))
    address_note = AddressNote.where(address: address).first
    associate_address_note(address_note, address) if address_note
    render json: {status: 'SUCCESS', message: nil,
      data: address.detailed_object}, status: :ok
  end

  swagger_api :update do
    summary "Updates an address record for a user"
    notes "Permitted roles: all. WARNING: If blank parameters are passed, they will delete the corresponding fields in the record."
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Address to be updated"
    param :form, :address1, :string, :optional, "Street address line 1"
    param :form, :address2, :string, :optional, "Street address line 2"
    param :form, :address3, :string, :optional, "Street address line 3"
    param :form, :address4, :string, :optional, "Street address line 4"
    param :form, :alt_business_name, :string, :optional, "Business name if applicable"
    param :form, :city, :string, :optional, "City"
    param :form, :state_name, :string, :optional, "State name, e.g. 'Massachusetts'"
    param :form, :zip_code, :string, :optional, "Zip code e.g. '90210-4545'"
    param :form, :country_name, :string, :optional, "E.g. 'Germany'"
    param :form, :gps_latitude_point, :decimal, :optional, "The latitude coordinate"
    param :form, :gps_longitude_point, :decimal, :optional, "The longitudinal coordinate"
    param :form, :address_note_option_id, :integer, :optional, "ID of preconfigured address note options for a company. Either this parameter or note is REQUIRED."
    param :form, :note, :string, :optional, "A custom note that doesn't fall into one of the preconfigured address note options above. REQUIRED if you don't specify a address_note_option_id"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def show
    address = policy_scope(Address).find(address_params[:id])
    authorize address
    render json: {status: 'SUCCESS', message: nil, data: address.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves an address record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Address to be updated"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def destroy
    address = policy_scope(Address).find(address_params[:id])
    authorize address
    if address.destroy!
      render json: {status: 'SUCCESS', message: nil, data: address}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes an address record for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Address to be updated"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  private
  def address_params
    params.permit(:id, :page, :user_id, :address1, :address2, :address3, :address4,
      :city, :state_name, :state_code, :zip_code, :country_name, :country_code,
      :note, :address_note_option_id, :gps_latitude_point, :gps_longitude_point,
      :alt_business_name)
  end

  def associate_address_note(address_note, address)
    if address_params[:address_note_option_id]
      address_note.address_note_option = address.user.company.address_note_options
        .find(address_params[:address_note_option_id])
    elsif address_params[:note]
      address_note.address_note_option = address.user.company.address_note_options
        .where(note: 'custom').first
      address_note.note = address_params[:note]
    end
    address_note.save!
  end
end
