class Api::V1::RouteHistoriesController < ApiController
  swagger_controller :route_histories, "For viewing a breadcrumb trail history of routes"

  def route
    histories = policy_scope(RouteHistory).by_route(history_params[:route_id])
    authorize histories
    histories = histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: histories, pagination: with_paging_info(histories)}, status: :ok
  end

  swagger_api :route do
    summary "Lists all route transit histories by route ID"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :route_id, :integer, :required, "The ID of the route whose route transit histories are to be returned"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def company
    if history_params[:company_id] == 'current'
      histories = policy_scope(RouteHistory).by_company(current_company.id)
    else
      histories = policy_scope(RouteHistory).by_company(history_params[:company_id])
    end
    authorize histories
    histories = histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: histories,
      pagination: with_paging_info(histories)}, status: :ok
  end

  swagger_api :company do
    summary "Lists all route transit histories by a specified company ID"
    notes "Permitted roles: supervisor, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :company_id, :integer, :required, "The ID of the company whose route histories are to be returned. 'current' can be used for the id of the current company"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def history_params
    params.permit(:company_id, :history_key, :history_value, :previous_status,
      :current_status, :transit_event_id, :route_id, :page)
  end
end
