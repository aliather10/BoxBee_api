class Api::V1::ReportsController < Api::V1::StripeController
  skip_after_action :verify_authorized #for Pundit
  skip_after_action :verify_policy_scoped #for Pundit

  swagger_controller :reports, "Manages reports"

  #GET revenues table based on paramters: start/end date, product_id
  def revenues
    authorize :report, :revenues?
    company_id = @user.super_user? ? revenue_params[:company_id] : @user.company_id
    client_user_email = @user.super_user? ? Figaro.env.SYSTEM_EMAIL : @user['email']
    render json: {status: 'SUCCESS', message: 'In Progress. You will soon receive an email with the report.', data: nil}, status: :ok
    Resque.enqueue(RevenueReportJob, revenue_params[:start_date], revenue_params[:end_date],
      company_id, get_stripe_account_id(company_id), @user.id, client_user_email)
  end

  swagger_api :revenues do
    summary "Generates a report of financials in a given period, organized by product_id, and delivers it via CSV attachment in email after it finishes processing"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :company_id, :integer, :optional, "Id of company on which revenue report will be run (note this is only required for super users)"
    param :query, :start_date, :integer, :required, "Start date expressed as UNIX Timestamp (e.g. '1450760400' for 12/22/2015)"
    param :query, :end_date, :integer, :required, "End date (same as above)"
    response :ok
  end

  private
  #Use strong parameters for security
  def revenue_params
    params.permit(:company_id, :start_date, :end_date) #unix time stamps, non inclusive (midnight to midnight). (e.g. 1/1/15-2/1/15 should be used for mo. of Jan.)
  end
end
