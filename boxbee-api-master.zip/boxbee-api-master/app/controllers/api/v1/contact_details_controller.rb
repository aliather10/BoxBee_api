class Api::V1::ContactDetailsController < ApiController
  swagger_controller :contact_details, "A users' contact details (phone, email, etc.)"

  def create
    contact_detail = ContactDetail.new(comm_params)
    authorize contact_detail
    contact_detail.modified_by, contact_detail.created_by = @user.id, @user.id
    if contact_detail.save!
      render json: {status: 'SUCCESS', message: nil, data: contact_detail}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new contact_detail record for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :user_id, :integer, :optional, "User Id of the customer. If not specified, system will assume it is for the requesting user (from the user_token). Thus if it is a client portal user, you must specify the user_id"
    param :form, :mode_key, :string, :required, "Mode of contact_detail, can be: 'phone', 'email'"
    param :form, :mode_value, :string, :required, "A string for the mode selected above (e.g. for 'call' it would be '555-555-5555', 'email' would be the email address, and so on.)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    contact_detail = policy_scope(ContactDetail).find(comm_params[:id])
    authorize contact_detail
    contact_detail.update_attributes!(comm_params.merge({modified_by: @user.id}))
      render json: {status: 'SUCCESS', message: nil, data: contact_detail}, status: :ok
  end

  swagger_api :update do
    summary "Updates a contact_detail record for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the contact_detail record to be updated"
    param :form, :user_id, :integer, :optional, "User Id of the customer. If not specified, system will assume it is for the requesting user (from the user_token). Thus if it is a client portal user, you must specify the user_id"
    param :form, :mode_key, :string, :optional, "Mode of contact_detail, can be: 'phone', 'email'"
    param :form, :mode_value, :string, :optional, "A string for the mode selected above (e.g. for 'call' it would be '555-555-5555', 'email' would be the email address, and so on.)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    contact_detail = policy_scope(ContactDetail).find(comm_params[:id])
    authorize contact_detail
    if contact_detail.destroy!
      render json: {status: 'SUCCESS', message: nil, data: contact_detail}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a contact_detail record for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the contact_detail record to be updated"
    param :query, :user_id, :integer, :optional, "User Id of the customer. If not specified, system will assume it is for the requesting user (from the user_token). Thus if it is a client portal user, you must specify the user_id"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    contact_details = policy_scope(ContactDetail)
    authorize contact_details
    contact_details = contact_details.paginate(page: page)
      render json: {status: 'SUCCESS', message: nil, data: contact_details,
        pagination: {current_page: contact_details.current_page, per_page: contact_details.per_page,
        total_entries: contact_details.total_entries, total_pages: contact_details.total_pages}},
        status: :ok
  end

  swagger_api :index do
    summary "Returns all contact_detail records for a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :user_id, :integer, :optional, "User Id of the customer. If not specified, system will assume it is for the requesting user (from the user_token). Thus if it is a client portal user, you must specify the user_id"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def comm_params
    params.permit(:id, :page, :user_id, :mode_key, :mode_value, :active)
  end
end
