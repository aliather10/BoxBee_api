class Api::V1::SubscriptionsController < ApiController
  swagger_controller :subscriptions, "Manages subscriptions to plans"

  def show
    subscription = policy_scope(Subscription).find(subs_params[:id])
    authorize subscription
    render json: {status: 'SUCCESS', message: nil, data: subscription}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves an subscription record"
    notes "Permitted params: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The subscription ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def customer
    if subs_params[:customer_id] == 'current'
      subscriptions = policy_scope(Subscription).by_customer(current_customer.id)
    else
      subscriptions = policy_scope(Subscription).by_customer(subs_params[:customer_id])
    end
    subscriptions = subscriptions.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: subscriptions.map(&:detailed_object),
      pagination: with_paging_info(subscriptions)}, status: :ok
  end

  swagger_api :customer do
    summary "Lists all subscriptions associated with a given customer"
    notes "Permitted params: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "The customer ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def plan
    subscriptions = policy_scope(Subscription).by_plan(subs_params[:plan_id])
    subscriptions = subscriptions.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: subscriptions, pagination: with_paging_info(subscriptions)},
      status: :ok
  end

  swagger_api :plan do
    summary "Lists all subscriptions associated with a given plan"
    notes "Permitted params: customer_service"
    notes "If the request comes from a customer, The returned subscriptions will actually be scoped according to the current product that he/she is logged in to."
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :plan_id, :integer, :required, "The plan ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def product
    if subs_params[:product_id] == 'current'
      subscriptions = policy_scope(Subscription).by_product(current_product.id)
    else
      subscriptions = policy_scope(Subscription).by_product(subs_params[:product_id])
    end
    subscriptions = subscriptions.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: subscriptions.map(&:detailed_object),
      pagination: with_paging_info(subscriptions)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all subscriptions associated with a given product"
    notes "Permitted params: customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :optional, "The product ID. Use 'current' for the current product's ID"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def subs_params
    params.permit(:id, :plan_id, :user_id, :length, :width, :height, :weight, :active,
      :page, :product_id)
  end
end
