class Api::V1::TaxesController < ApiController
  swagger_controller :taxes, "Taxes based on zip codes and accounting codes"
  skip_before_action :authenticate_user, only: :product
  skip_after_action :verify_policy_scoped, only: :product
  skip_after_action :verify_authorized, only: :product


  #POST a tax
  def create
    tax = policy_scope(Tax).new(product_id: tax_params[:product_id], zips: tax_params[:zips],
      tax_percent: tax_params[:tax_percent])
    authorize tax
    tax.created_by, tax.modified_by = @user.id, @user.id
    if tax.save!
      render json: {status: 'SUCCESS', message: nil, data: tax}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a Tax record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :zips, :string, :required, "Array of zip codes (e.g. '10036')"
    param :form, :product_id, :integer, :required, "The ID of the product corresponding to the product price record this tax should belong to"
    param :form, :tax_percent, :decimal, :required, "Percent in decimal format (e.g. '7.5')"
    response :ok
    response :internal_server_error, 'tax record could not be created'
  end

  #GET all companies' taxes (essentially the tax table)
  def index
    taxes = policy_scope(Tax)
    authorize taxes
    render json: {status: 'SUCCESS', message: nil, data: taxes}, status: :ok
  end

  swagger_api :index do
    summary "Lists all Tax records"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    response :ok
  end

  #GET a company's taxes based on product
  def product
    if tax_params[:product_id] == 'current'
      product = current_product
    else
      product = policy_scope(Product).find(tax_params[:product_id])
      verify_policy_scoped
    end
    accounting_code = product.accounting_codes
                          .where('name LIKE ?', "%#{tax_params[:type].capitalize}%").first.code
    tax = product.taxes.select{|tax| tax.zips.include?(tax_params[:zip].to_s)}.first
    authorize tax unless tax_params[:product_id] == 'current'
    tax_percent = product.taxed_accounting_codes.include?(accounting_code.to_s) ? (tax ? tax.tax_percent : product.default_tax) : 0
    render json: {status: 'SUCCESS', message: nil, data: {tax_percent: tax_percent}}, status: :ok
  end

  swagger_api :product do
    summary "Lists all Tax records"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The product ID. Can use 'current' for the current product"
    param :query, :type, :string, :required, "The type of the accounting code. Can be: 'storage', 'transit', 'misc'"
    param :query, :zip, :string, :required, "The zip code to check for tax"
    response :ok
  end

  #PUT a tax
  def update
    tax = policy_scope(Tax).find(tax_params[:id])
    authorize tax
    tax.modified_by = @user.id
    added_zips = tax_params[:zips] - tax.zips
    removed_zips = tax.zips - tax_params[:zips]
    tax.zips = tax.zips + added_zips unless added_zips.empty?
    tax.zips = tax.zips - removed_zips unless removed_zips.empty?
    #Associate tax rates to a client tax table.
    tax.product = policy_scope(Product).find_by_id(tax_params[:product_id]) if tax_params[:product_id]
    tax.tax_percent = tax_params[:tax_percent]
    if tax.save!
      render json: {status: 'SUCCESS', message: nil, data: tax}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a Tax record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the record to be updated"
    param :form, :zips, :string, :optional, "Array of zip codes (e.g. ['10036', '10001'])"
    param :form, :product_id, :integer, :optional, "The ID of the product corresponding to the product price record this tax should belong to"
    param :form, :tax_percent, :decimal, :optional, "Percent in decimal format (e.g. '7.5')"
    response :ok
    response :internal_server_error, 'tax record could not be updated'
  end

  def destroy
    tax = policy_scope(Tax).find(tax_params[:id])
    authorize tax
    if tax.destroy!
      render json: {status: 'SUCCESS', message: nil, data: tax}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a Tax record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the record to be updated"
    response :ok
    response :internal_server_error, 'tax record could not be updated'
  end

  private
  #Use strong parameters for security
  def tax_params
    params.permit(:id, :company_id, {zips: []}, :accounting_codes, :tax_percent, :product_id, :type)
  end
end
