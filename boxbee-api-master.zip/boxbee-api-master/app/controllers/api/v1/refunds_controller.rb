class Api::V1::RefundsController < Api::V1::StripeController
  swagger_controller :refunds, "Manage Stripe refunds"
  skip_after_action :verify_policy_scoped

  def create
    authorize :refund, :create?
    invoice_items = get_invoice_items_from_ids(refund_params[:invoice_item_ids], @user.company.id)
    refunds = Refund.refunder(invoice_items, @user.company_id, refund_params[:reason])
    if refunds.empty?
      render json: {status: 'SUCCESS', message: "No refunds were processable from the requested invoice_items. " \
        "Most likely the corresponding invoices have already been refunded.", data: refunds.as_json}, status: :ok
    else
      render json: {status: 'SUCCESS', message: nil, data: refunds.as_json}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new refund for a client"
    notes "Warning: requires client customer_service role or above. Takes in an array of invoice_items"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :invoice_item_ids, :string, :required, "An array of invoice_item_ids to be refunded"
    param :form, :reason, :string, :optional, "String indicating the reason for the refund. Possible values are duplicate, fraudulent, and requested_by_customer. Specifying fraudulent as the reason when you believe the charge to be fraudulent will help us improve our fraud detection algorithms."
    response :ok
    response :internal_server_error
  end

  private
  #Use strong parameters for security
  def refund_params
    params.permit(:id, :company_id, :charge_id, :amount, :reason,
      {invoice_item_ids: []})
  end

  def get_invoice_items_from_ids(invoice_item_ids, company_id)
    invoice_items = InvoiceItem.by_company(company_id).select{ |ii|
      invoice_item_ids.include?(ii['id'])
    }
  end
end
