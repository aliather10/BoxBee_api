class Api::V1::AppointmentNotesController < ApiController
  swagger_controller :appointment_notes, "Notes that are attached to an appointment"

  def create
    appointment_note = AppointmentNote.new(an_params.except(:appointment_id))
    authorize appointment_note
    appointment_note = set_appointment(appointment_note)
    appointment_note.created_by, appointment_note.modified_by = @user.id, @user.id
    if appointment_note.save!
      render json: {status: 'SUCCESS', message: nil,
        data: appointment_note.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new appointment note record for a appointment"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :appointment_id, :integer, :required, "The appointment ID this appointment note belongs to"
    param :form, :note, :string, :required, "The note text to form this appointment note"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    appointment_note = policy_scope(AppointmentNote).find(an_params[:appointment_id])
    authorize appointment_note
    appointment_note.modified_by = @user.id
    appointment_note = set_appointment(appointment_note) if an_params[:appointment_id]
    if appointment_note.update_attributes!(an_params.except(:appointment_id))
      appointment_note = appointment_note.detailed_object
      render json: {status: 'SUCCESS', message: nil, data: appointment_note}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a appointment note record for a appointment"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The appointment note ID"
    param :form, :appointment_id, :integer, :optional, "The appointment ID this appointment note belongs to"
    param :form, :note, :string, :optional, "The note text to form this appointment note"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def an_params
    params.permit(:id, :appointment_id, :note)
  end

  def set_appointment(appointment_note)
    if @user.super_user?
      appointment_note.appointment = Appointment.find(an_params[:appointment_id])
    elsif is_client_cs?
      appointment_note.appointment = Appointment.by_company(@user.company_id).find(an_params[:appointment_id])
    else
      appointment_note.appointment = Appointment.by_user(@user.id).find(an_params[:appointment_id])
    end
    return appointment_note
  end
end
