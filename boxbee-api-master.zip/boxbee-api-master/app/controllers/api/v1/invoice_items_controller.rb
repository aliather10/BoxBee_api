class Api::V1::InvoiceItemsController < Api::V1::StripeController
  swagger_controller :invoice_items, "Manage Stripe invoice items"
  skip_after_action :verify_policy_scoped

  #GET invoice item
  def show
    authorize :invoice_item, :show?
    invoice_item = InvoiceItem.by_company(@user.company_id)
      .select{|ii| ii['id'] == invoice_item_params[:id]}.first
    render json: {status: 'SUCCESS', message: nil, data: invoice_item.as_json}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves an invoice item for a Stripe customer"
    notes "Permitted roles: customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "ID of invoice_item (e.g. ii_17IkXD2eZvKYlo2C1JK3Ejq8)"
    response :ok
    response :not_found
    response :internal_server_error
  end

  #GET all invoice items
  def index
    authorize :invoice_item, :index?
    invoice_items = InvoiceItem.by_customer(customer_id)
    if invoice_item_params[:invoice]
      invoice_items.select!{|ii| ii['invoice'] == invoice_item_params[:invoice]}
    end
    render json: {status: 'SUCCESS', message: nil, data: invoice_items.as_json}, status: :ok
  end


  swagger_api :index do
    summary "Lists all invoice items for a customer"
    notes "Permitted roles: customer_service"
    notes "IMPORTANT: When specifying the invoice as a query parameter, the response will also include refund information for each invoice item"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :invoice, :integer, :optional, "Stripe Invoice ID (e.g. 'in_17KWH1GtWBbsCJco0y2nT7H3')"
    response :ok
    response :internal_server_error
  end

  private
  #Implement strong parameters for security
  def invoice_item_params
    params.permit(:id, :starting_after, :company_id, :user_id, :amount, :description, :discountable, :currency,
      :invoice, :product_id)
  end
end
