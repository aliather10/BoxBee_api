class Api::V1::CardsController < Api::V1::StripeController
  swagger_controller :cards, "Manage Stripe customers' credit cards"
  skip_after_action :verify_policy_scoped

  #POST a card
  def create
    authorize :card, :create?
    if card_params[:customer_id]
      customer = policy_scope(Customer).find(card_params[:customer_id])
    else
      customer = policy_scope(Customer).find(current_customer.id)
    end
    stripe_customer = customer.stripe_customer
    #Create the card and associate it to the stripe customer in the params
    metadata = {product_id: customer.product.id}
    card = Card.create(stripe_customer, card_params[:stripe_token], metadata, customer.product.company_id, customer.product_id)
    #Render the API response
    if card
      render json: {status: 'SUCCESS', message: nil, data: card.as_json}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end

  swagger_api :create do
    summary "Creates a new card for a Stripe customer"
    notes "Permitted roles: all. WARNING: A Stripe token MUST be obtained via StripeJS and passed as a param. One CANNOT directly send credit card details (number, exp, etc.)"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :customer_id, :integer, :optional, "Customer ID. If not passed, will infer from the currently logged in user's token"
    param :form, :stripe_token, :string, :required, "The token returned from StripeJS (e.g. 'tok_17Qi6F2eZvKYlo2CF5KHkZ54')"
    response :ok
    response :internal_server_error
  end

  #GET a card
  def show
    authorize :card, :show?
    card = Card.retrieve_from_cache(card_params[:id], @user.company_id)
    if card
      render json: {status: 'SUCCESS', message: nil, data: card.as_json}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :show do
    summary "Retrieves a card based on its ID"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :string, :required, "The Stripe Card (aka 'source') ID e.g. card_17KxXR2eZvKYlo2Ch7l2AAJr"
    param :query, :company_id, :integer, :optional, "Company ID. Only required for superusers"
    response :ok
    response :not_found
  end

  #GET all cards
  def customer
    authorize :card, :index?
    if card_params[:customer_id] == 'current'
      customer = policy_scope(Customer).where(product: current_product, user: current_user).first
    else
      customer = policy_scope(Customer).find(card_params[:customer_id])
    end
    cards = {cards: customer.cards, default_card: customer.stripe_customer['default_source']}
    if cards
      render json: {status: 'SUCCESS', message: nil, data: cards}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :internal_server_error
    end
  end

  swagger_api :customer do
    summary "Retrieves all cards belonging to a customer"
    notes "Permitted roles: customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "Customer ID. Can use 'current' for current customer"
    response :ok
    response :internal_server_error
  end

  #PUT a card
  def update
    authorize :card, :update?
    #Retrieve a card and update its properties before saving
    if card_params[:customer_id] == 'current'
      customer = current_customer
    else
      customer = Customer.find(card_params[:customer_id])
    end
    card = Card.update(card_params[:id], customer.id, card_params.slice(:exp_month,
      :exp_year, :address_line1, :address_line2, :address_city, :address_state,
      :address_zip, :address_country), @user.company_id)
    if card
      render json: {status: 'SUCCESS', message: nil, data: card.as_json}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a card based on its ID"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :string, :required, "The Stripe Card (aka 'source') ID e.g. card_17KxXR2eZvKYlo2Ch7l2AAJr"
    param :form, :customer_id, :integer, :required, "The customer ID (can use 'current' for the current customer)"
    param :form, :exp_month, :integer, :optional, "month of expiration m or mm"
    param :form, :exp_year, :integer, :optional, "year of expiration yyyy"
    param :form, :address_line1, :string, :optional, "Address street address 1"
    param :form, :address_line2, :string, :optional, "Address street address 2"
    param :form, :address_city, :string, :optional, "Address city"
    param :form, :address_state, :string, :optional, "Address state (full name)"
    param :form, :address_zip, :string, :optional, "Address zip"
    param :form, :address_country, :string, :optional, "Address country abbreviation (2 letter ISO abbrev.). Not needed in most cases"
    response :ok
    response :internal_server_error
  end

  #DELETE a card
  def destroy
    authorize :card, :destroy?
    #! For higher security, make sure stripe_card_id is scoped to the User making the request. For #update and #create as well.
    if card = delete(stripe_card_id, @user.company_id)
      render json: {status: 'SUCCESS', message: nil, data: card.as_json}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a card based on its ID"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :string, :required, "The Stripe Card (aka 'source') ID e.g. card_17KxXR2eZvKYlo2Ch7l2AAJr"
    response :ok
    response :internal_server_error
  end

  private
  #Use strong parameters for security
  def card_params
    params.permit(:id, :company_id, :customer_id, :stripe_token, :product_id,
      :exp_month, :exp_year, :address_line1, :address_line2, :address_city,
      :address_state, :address_zip, :address_country)
  end
end
