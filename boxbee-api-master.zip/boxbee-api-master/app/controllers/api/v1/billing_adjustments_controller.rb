class Api::V1::BillingAdjustmentsController < Api::V1::StripeController
  swagger_controller :adjustments, "Manage one off adjustments (debits/credits)"

  #POST invoice item. Upon creation, it will be billed on the next billing cycle.
  def create
    authorize :billing_adjustment, :create?
    customer = policy_scope(Customer).find(adjustment_params[:customer_id])
    product = customer.product
    accounting_code = AccountingCode.where("name LIKE ?", "Misc Revenue")
      .where(product_id: product.id).first.code
    taxes = product.taxes.select{|tax| tax.zips.include?(adjustment_params[:zip])}
    tax_percent = product.taxed_accounting_codes.include?(accounting_code.to_s) ? (!taxes.empty? ? taxes.first.tax_percent : product.default_tax) : 0
    #Iterate through adjustments and create an invoice item for each
    metadata = {product_id: product.id, accounting_code: accounting_code, tax: (tax_percent * adjustment_params[:amount])}
    invoice_items = []
    adjustment_params[:adjustment_list].each do |adj|
      invoice_items << InvoiceItem.create(customer.id, adjustment_params[:amount], adjustment_params[:description],
        product.currency, metadata, product.company_id)
    end
    render json: {status: 'SUCCESS', message: 'Invoice created successfully.', data: invoice_items.as_json}, status: :ok
  end

  swagger_api :create do
    summary "Creates a new invoice item for a Stripe customer"
    notes "Permitted roles: customer_service, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :customer_id, :integer, :required, "The ID of the customer to apply the adjustments to"
    param :form, :zip, :string, :required, "The zip code to retrieve taxes from. It is recommended that the zip from the customer's last used or default address is used"
    param :form, :adjustment_list, :string, :required, "An array of JSON objects representing the adjustments. E.g. '[{amount:1000, description: Tape and boxes}, {amount: -550, description: credit}]' Amounts are + or - integers in cents. Remember to use double quotes for proper JSON"
    response :ok
    response :internal_server_error
  end

  private
  #Implement strong parameters for security
  def adjustment_params
    params.permit(:id, :starting_after, :company_id, :user_id, {adjustment_list: [:amount, :description]},
      :currency, :product_id, :zip)
  end
end
