class Api::V1::InventoriesController < ApiController
  swagger_controller :inventories, "Manages inventory locations in a warehouse"

  def create
    inventory = policy_scope(Inventory).new(inv_params.except(:company_id))
    authorize inventory
    inventory.created_by, inventory.modified_by = @user.id, @user.id
    if inventory.save!
      render json: {status: 'SUCCESS', message: nil, data: inventory}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new inventory record"
    notes "Permitted roles: warehouse_staff, driver, supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :location_id, :integer, :required, "The ID of the location"
    param :form, :inventory_type, :string, :required, "Can be 'container, 'customer_item'"
    param :form, :inventory_name, :string, :required, "The name of the inventory e.g. 'yellow box'. It will usually be the name of the customer's or container's item_type name"
    param :form, :sku, :string, :required, "The identifier of the inventory. Will be either the item_type_id (if it's an empty container) or the barcode number if it's a customer_item"
    param :form, :quantity, :integer, :required, "Should be 1 for customer_items and some positive integer describing the quantity of empty containers in the location if it's an empty container"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def update
    inventory = policy_scope(Inventory).find(inv_params[:id])
    authorize inventory
    inventory.modified_by = @user.id
    if inventory.update_attributes!(inv_params.except(:company_id))
      render json: {status: 'SUCCESS', message: nil, data: inventory}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a new inventory record"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the inventory location to be updated"
    param :form, :location_id, :integer, :optional, "The ID of the location"
    param :form, :inventory_type, :string, :optional, "Can be 'container, 'customer_item'"
    param :form, :inventory_name, :string, :optional, "The name of the inventory e.g. 'yellow box'. It will usually be the name of the customer's or container's item_type name"
    param :form, :sku, :string, :optional, "The identifier of the inventory. Will be either the item_type_id (if it's an empty container) or the barcode number if it's a customer_item"
    param :form, :quantity, :integer, :optional, "Should be 1 for customer_items and some positive integer describing the quantity of empty containers in the location if it's an empty container"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def destroy
    inventory = policy_scope(Inventory).find(inv_params[:id])
    authorize inventory
    if inventory.destroy!
      render json: {status: 'SUCCESS', message: nil, data: inventory}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes an inventory by ID"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be deleted"
    response :ok
    response :unauthorized
    response :not_found
  end

  def customer_item
    inventories = policy_scope(Inventory)
      .by_inventory_type(:customer_item)
      .by_warehouse(inv_params[:warehouse_id])
    authorize inventories
    if inv_params[:location_types]
      inv_params[:location_types].each do |loc_type|
        inventories = inventories.by_location_type(loc_type)
      end
    end
    inventories = inventories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventories.map(&:detailed_object),
      pagination: with_paging_info(inventories)}, status: :ok
  end

  swagger_api :customer_item do
    summary "Lists all inventories in a given warehouse that hold an customer item"
    notes "Not suitable for superusers"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :warehouse_id, :integer, :required, "The warehouse ID"
    param :query, :location_types, :string, :optional, "e.g. '?location_types[]=reserve&location_types[]=forward'. Can be 'permanent', 'staging', 'cart'"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def container
    inventories = policy_scope(Inventory)
      .by_inventory_type(:container)
      .by_warehouse(inv_params[:warehouse_id])
    authorize inventories
    if inv_params[:location_types]
      inv_params[:location_types].each do |loc_type|
        inventories = inventories.by_location_type(loc_type)
      end
    end
    inventories = inventories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventories,
      pagination: with_paging_info(inventories)}, status: :ok
  end

  swagger_api :container do
    summary "Lists all inventories in a given warehouse that hold empty containers"
    notes "Not suitable for superusers"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :warehouse_id, :integer, :required, "The warehouse ID"
    param :query, :location_types, :string, :optional, "e.g. '?location_types[]=reserve&location_types[]=forward'. Can be 'permanent', 'staging', 'cart'"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def move_to_staging
    # Staging location ID should be the sole staging location belonging to that warehouse.
    staging_location_id = @user.company.warehouses.first.locations
      .where(location_type: Location.location_types[:staging]).first.id
    mass_transfer(inv_params[:inventories], staging_location_id)
  end

  swagger_api :move_to_staging do
    summary "Mass transfer of inventories into a temporary staging location in the warehouse"
    notes "Not suitable for superusers"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :inventories, :string, :required, "A JSON array of inventory_ids and quantities to be moved to staging, e.g.: '[{inventory_id: 3, quantity: 10, warehouse_task_id: 341}, {...}, ...]'. As usual, assume quantity of 1 for customer items"
    response :ok
    response :unauthorized
    response :not_found
  end

  def load_cart
    mass_transfer(inv_params[:inventories], inv_params[:cart_id],
      inv_params[:warehouse_task_id])
  end

  swagger_api :load_cart do
    summary "Mass transfer of inventories onto a cart in the warehouse"
    notes "Not suitable for superusers"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :inventories, :string, :required, "A JSON array of inventory_ids and quantities to be moved to the cart, e.g.: '[{inventory_id: 3, quantity: 10, warehouse_task_id: 341}, {...}, ...]'. As usual, assume quantity of 1 for customer items. Warehouse Task ID is optional"
    param :form, :cart_id, :integer, :required, "The location ID of the cart. (The cart is treated as a location)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def move_to_storage
    inventories = []
    warehouse_task = nil
    staging_location_id = policy_scope(Location).where(location_type: Location.location_types[:staging]).first.id
    inv_params[:skus].each do |sku|
      inventory = policy_scope(Inventory).where(sku: sku['sku'], location_id: staging_location_id).first
      inventories << {inventory_id: inventory.id, quantity: 1}
      warehouse_task = WarehouseTask.create!(
        location_id: staging_location_id,
        inventory_type: :customer_item,
        inventory_name: inventory.inventory_name,
        sku: sku['sku'],
        quantity: 1,
        status: :created,
        task_type: :put,
        created_by: @user.id,
        modified_by: @user.id
      )
    end
    mass_transfer(inventories, policy_scope(Location).find(inv_params[:destination_id]).id, warehouse_task.id)
  end

  swagger_api :move_to_storage do
    summary "Mass transfer of inventories into permanent storage in the warehouse"
    notes "Not suitable for superusers"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :skus, :string, :required, "A JSON array of skus and quantities to be moved to storage, e.g.: '[{sku: 302384, quantity: 1}, {...}, ...]'. As usual, assume quantity of 1 for customer items"
    param :form, :destination_id, :integer, :required, "The location ID of where the items will be stored"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def inv_params
    params.permit(:id, :location_id, :company_id, :user_id, :inventory_type,
      :inventory_name, :sku, :quantity, :page, {location_types: []}, :warehouse_id,
      {inventories: [:inventory_id, :quantity, :warehouse_task_id]}, {skus: [:sku, :quantity]},
      :staging_location_id, :cart_id, :destination_id, :warehouse_task_id)
  end

  def mass_transfer(inventories, destination_id, warehouse_task_id)
    authorize policy_scope(Inventory)
    updated_inventories = Inventory.mass_transfer(inventories,
      destination_id, warehouse_task_id, @user.company_id)
    render json: {status: 'SUCCESS', message: nil, data: updated_inventories}, status: :ok
  end
end
