class Api::V1::CustomerFeesController < ApiController
  swagger_controller :customer_fees, "A customer_fee of a user's transit-related prices for a particular appointment."

  #GET a customer_fee
  def appointment
    customer_fee = policy_scope(CustomerFee).find_by_appointment_id(fee_params[:appointment_id])
    authorize customer_fee
    fee = customer_fee.fee(fee_params[:appointment_details])
    render json: {status: 'SUCCESS', message: nil, data: customer_fee.detailed_object(fee)}, status: :ok
  end

  swagger_api :appointment do
    summary "Shows a CustomerFee record and fee billed to customer based on appointment ID"
    notes "Permitted roles: customer_service, admin, super_user"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :appointment_id, :integer, :required, "Appointment Id"
    response :ok
    response :not_found
  end

  #GET a customer_fee
  def customer
    customer_fees = policy_scope(CustomerFee).by_customer(fee_params[:customer_id])
    authorize customer_fees
    render json: {status: 'SUCCESS', message: nil, data: customer_fees}, status: :ok
  end

  swagger_api :customer do
    summary "Shows CustomerFee records based on User ID"
    notes "Permitted roles: customer_service, admin, super_user"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "Customer Id"
    response :ok
    response :not_found
  end

  private
  #Use strong parameters for security
  def fee_params
    params.permit(:id, :user_id, :appointment_id, :product_id, :empty_delivery_price, :packed_pickup_price,
      :packed_delivery_price, :empty_pickup_price, appointment_details: [:transit_type, :request_type])
  end
end
