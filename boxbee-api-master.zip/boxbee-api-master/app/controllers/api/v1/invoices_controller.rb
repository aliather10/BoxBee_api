class Api::V1::InvoicesController < Api::V1::StripeController
  swagger_controller :invoices, "Manage Stripe invoices"
  skip_after_action :verify_policy_scoped

  #GET invoice
  def show
    authorize :invoice, :show?
    invoice = Invoice.by_company(current_company.id).select{|inv| inv['id'] == invoice_params[:id]}.first
    customer = policy_scope(Customer).find_by_stripe_customer_id(invoice['customer'])
    invoice = detailed_object(invoice, customer.id, @user.company_id) if invoice
    render json: {status: 'SUCCESS', message: nil, data: invoice}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves an invoice for a customer"
    notes "Permitted roles: customer, customer_service, admin"
    param :path, :id, :integer, :required, "ID of invoice (e.g. in_17KWH1GtWBbsCJco0y2nT7H3)"
    response :ok
    response :internal_server_error
  end

  def customer
    authorize :invoice, :customer?
    if invoice_params[:customer_id] == 'current'
      customer = policy_scope(Customer).find(current_customer.id)
    else
      customer = policy_scope(Customer).find(invoice_params[:customer_id])
    end
    invoices = Invoice.by_customer(customer.id)
    invoices = detailed_object_lite(invoices)
    render json: {status: 'SUCCESS', message: nil, data: invoices}, status: :ok
  end

  swagger_api :customer do
    summary "Lists invoices for a customer"
    param :path, :customer_id, :integer, :required, "customer ID. Use 'current' for the current customer"
    response :ok
    response :internal_server_error
  end

  #GET all invoice items
  def index
    authorize :invoice, :index?
    invoices = Invoice.by_company(current_company.id)

    if invoice_params[:product_id]
      invoices = Invoice.by_product(invoice_params[:product_id]) & invoices
    end

    if invoice_params[:appointment_id]
      invoices = Invoice.by_appointment(invoice_params[:appointment_id]) & invoices
    end

    if invoice_params[:customer_id]
      invoices = Invoice.by_customer(invoice_params[:customer_id]) & invoices
    end

    invoices.select! {|invoice| invoice['closed'] == false} if invoice_params[:outstanding]

    unless invoices.empty?
      invoices = detailed_object_lite(invoices)
    end

    render json: {status: 'SUCCESS', message: nil, data: invoices}, status: :ok
  end

  swagger_api :index do
    summary "Lists all invoices for a company or for a particular user."
    notes "Permitted roles: customer_service, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :product_id, :integer, :optional, "Product ID"
    param :query, :appointment_id, :integer, :optional, "Filter by appointment_id"
    param :query, :customer_id, :integer, :optional, "Customer ID"
    param :query, :start_date, :integer, :optional, "Filter results based on start_date (expressed as UNIX timestamp, e.g. 12/25/2015 would be expressed as '1451019600'"
    param :query, :end_date, :integer, :optional, "Filter results based on end_date (if start_date is specified but no end_date, it will be assumed that the end_date is today's date)"
    param :query, :outstanding, :boolean, :optional, "Filter by outstanding invoices"
    response :ok
    response :internal_server_error
  end

  def pay
    authorize :invoice, :pay?
    paid_invoices = []
    invoice_params[:invoice_ids].each do |invoice_id|
      invoice = Invoice.retrieve(invoice_id, current_company.id)
      if invoice.pay
        paid_invoices << invoice.as_json
      end
    end
    render json: {status: 'SUCCESS', message: nil, data: paid_invoices.as_json}, status: :created
  end

  swagger_api :pay do
    summary "Pays a particular invoice or a batch of invoices immediately"
    notes "Permitted roles: customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :invoice_ids, :string, :required, "An array of invoice IDs to be paid, e.g. '[in_17KWH1GtWBbsCJco0y2nT7H3, in_29KERH1GtWBbsCJco0y2nT7H3]'"
    response :created
    response :internal_server_error
  end

  private
  #Implement strong parameters for security
  def invoice_params
    params.permit(:id, :starting_after, :company_id, :customer_id, :closed,
      :description, :product_id, :start_date, :end_date, :appointment_id, {invoice_ids: []})
  end

  def filter_by_date(invoices)
    start_date = invoice_params[:start_date]
    unless invoice_params[:end_date]
      end_date = start_date + 1.day.to_i
    end
    if start_date && end_date
      return invoices.select do |invoice|
        invoice['date'] >= start_date && invoice['date'] <= end_date
      end
    else
      return invoices
    end
  end

  #! Consider moving this to a library to make this controller lighter 
  def detailed_object(invoice, customer_id, company_id)
    #Assign correct invoice status
    if invoice['attempted'] && invoice['closed'] && invoice['paid']
      status = 'paid'
    elsif invoice['forgiven'] && invoice['closed'] || invoice['closed']
      status = 'closed'
    elsif invoice['attempted']
      status = 'attempted'
    else
      status = 'pending'
    end
    appointment_id = invoice['metadata']['appointment_id']
    history =  CustomerFee.find_by_appointment_id(appointment_id)
    transit_fees = history.nil? ? 0 : history.fee
    charge_id = invoice['charge']

    #Assign refundability and refundable amount for each invoice item
    ii_lines = []
    refunds_array = Refund.refund_info(invoice['lines']['data'], invoice, company_id)
    invoice['lines']['data'].each_with_index do |ii, index|
      ii_lines << ii.merge({refundable: refunds_array[index][:refundable],
        amount_refundable: refunds_array[index][:amount_refundable], tax_refundable: refunds_array[index][:tax_refundable]})
    end

    if charge_id
      charge = Charge.by_company(company_id).select{|ch| ch['id'] == charge_id}.first
      invoice['source'] = charge['source']
    end
    customer = Customer.find(customer_id)
    card = customer.cards.select {|card| card['id'] == charge['source']['id']}.first
    return invoice.merge({
      user: customer.user,
      card: card,
      customer: customer,
      invoice_status: status,
      transit_fees_subtotal: transit_fees,
      appointment_id: appointment_id ||= 'ID not available',
      lines: {data: ii_lines}
    })
  end

  def detailed_object_lite(invoices)
    invoices.map{|inv|
      customer = Customer.find_by_stripe_customer_id(inv['customer'])
      if customer
        inv.merge({
                      customer_id: customer.id,
                      name: customer.user.full_name,
                      email: customer.user.email
                  })
      else
        inv
      end
    }
  end
end
