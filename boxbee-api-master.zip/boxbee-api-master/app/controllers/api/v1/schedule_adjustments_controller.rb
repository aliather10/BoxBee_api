class Api::V1::ScheduleAdjustmentsController < ApiController
  swagger_controller :schedule_adjustments, "Manages adjustments to service area schedules"

  def create
    adjustment = ScheduleAdjustment.new(adjustment_params.except(:service_area_schedule_id))
    authorize adjustment
    adjustment.created_by, adjustment.modified_by = @user.id, @user.id
    adjustment = set_date(adjustment)
    adjustment.service_area_schedule = policy_scope(ServiceAreaSchedule)
      .find(adjustment_params[:service_area_schedule_id])
    if adjustment.save!
      render json: {status: 'SUCCESS', message: nil, data: adjustment.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new adjustment record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :service_area_schedule_id, :integer, :required, "The ID of the operating area schedule this adjustment is associated with"
    param :form, :name, :integer, :required, "The name of this adjustment (e.g. 'Student summer season')"
    param :form, :date, :integer, :required, "The start date of the adjustment. Enter as a UNIX timestamp"
    param :form, :end_date, :integer, :optional, "The end date of the adjustment. If no end date is provided, the system will assume that the adjustment only takes place for ONE day, given by the 'date' parameter."
    param :form, :new_duration_value_mins, :integer, :require, "The new width of the time window that a customer must wait for, in minutes"
    param :form, :new_max_appointments_per_slot, :integer, :require, "The new max number of appointments for a given slot"
    param :form, :active, :boolean, :required, "Whether or not the adjustment is good for use. Should almost always be true when creating a new record."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    adjustment = policy_scope(ScheduleAdjustment).find(adjustment_params[:id])
    authorize adjustment
    render json: {status: 'SUCCESS', message: nil, data: adjustment.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves an adjustment record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The adjustment ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    adjustment = policy_scope(ScheduleAdjustment).find(adjustment_params[:id])
    authorize adjustment
    adjustment.modified_by = @user.id
    adjustment.service_area_schedule = policy_scope(ServiceAreaSchedule)
      .find(adjustment_params[:service_area_schedule_id]) if adjustment_params[:service_area_schedule_id]
    adjustment = set_date(adjustment)
    if adjustment.update_attributes!(adjustment_params.except(:service_area_schedule_id, :date))
      render json: {status: 'SUCCESS', message: nil, data: adjustment.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates an adjustment record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The adjustment ID"
    param :form, :service_area_schedule_id, :integer, :optional, "The ID of the operating area schedule this adjustment is associated with"
    param :form, :name, :integer, :optional, "The name of this adjustment (e.g. 'Student summer season')"
    param :form, :date, :integer, :optional, "The start date of the adjustment. Enter as a UNIX timestamp"
    param :form, :end_date, :integer, :optional, "The end date of the adjustment. If no end date is provided, the system will assume that the adjustment only takes place for ONE day, given by the 'date' parameter."
    param :form, :new_duration_value_mins, :integer, :optional, "Height in company defined units"
    param :form, :new_max_appointments_per_slot, :integer, :optional, "Weight in company defined units"
    param :form, :active, :boolean, :optional, "Whether or not the adjustment is good for use. Should almost always be true when creating a new record."
    response :ok
    response :not_found
    response :unauthorized
  end

  def destroy
    adjustment = policy_scope(ScheduleAdjustment).find(adjustment_params[:id])
    authorize adjustment
    if adjustment.destroy!
      render json: {status: 'SUCCESS', message: nil, data: adjustment}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys an adjustment record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The adjustment ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def index
    adjustment = policy_scope(ScheduleAdjustment)
    authorize adjustments
    adjustments = adjustments.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: adjustments(&:detailed_object),
      pagination: with_paging_info(adjustments)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all adjustments"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def adjustment_params
    params.permit(:id, :service_area_schedule_id, :name, :date, :end_date, :new_duration_value_mins,
      :new_max_appointments_per_slot, :active, :page)
  end

  def set_oas(adjustment)
    if @user.super_user?
      adjustment.service_area_schedule = ServiceAreaSchedule
        .find(adjustment_params[:service_area_schedule_id])
    else
      adjustment.service_area_schedule = ServiceAreaSchedule
        .by_company(@user.company_id)
        .find(adjustment_params[:service_area_schedule_id])
    end
    return adjustment
  end

  def find_adjustment
    if @user.super_user?
      ScheduleAdjustment.find(adjustment_params[:id])
    else
      ScheduleAdjustment.by_company(@user.company_id).find(adjustment_params[:id])
    end
  end

  def find_adjustments
    if @user.super_user?
      ScheduleAdjustment.all
    else
      ScheduleAdjustment.by_company(@user.company_id)
    end
  end

  def set_date(adjustment)
    if adjustment_params[:date]
      adjustment.date = DateTime.strptime("#{adjustment_params[:date]}", "%s")
    end
    if adjustment_params[:end_date]
      adjustment.end_date = DateTime.strptime("#{adjustment_params[:end_date]}", "%s")
    end
    return adjustment
  end
end
