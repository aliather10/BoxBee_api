class Api::V1::WarehousesController < ApiController
  swagger_controller :warehouses, "Manages warehouses belonging to companies"

  def create
    warehouse = policy_scope(Warehouse).new(name: warehouse_params[:name])
    authorize warehouse
    address = policy_scope(Address).create!(warehouse_params.except(:name).merge({
      created_by: @user.id,
      modified_by: @user.id
    }))
    warehouse.address_id = address.id
    warehouse.modified_by, warehouse.created_by = @user.id, @user.id
    warehouse.company_id = @user.company_id
    if warehouse.save!
      render json: {status: 'SUCCESS', message: nil,
        data: warehouse.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new warehouse record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "Warehouse name"
    param :form, :address1, :string, :required, "Address1"
    param :form, :address2, :string, :required, "Address2"
    param :form, :address3, :string, :required, "Address3"
    param :form, :city, :string, :required, "City"
    param :form, :state_name, :string, :required, "Full state name"
    param :form, :country_name, :string, :required, "Full country name"
    param :form, :zip_code, :string, :required, "Zip code"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    warehouse = policy_scope(Warehouse).find(warehouse_params[:id])
    authorize warehouse
    if warehouse.update_attributes!(warehouse_params.slice(:name).merge({modified_by: @user.id}))
      Address.find(warehouse.address_id).update_attributes!(
        warehouse_params.except(:id, :name)
        .merge({modified_by: @user.id})
      )
      render json: {status: 'SUCCESS', message: nil,
        data: warehouse.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a warehouse record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Warehouse to be updated"
    param :form, :name, :string, :optional, "Warehouse name (publicly displayed to companies)"
    param :form, :address1, :string, :optional, "Address1"
    param :form, :address2, :string, :optional, "Address2"
    param :form, :address3, :string, :optional, "Address3"
    param :form, :city, :string, :optional, "City"
    param :form, :state_name, :string, :optional, "Full state name"
    param :form, :country_name, :string, :optional, "Full country name"
    param :form, :zip_code, :string, :optional, "Zip code"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def destroy
    warehouse = policy_scope(Warehouse).find(warehouse_params[:id])
    authorize warehouse
    if warehouse.destroy!
      Address.find(warehouse.address_id).destroy!
      render json: {status: 'SUCCESS', message: nil, data: warehouse}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a warehouse record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the warehouse record to be deleted"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    warehouses = policy_scope(Warehouse)
    authorize warehouses
    warehouses = warehouses.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: warehouses.map(&:detailed_object),
      pagination: with_paging_info(warehouses)}, status: :ok
  end

  swagger_api :index do
    summary "Returns all warehouse records for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    response :ok
    response :unauthorized
  end

  private
  def warehouse_params
    params.permit(:id, :page, :name, :gps_latitude_point, :gps_longitude_point,
      :address_id, :company_id, :address1, :address2, :address3, :state_name,
      :city, :country_name, :zip_code)
  end
end
