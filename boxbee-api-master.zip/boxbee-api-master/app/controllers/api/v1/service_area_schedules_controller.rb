class Api::V1::ServiceAreaSchedulesController < ApiController
  swagger_controller :service_area_schedules, "Schedules for service areas"

  def create
    sa_schedule = ServiceAreaSchedule.new(sas_params.except(:service_area_id, :start_time, :end_time))
    authorize sa_schedule
    sa_schedule.created_by, sa_schedule.modified_by = @user.id, @user.id
    sa_schedule = set_times(sa_schedule)
    sa_schedule.service_area_id = policy_scope(ServiceArea).find(sas_params[:service_area_id])
    if sa_schedule.save!
      render json: {status: 'SUCCESS', message: nil, data: sa_schedule.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new service area schedule record for an service area"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :service_area_id, :integer, :required, "The service area ID that this schedule belongs to"
    param :form, :name, :string, :required, "The name of this schedule, displayed to client users"
    param :form, :day_of_week, :string, :required, "The day of week this schedule applies to: 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'"
    param :form, :start_time, :string, :required, "The start time of the hours of operation ('HHMM' in 24 hours time)"
    param :form, :end_time, :string, :required, "The end time of the hours of operation ('HHMM' in 24 hours time)"
    param :form, :duration_value_mins, :integer, :required, "The duration of a slot (e.g. how long of a window must a customer wait at home)"
    param :form, :max_appointments_per_slot, :integer, :required, "How many appointments (maximum) can take place in the window duration specified above"
    param :form, :schedule_start_date, :string, :optional, "Start date to which this schedule applies (UNIX timestamp). If this and schedule_end_date are left blank, the schedule is good for perpetuity."
    param :form, :schedule_end_date, :string, :optional, "End date to which this schedule applies (UNIX timestamp). If this is left blank, the schedule is good for perpetuity from the schedule_start_date."
    param :form, :active, :boolean, :optional, "Whether or not the schedule is good for use. Should usually be true for new schedules."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    sa_schedule = policy_scope(ServiceAreaSchedule).find(sas_params[:id])
    authorize sa_schedule
    render json: {status: 'SUCCESS', message: nil, data: sa_schedule.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a service area schedule record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area schedule ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    sa_schedule = policy_scope(ServiceAreaSchedule).find(sas_params[:id])
    authorize sa_schedule
    sa_schedule.modified_by = @user.id
    sa_schedule.service_area_id = policy_scope(ServiceArea)
      .find(sas_params[:service_area_id]) if sas_params[:service_area_id]
    if sa_schedule.update_attributes!(sas_params.except(:service_area_id))
      render json: {status: 'SUCCESS', message: nil, data: sa_schedule.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates an service area schedule record for an service area"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area schedule ID"
    param :form, :service_area_id, :integer, :optional, "The service area ID that this schedule belongs to"
    param :form, :name, :string, :optional, "The name of this schedule, displayed to client users"
    param :form, :day_of_week, :string, :optional, "The day of week this schedule applies to: 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'"
    param :form, :start_time, :string, :optional, "The start time of the hours of operation ('HHMM' in 24 hours time)"
    param :form, :end_time, :string, :optional, "The end time of the hours of operation ('HHMM' in 24 hours time)"
    param :form, :duration_value_mins, :integer, :optional, "The duration of a slot (e.g. how long of a window must a customer wait at home)"
    param :form, :max_appointments_per_slot, :integer, :optional, "How many appointments (maximum) can take place in the window duration specified above"
    param :form, :schedule_start_date, :string, :optional, "Start date to which this schedule applies (UNIX timestamp). If this and schedule_end_date are left blank, the schedule is good for perpetuity."
    param :form, :schedule_end_date, :string, :optional, "End date to which this schedule applies (UNIX timestamp). If this is left blank, the schedule is good for perpetuity from the schedule_start_date."
    param :form, :active, :boolean, :optional, "Whether or not the schedule is good for use. Should usually be true for new schedules."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    sa_schedule = policy_scope(ServiceAreaSchedule).find(sas_params[:id])
    authorize sa_schedule
    if sa_schedule.destroy!
      render json: {status: 'SUCCESS', message: nil, data: sa_schedule.detailed_object}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :destroy do
    summary "Destroys a service area schedule record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area schedule ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def sas_params
    params.permit(:id, :service_area_id, :name, :day_of_week, :start_time, :end_time, :allowed_break_hours,
      :max_break_count, :duration_value_mins, :max_appointments_per_slot, :schedule_start_date,
      :schedule_end_date, :active)
  end

  def set_service_area(sa_schedule)
    if @user.super_user?
      sa_schedule.service_area = ServiceArea.find(sas_params[:service_area_id])
    else
      sa_schedule.service_area = ServiceArea.by_company(@user.company_id)
        .find(sas_params[:service_area_id])
    end
    return sa_schedule
  end

  def set_times(sa_schedule)
    start_time = sas_params[:start_time]
    sa_schedule.start_time = start_time[0..1].to_i*3600 + start_time[2..3].to_i*60
    end_time = sas_params[:end_time]
    sa_schedule.end_time = end_time[0..1].to_i*3600 + end_time[2..3].to_i*60

    oas_schedule.schedule_start_date = DateTime.strptime("#{sas_params[:schedule_start_date]}")
    oas_schedule.schedule_end_date = DateTime.strptime("#{sas_params[:schedule_end_date]}") if sas_params[:schedule_end_date]
    return sa_schedule
  end
end
