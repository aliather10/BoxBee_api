class Api::V1::ChargesController < Api::V1::StripeController
  swagger_controller :charges, "Manage Stripe charges"

  #GET a charge
  def show
    authorize :charge, :show
    customer_id = policy_scope(Customer).find(charge_params[:customer_id]).id
    charge = Charge.by_customer(customer_id)
      .select{|ch| ch['id'] == charge_params[:id]}
    if charge
      render json: {status: 'SUCCESS', message: nil, data: charge}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :show do
    summary "Retrieves a charge for a customer"
    notes "Permitted roles: customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "ID of charge (e.g. ch_17KxT22eZvKYlo2Cz15Mw2wb)"
    param :query, :customer_id, :integer, :required, "The customer ID"
    response :ok
    response :internal_server_error
  end

  private
  #Use strong parameters for security
  def charge_params
    params.permit(:id, :customer_id)
  end
end
