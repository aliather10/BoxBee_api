class Api::V1::AvailabilitiesController < ApiController
  skip_before_action :authenticate_user
  skip_after_action :verify_policy_scoped
  swagger_controller :availabilities, "Checks availability for a zip code"

  def zip
    authorize :availability, :zip?
    service_areas = current_product.service_areas
    covered_service_areas = service_areas.select do |sa|
      sa.service_area_zips.where(active: true).by_zip(avail_params[:zip_code]).size > 0
    end
    if covered_service_areas.size > 0
      render json: {status: 'SUCCESS', message: 'This zip code is served and available.',
        data: {valid_zip: true}}, status: :ok
    else
      render json: {status: 'FAILED', message: 'This zip code is NOT served.',
        data: {valid_zip: false}}, status: :ok
    end
  end

  swagger_api :zip do
    summary "Checks whether a zip code exists in a product's operating areas"
    param :query, :zip_code, :string, :required, "The zip code to be checked"
    response :ok
    response :not_found
    response :unauthorized
  end

  def host
    authorize :availability, :host?
    matching_products = Product.matching_products_for_host(avail_params[:host])
    if matching_products.empty?
      render json: {status: 'SUCCESS', message: 'This host is available.',
        data: {available_host: true}}, status: :ok
    else
      render json: {status: 'FAILED', message: 'This host as already been taken.',
        data: {available_host: false}}, status: :ok
    end
  end

  swagger_api :host do
    summary "Checks whether a host exists among products"
    param :query, :host, :string, :required, "The host to be checked, format: 'subdomain.storagesherpa.co'"
    response :ok
    response :not_found
  end

  def avail_params
    params.permit(:zip_code, :host)
  end
end
