class Api::V1::AddressNoteOptionsController < ApiController
  swagger_controller :address_note_options, "Templates for a company to use for address notes"

  def create
    address_note_option = AddressNoteOption.new(ano_params)
    authorize address_note_option
    address_note_option.modified_by, address_note_option.created_by = @user.id, @user.id
    address_note_option.company = @user.super_user? ? Client.find(ano_params[:company_id]) : @user.company
    if address_note_option.save!
      render json: {status: 'SUCCESS', message: nil, data: address_note_option}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new address_note_option record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :note, :string, :required, "The note to be stored (limit: 140 characters)"
    param :form, :company_id, :integer, :optional, "Required for superusers (roles = boxbee or system), otherwise will be inferred for normal users."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    address_note_option = policy_scope(AddressNoteOption).find(ano_params[:id])
    authorize address_note_option
    if address_note_option.update_attributes!(ano_params.merge({modified_by: @user_id}))
      render json: {status: 'SUCCESS', message: nil, data: address_note_option}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a address_note_option record for a company"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :note, :string, :optional, "The note to be stored (limit: 140 characters)"
    param :form, :active, :boolean, :optional, "Whether or not the note is active"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    address_note_option = policy_scope(AddressNoteOption).find(ano_params[:id])
    authorize :address_note_option
    if address_note_option.destroy!
      render json: {status: 'SUCCESS', message: nil, data: address_note_option}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a address_note_option record for a company"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the address_note_option record to be deleted"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    company = @user.super_user? ? Company.find(ano_params[:company_id]) : @user.company
    address_note_options = policy_scope(AddressNoteOption)
    authorize address_note_options
    address_note_options = address_note_options.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: address_note_options,
      pagination: {current_page: address_note_options.current_page, per_page: address_note_options.per_page,
        total_entries: address_note_options.total_entries, total_pages: address_note_options.total_pages}},
        status: :ok
  end

  swagger_api :index do
    summary "Returns all address_note_option records for a company"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    param :query, :company_id, :integer, :optional, "Required for superusers (roles = boxbee or system), otherwise will be inferred for normal users."
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def ano_params
    params.permit(:id, :page, :note, :active, :company_id)
  end
end
