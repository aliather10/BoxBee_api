class Api::V1::ServiceAreasController < ApiController
  swagger_controller :service_areas, "Where service is available"

  def create
    service_area = policy_scope(ServiceArea).new(sa_params.except(:zips))
    authorize service_area
    service_area.created_by, service_area.modified_by = @user.id, @user.id
    service_area.company_id = @user.company_id
    latlong = Seeding::Mapbox.latlong_from_zip(sa_params[:zips].first)
    service_area.time_zone = Timezone.lookup(latlong[1], latlong[0])
    if service_area.save!
      begin
        service_area = add_remove_zips(service_area)
        sa = ServiceArea.find(service_area.id)
        render json: {status: 'SUCCESS', message: nil, data: sa.detailed_object}, status: :ok
      rescue
        service_area.destroy
        render json: {status: 'FAILED', message: 'Service Area and Zips could not be saved.', data: nil}, status: :ok
      end
    end
  end

  swagger_api :create do
    summary "Creates a new service area record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of this service area, displayed to company users"
    param :form, :active, :string, :required, "Whether or not this service area is good for use"
    param :form, :zips, :string, :required, "A string of zips for this service area, e.g. [87234, 92348, 23094]"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    service_area = policy_scope(ServiceArea).find(sa_params[:id])
    authorize service_area
    render json: {status: 'SUCCESS', message: nil, data: service_area.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a service area record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    service_area = policy_scope(ServiceArea).find(sa_params[:id])
    authorize service_area
    service_area.modified_by = @user.id
    service_area = add_remove_zips(service_area)
    if service_area.update_attributes!(sa_params.except(:zips))
      sa = ServiceArea.find(service_area.id)
      render json: {status: 'SUCCESS', message: nil, data: sa.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates an service area record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area ID"
    param :form, :name, :string, :optional, "The name of this service area, displayed to company users"
    param :form, :active, :string, :optional, "Whether or not this service area is good for use"
    param :form, :zips, :string, :optional, "A string of zips for this service area, e.g. [87234, 92348, 23094]"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    service_area = policy_scope(ServiceArea).find(sa_params[:id])
    authorize service_area
    if service_area.destroy
      render json: {status: 'SUCCESS', message: nil, data: service_area}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes an service area record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area ID"
    response :ok
    response :bad_request
    response :unauthorized
  end


  def index
    service_areas = policy_scope(ServiceArea)
    authorize service_areas
    service_areas = service_areas.by_active_status(sa_params[:active]) if sa_params[:active]
    service_areas = service_areas.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: service_areas.map(&:detailed_object),
      pagination: with_paging_info(service_areas)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all service areas"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def product
    service_areas = policy_scope(ServiceArea).by_product(sa_params[:product_id])
    authorize service_areas
    service_areas = service_areas.by_active_status(sa_params[:active]) if sa_params[:active]
    service_areas = service_areas.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: service_areas.map(&:detailed_object),
      pagination: with_paging_info(service_areas)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all service areas for a given product"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The product ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def sa_params
    params.permit(:id, :name, :company_id, :active, :product_id, :page, {zips: []})
  end

  def add_remove_zips(service_area)
    sanitized_zips = sa_params[:zips].map{|a| a.to_s}
    if sanitized_zips
      zips_added = sanitized_zips - service_area.service_area_zips.where(active: true).map{|saz| saz.zip.to_s}
      zips_removed = service_area.service_area_zips.where(active: true).map{|saz| saz.zip.to_s} - sanitized_zips
    end
    zips_added.each { |zip|
      # If an existing deactivated service_area_zip exists, activate it. Otherwise, create a new one
      existing_sa_zip = service_area.service_area_zips.where(active: false).find_by_zip(zip)
      if existing_sa_zip
        existing_sa_zip.active = true
        existing_sa_zip.save!
      else
        ServiceAreaZip.create!(service_area: service_area, zip: zip, created_by: @user.id, modified_by: @user.id)
      end
    } if zips_added
    zips_removed.each { |zip|
      sa_zip = service_area.service_area_zips.find_by_zip(zip)
      if sa_zip.allowed_to_destroy?
        sa_zip.destroy!
      else
        sa_zip.active = false
        sa_zip.save!
      end

      #The model will make sure to deactivate instead of destroying
      # if there are linked appointments to this zip code
    } if zips_removed
    return service_area
  end
end
