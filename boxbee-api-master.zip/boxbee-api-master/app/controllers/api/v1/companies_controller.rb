class Api::V1::CompaniesController < ApiController
  skip_before_action :authenticate_user, only: :show
  skip_after_action :verify_policy_scoped, only: [:get_global_settings, :update_global_settings]
  # skip_after_action :verify_authorized, only: :update_global_settings
  swagger_controller :companies, "Manage companies"

  def create
    company = Company.new(company_params.except(:company_id, :logo))
    authorize company
    company.logo = decode_picture_data(company_params[:logo]) if company_params[:logo]
    company.created_by = User.first.id
    company.modified_by = company.created_by
    if company.save!
      render json: {status: 'SUCCESS', message: nil, data: company}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new company"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :contact_name, :string, :required, "The name of the primary contact at the company"
    param :form, :contact_number, :string, :required, "The primary contact's phone number"
    param :form, :contact_email, :string, :required, "The primary contact's email"
    param :form, :name, :string, :required, "A name for the company (e.g. 'Storage Sherpa')"
    param :form, :logo, :string, :required, "A base64 encoded string of the image to be uploaded"
    param :form, :country, :string, :required, "The 2 letter ISO representation of the country the company is domiciled in. E.g. 'us', 'ca', 'de'"
    param :form, :custom_admin_url, :string, :optional, "The full URL of the custom admin site (e.g. http://admin.storagesherpa.com)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    if company_params[:id] == 'current'
      company = current_company
    else
      authenticate_user
      company = policy_scope(Company).find(company_params[:id])
    end
    authorize company
    render json: {status: 'SUCCESS', message: nil, data: company}, status: :ok
  end

  swagger_api :show do
    summary "Shows an individual company record"
    notes "Permitted roles: all."
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Company to be retrieved. Use id = 'current' to retrieve the current company's information"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    company = policy_scope(Company).find(company_params[:id])
    authorize company
    company.logo = decode_picture_data(company_params[:logo]) if company_params[:logo]

    if company.update_attributes!(company_params.merge({modified_by: @super_user.id}).except(:logo))
      render json: {status: 'SUCCESS', message: nil, data: company}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates an individual company record"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Company to be updated"
    param :form, :contact_name, :string, :optional, "The name of the primary contact at the company"
    param :form, :contact_number, :string, :optional, "The primary contact's phone number"
    param :form, :contact_email, :string, :optional, "The primary contact's email"
    param :form, :name, :string, :optional, "A name for the company (e.g. 'Storage Sherpa')"
    param :form, :logo, :string, :optional, "A base64 encoded string of the image to be uploaded"
    param :form, :country, :string, :optional, "The 2 letter ISO representation of the country the company is domiciled in. E.g. 'us', 'ca', 'de'"
    param :form, :custom_admin_url, :string, :optional, "The full URL of the custom admin site (e.g. http://admin.storagesherpa.com)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def index
    companies = policy_scope(Company)
    companies = companies.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: companies,
      pagination: {current_page: companies.current_page, per_page: companies.per_page,
        total_entries: companies.total_entries, total_pages: companies.total_pages}},
        status: :ok
  end

  swagger_api :index do
    summary "Shows all companies (only available to Boxbee/System roles)"
    notes "Either a system token must be passed or the requesting user must be a Boxbee user"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Company to be retrieved"
    param :query, :page, :integer, :optional, "Specify the page of records to be retrieved. If not specified, the first page will be displayed. View the 'pagination' section of the response for more information on what pages are available"
    response :ok
    response :not_found
    response :unauthorized
  end

  def current
    authorize @company
    if @company
      render json: {status: 'SUCCESS', message: nil, data: @company}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :current do
    summary "Retrieves a company's information by the current domain (for users who have not logged in yet)"
    response :ok
    response :not_found
  end

  def update_global_settings
    authorize @user.company
    #Company information
    @user.company.update_attributes!(company_params.slice(:name))
    @user.company.company_detail.update_attributes!(company_params.slice(:address1, :address2,
      :address3, :city, :state_name, :zip_code, :entity_type))
    #Appointment lead times
    product = @user.company.products.first
    product.update_attributes!(company_params.slice(:default_slot_duration,
      :default_max_appointments_per_slot, :default_daily_start, :default_daily_end, :default_days_of_week))
    appointment_cutoffs = product.appointment_cutoffs
    creation_cutoff = appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types[:creation]).first
      .update_attributes!({lead_time: company_params[:creation_lead_time]})
    modification_cutoff = appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types[:modification]).first
      .update_attributes!(lead_time: company_params[:modification_lead_time]) if company_params[:modification_lead_time]
    cancellation_cutoff = appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types[:cancellation]).first
      .update_attributes!(lead_time: company_params[:cancellation_lead_time]) if company_params[:cancellation_lead_time]
    if @user.company
      render json: {status: 'SUCCESS', message: nil, data: @user.company.detailed_object}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :update_global_settings do
    summary "Sets a company's global settings"
    param :form, :address1, :string, :optional, "The street address of the company"
    param :form, :address2, :string, :optional, "The street address of the company"
    param :form, :address3, :string, :optional, "The street address of the company"
    param :form, :city, :string, :optional, "The city of the company"
    param :form, :state_name, :string, :optional, "The state of the company"
    param :form, :zip_code, :string, :optional, "The zip code of the company"
    param :form, :entity_type, :string, :optional, "The entity type of the company (can be 'llc', 'corporation', 'sole_proprietorship', 'c_corp', 's_corp', 'partnership')"
    param :form, :name, :string, :optional, "The formal name of the company ('Storage, LLC')"
    param :form, :creation_lead_time, :integer, :optional, "The minimum time in hours before an appointment can be made"
    param :form, :modification_lead_time, :integer, :optional, "The minimum time in hours before a change to an appointment can be made"
    param :form, :cancellation_lead_time, :integer, :optional, "The minimum time in hours after which an appointment cannot be canceled"
    param :form, :default_slot_duration, :integer, :optional, "The default slot duration (will override all other service area schedules for a company)"
    param :form, :default_max_appointments_per_slot, :integer, :optional, "The default maximum number of appointments per slot (will override all other service area schedules for a company)"
    param :form, :default_days_of_week, :string, :optional, "A JSON array of the default days per week for opening of business (e.g. ['monday', 'tuesday', 'friday']) (will override all other service area schedules for a company)"
    param :form, :default_daily_start, :integer, :optional, "The default start of business hours each day (in seconds since midnight) (will override all other service area schedules for a company)"
    param :form, :default_daily_end, :integer, :optional, "The default end of business hours each day (in seconds since midnight) (will override all other service area schedules for a company)"
    response :ok
    response :not_found
  end

  def get_global_settings
    authorize @user.company
    #Appointment lead times
    if @user.company
      render json: {status: 'SUCCESS', message: nil, data: @user.company.detailed_object}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :get_global_settings do
    summary "Gets a company's global settings"
    response :ok
    response :not_found
  end

  private
  def company_params
    params.permit(:id, :page, :name, :url, :contact_name, :contact_number,
      :billing_acct_code, :code, :ok_by, :modified_by, {inspectable_hosts: []}, :logo,
      :default_slot_duration, :default_max_appointments_per_slot, :default_daily_start,
      :default_daily_end, {:default_days_of_week => []}, :address1, :address2, :address3,
      :city, :state_name, :zip_code, :entity_type, :creation_lead_time, :modification_lead_time,
      :cancellation_lead_time)
  end
end
