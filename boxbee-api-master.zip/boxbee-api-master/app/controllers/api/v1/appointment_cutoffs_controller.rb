class Api::V1::AppointmentCutoffsController < ApiController
  swagger_controller :appointment_cutoffs, "Manages appointment cutoff times"

  def create
    appointment_cutoff = AppointmentCutoff.new(ac_params.except(:product_id))
    authorize appointment_cutoff
    appointment_cutoff = set_product(appointment_cutoff)
    appointment_cutoff.created_by, appointment_cutoff.modified_by = @user.id, @user.id
    if appointment_cutoff.save!
      render json: {status: 'SUCCESS', message: nil,
        data: appointment_cutoff.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new appointment cutoff record for a product"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :product_id, :integer, :required, "The product ID this appointment cutoff belongs to"
    param :form, :cutoff_type, :string, :required, "The type of appointment cutoff (can be 'creation', 'cancellation', 'modification')"
    param :form, :lead_time, :integer, :required, "The lead time (in hours) associated with the cutoff. For creation and modification cutoffs, this is the minimum time between now and the window start time of the appointment. For cancellation, this is the time since the appointment was created"
    param :form, :active, :boolean, :optional, "Specifies whether the record is good to use. Defaults to true."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    appointment_cutoff = policy_scope(AppointmentCutoff).find(ac_params[:id])
    authorize appointment_cutoff
    render json: {status: 'SUCCESS', message: nil,
      data: appointment_cutoff.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a appointment cutoff record"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The appointment cutoff ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    appointment_cutoff = policy_scope(AppointmentCutoff).find(ac_params[:id])
    authorize appointment_cutoff
    appointment_cutoff.modified_by = @user.id
    appointment_cutoff = set_product(appointment_cutoff) if ac_params[:product_id]
    if appointment_cutoff.update_attributes!(ac_params.except(:product_id))
      appointment_cutoff = appointment_cutoff.detailed_object
      render json: {status: 'SUCCESS', message: nil, data: appointment_cutoff}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a appointment cutoff record"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The appointment cutoff ID"
    param :form, :product_id, :integer, :optional, "The product ID this appointment cutoff belongs to"
    param :form, :cutoff_type, :string, :optional, "The type of appointment cutoff (can be 'creation', 'cancellation', 'modification')"
    param :form, :lead_time, :integer, :optional, "The lead time (in hours) associated with the cutoff. For creation and modification cutoffs, this is the minimum time between now and the window start time of the appointment. For cancellation, this is the time since the appointment was created"
    param :form, :active, :boolean, :optional, "Specifies whether the record is good to use. Defaults to true."
    response :ok
    response :not_found
    response :unauthorized
  end

  def product
    appointment_cutoffs = policy_scope(AppointmentCutoff).by_product(ac_params[:product_id])
    render json: {status: 'SUCCESS', message: nil,
      data: appointment_cutoffs.map(&:detailed_object)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all appointment cutoffs for a given product"
    notes "Permitted roles: admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The product ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end


  private
  def ac_params
    params.permit(:id, :product_id, :cutoff_type, :lead_time, :active, :page)
  end

  def set_product(appointment_cutoff)
    if @user.super_user?
      appointment_cutoff.product = Product.find(ac_params[:product_id])
    else
      appointment_cutoff.product = Product.by_company(@user.company_id)
        .find(ac_params[:product_id])
    end
    return appointment_cutoff
  end
end
