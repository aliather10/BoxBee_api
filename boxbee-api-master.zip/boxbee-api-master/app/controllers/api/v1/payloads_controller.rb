class Api::V1::PayloadsController < ApiController
  swagger_controller :payloads, "Manages payloads for drivers' routes to/from customers"

  def create
    payload = Payload.new(payload_params.except(:appointment_detail_id, :warehouse_id))
    authorize payload
    payload.warehouse_id = policy_scope(Warehouse)
      .find(payload_params[:warehouse_id]).id if payload_params[:warehouse_id]
    payload.appointment_detail_id = policy_scope(AppointmentDetail)
      .find(payload_params[:appointment_detail_id]).id
    payload.created_by, payload.modified_by = @user.id, @user.id
    if payload.save!
      render json: {status: 'SUCCESS', message: nil, data: payload.detailed_object},
        status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new payload"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :appointment_detail_id, :integer, :required, "The ID of the appointment_detail this payload belongs to"
    param :form, :warehouse_id, :integer, :required, "The warehouse ID"
    param :form, :name, :integer, :required, "The name of the item_type (e.g. 'Yellow Box')"
    param :form, :status, :string, :required, "The status of the payload. Can be: 'scheduled', 'with_user', 'on_truck', 'in_transit', 'in_storage', 'ignored', 'extinct'"
    param :form, :staging_location_id, :integer, :optional, "The location ID of the staging location"
    param :form, :sku, :string, :optional, "If the item_type is 'container': The id of the item_type. If the type is 'customer_item', then the barcode of the customer_items"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def show
    payload = policy_scope(Payload).find(payload_params[:id])
    authorize payload
    render json: {status: 'SUCCESS', message: nil, data: payload.detailed_object},
      status: :ok
  end

  swagger_api :show do
    summary "Retrieves a payload by ID"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be retrieved"
    response :ok
    response :unauthorized
    response :not_found
  end

  def update
    payload = policy_scope(Payload).find(payload_params[:id])
    authorize payload
    payload.appointment_detail_id = policy_scope(AppointmentDetail)
      .find(payload_params[:appointment_detail_id]).id if payload_params[:appointment_detail_id]
    payload.modified_by = @user.id
    payload.warehouse_id = policy_scope(Warehouse)
      .find(payload_params[:warehouse_id]).id if payload_params[:warehouse_id]
    if payload.update_attributes!(payload_params.except(:appointment_detail_id, :warehouse_id))
      render json: {status: 'SUCCESS', message: nil, data: payload.detailed_object},
        status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a payload"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be updated"
    param :form, :appointment_detail_id, :integer, :optional, "The ID of the appointment_detail this payload belongs to"
    param :form, :warehouse_id, :integer, :optional, "The warehouse ID"
    param :form, :name, :integer, :optional, "The name of the item_type (e.g. 'Yellow Box')"
    param :form, :status, :string, :optional, "The status of the payload. Can be: 'scheduled', 'with_user', 'on_truck', 'in_transit', 'in_storage', 'ignored', 'extinct'"
    param :form, :staging_location_id, :integer, :optional, "The location ID of the staging location"
    param :form, :sku, :string, :optional, "If the item_type is 'container': The id of the item_type. If the type is 'customer_item', then the barcode of the customer_items"
    response :ok
    response :unauthorized
    response :bad_request
  end


  def destroy
    payload = policy_scope(Payload).find(payload_params[:id])
    authorize payload
    if payload.destroy!
      render json: {status: 'SUCCESS', message: nil, data: payload},
        status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a payload by ID"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be retrieved"
    response :ok
    response :unauthorized
    response :not_found
  end

  def company
    if payload_params[:company_id] == 'current'
      payloads = policy_scope(Payload).by_company(current_company.id)
    else
      payloads = policy_scope(Payload).by_company(payload_params[:company_id])
    end
    authorize payloads
    payloads = payloads.by_transit_type(payload_params[:transit_type]) if payload_params[:transit_type]
    payloads = payloads.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: payloads.map(&:detailed_object),
      pagination: with_paging_info(payloads)}, status: :ok
  end

  swagger_api :company do
    summary "Lists all transit event payloads by a specified company ID"
    notes "Permitted roles: supervisor, driver, warehouse_staff, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :company_id, :integer, :required, "The ID of the company to list records for. Use 'current' for the company belonging to the current logged in user"
    param :query, :transit_type, :string, :optional, "The transit_type to filter by (can be 'delivery' or 'pickup')"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def route
    payloads = policy_scope(Payload).by_company(@user.company_id).by_route(payload_params[:route_id])
    authorize payloads
    payloads = payloads.by_transit_type(payload_params[:transit_type]) if payload_params[:transit_type]
    payloads = payloads.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: payloads.map(&:detailed_object),
      pagination: with_paging_info(payloads)}, status: :ok
  end

  swagger_api :route do
    summary "Lists all transit event payloads by a specified route ID"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :route_id, :integer, :required, "The ID of the route whose transit event payloads are to be returned"
    param :query, :transit_type, :string, :optional, "The transit_type to filter by (can be 'delivery' or 'pickup')"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def unload_van
    authorize policy_scope(Payload)
    payloads = policy_scope(Payload).find(payload_params[:payload_ids])
    inventories = []
    payloads.each do |payload|
      #Create inventory record and assign it to only staging location
      inventories << Inventory.create!(
        location: policy_scope(Location).by_location_type(:staging).first, #assuming 1 staging location per company,
        inventory_type: :customer_item,
        inventory_name: payload.name,
        sku: payload.sku, #The barcode ID
        quantity: 1, #assuming no empty containers
        created_by: 1,
        modified_by: 1
      )
    end
    render json: {status: 'SUCCESS', message: 'New inventories successfully created and van unloaded.',
      data: inventories}
  end

  swagger_api :unload_van do
    summary "Transfers all items from the van to a staging location"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :payload_ids, :integer, :required, "An array of payload IDs to be transferred from the van to the staging area, format: '[15, 178, 251]'"
    response :ok
    response :unauthorized
    response :not_found
  end

  def mass_assign_barcodes
    payloads = []
    payload_params[:payload_barcodes].each do |obj|
      payload = policy_scope(Payload).find(obj['payload_id'])
      authorize payload
      # Find corresponding customer_item
      payload.sku = obj['barcode']
      payload.save!
      payloads << payload
    end
    render json: {status: 'SUCCESS', message: nil, data: payloads},
      status: :ok
  end

  swagger_api :mass_assign_barcodes do
    summary "Mass assigns barcodes to payloads"
    notes "Permitted roles: supervisor, admin, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :payload_barcodes, :string, :required, "A JSON array of payload_ids and their respective new barcodes, e.g. '[{payload_id: 17, barcode: 983457}, {}, ...]'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  private
  def payload_params
    params.permit(:id, :appointment_detail_id, :appointment_action_detail_id, :transit_type,
      :request_type, :warehouse_id, :group_name, :active_plan_name, :payload_name,
      :payload_value, :payload_status, :staging_location_num, :added_on_spot, :company_id,
      :route_id, {payload_ids: []}, {payload_barcodes: [:payload_id, :barcode]}, :page)
  end
end
