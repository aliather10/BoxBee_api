class Api::V1::ProductsController < ApiController
  skip_before_action :authenticate_user, only: :show
  skip_after_action :verify_policy_scoped
  swagger_controller :products, "Manages products"

  def create
    product = Product.new(product_params.except(:company_id, :currency, :empty_delivery_price,
      :packed_pickup_price, :packed_delivery_price, :empty_pickup_price, :logo_image))
    authorize product
    product.created_by, product.modified_by = @user.id, @user.id
    product.company_id = @user.super_user? ? product_params[:company_id] : @user.company_id
    product.logo_image_url = decode_picture_data(product_params[:logo_image])
    product.about_us_image = decode_picture_data(product_params[:about_us_image])
    if product.save!
      render json: {status: 'SUCCESS', message: nil, data: product.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new product for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of the product"
    param :form, :description, :string, :required, "The description of the product"
    param :form, :company_id, :integer, :required, "The ID of the company this record also belongs to"
    param :form, :active, :boolean, :required, "Whether or not this product is good for use. Should be true"
    param :form, :marketing_url, :string, :optional, "The unique FULL URL of the maketing site for this product"
    param :form, :customer_portal_url, :string, :optional, "The unique FULL URL of the customer portal for this product"
    param :form, :logo_image, :string, :required, "Product logo in Base64 format 'data:image/png;base64,iVBORw0KGgo......'"
    param :form, :support_phone, :string, :required, "The support phone of this company"
    param :form, :support_email, :string, :required, "The support email of this company"
    param :form, :currency, :string, :required, "Currency as a 3 letter string, e.g. 'usd'"
    param :form, :empty_delivery_price, :integer, :optional, "Empty delivery price expressed in CENTS (default: 0 cents)"
    param :form, :packed_pickup_price, :integer, :optional, "Packed pickup price expressed in CENTS (default: 0 cents)"
    param :form, :packed_delivery_price, :integer, :optional, "Packed delivery price expressed in CENTS (default: 0 cents)"
    param :form, :empty_pickup_price, :integer, :optional, "Empty pickup price expressed in CENTS (default: 0 cents)"
    param :form, :meta_tags, :string, :optional, "Meta tags for SEO, as an array"
    param :form, :theme, :string, :required, "The identifier of the appropriate color theme to use (for now 'red', 'green', 'yellow', 'blue')"
    param :form, :hero_text, :string, :required, "The hero text"
    param :form, :description_text, :text, :required, "The main description text"
    param :form, :what_we_store, :text, :required, "The text underneath 'What we store'"
    param :form, :how_it_works1, :text, :required, "How it works text, first from left"
    param :form, :how_it_works2, :text, :required, "How it works text, second from left"
    param :form, :how_it_works3, :text, :required, "How it works text, third from left"
    param :form, :our_plans, :text, :required, "Text underneath 'our plans'"
    param :form, :areas_of_operation, :text, :required, "Areas served, as an array"
    param :form, :closing_cta, :text, :required, "The button text for the CTA button"
    param :form, :about_us_title, :text, :required, "Title of about us page"
    param :form, :about_us_body, :text, :required, "Body text of about us page"
    param :form, :about_us_image, :text, :required, "Upload field for about us page. The URL of the uploaded image will be available as a string in this field after upload."
    param :form, :terms_title, :string, :required, "The title of the TOS page"
    param :form, :terms_body, :text, :required, "The text the terms of service (TOS) page"
    param :form, :storage_terms, :string, :required, "The body of the storage rules page"
    param :form, :faq_title, :string, :required, "The title of the FAQ page"
    param :form, :twitter_url, :string, :optional, "The business' Twitter URL (full http URL)"
    param :form, :facebook_url, :string, :optional, "The business' Facebook URL (full http URL)"
    param :form, :instagram_url, :string, :optional, "The business' Instagram URL (full http URL)"
    param :form, :pinterest_url, :string, :optional, "The business' Pinterest URL (full http URL)"
    param :form, :yelp_url, :string, :optional, "The business' Yelp URL (full http URL)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    if product_params[:id] == 'current'
      product = current_product
    else
      authenticate_user
      product = policy_scope(Product).find(product_params[:id])
      verify_policy_scoped
    end
    authorize product
    render json: {status: 'SUCCESS', message: nil, data: product.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a product record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :optional, "The logged in user's token must be passed in the header. Only required if using a value other than 'current' for id"
    param :path, :id, :integer, :required, "The product ID. Can use 'current' for current product"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    product = policy_scope(Product).find(product_params[:id])
    authorize product
    product.logo_image_url = decode_picture_data(product_params[:logo_image]) if product_params[:logo_image]
    if product.update_attributes!(product_params.except(:company_id, :logo_image))
      render json: {status: 'SUCCESS', message: nil, data: product.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a product for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The product ID"
    param :form, :name, :string, :optional, "The name of the product"
    param :form, :description, :string, :optional, "The description of the product"
    param :form, :active, :boolean, :optional, "Whether or not this product is good for use. Should be true"
    param :form, :marketing_url, :string, :optional, "The unique FULL URL of the maketing site for this product"
    param :form, :customer_portal_url, :string, :optional, "The unique FULL URL of the customer portal for this product"
    param :form, :logo_image, :string, :optional, "Product logo in Base64 format 'data:image/png;base64,iVBORw0KGgo......'"
    param :form, :support_phone, :string, :optional, "The support phone of this company"
    param :form, :support_email, :string, :optional, "The support email of this company"
    param :form, :currency, :string, :optional, "Currency as a 3 letter string, e.g. 'usd'"
    param :form, :empty_delivery_price, :integer, :optional, "Empty delivery price expressed in CENTS (default: 0 cents)"
    param :form, :packed_pickup_price, :integer, :optional, "Packed pickup price expressed in CENTS (default: 0 cents)"
    param :form, :packed_delivery_price, :integer, :optional, "Packed delivery price expressed in CENTS (default: 0 cents)"
    param :form, :empty_pickup_price, :integer, :optional, "Empty pickup price expressed in CENTS (default: 0 cents)"
    param :form, :meta_tags, :string, :optional, "Meta tags for SEO, as an array"
    param :form, :theme, :string, :optional, "The identifier of the appropriate color theme to use (for now 'red', 'green', 'yellow', 'blue')"
    param :form, :hero_text, :string, :optional, "The hero text"
    param :form, :description_text, :text, :optional, "The main description text"
    param :form, :what_we_store, :text, :optional, "The text underneath 'What we store'"
    param :form, :how_it_works1, :text, :optional, "How it works text, first from left"
    param :form, :how_it_works2, :text, :optional, "How it works text, second from left"
    param :form, :how_it_works3, :text, :optional, "How it works text, third from left"
    param :form, :how_it_works4, :text, :optional, "How it works text, fourth from left"
    param :form, :our_plans, :text, :optional, "Text underneath 'our plans'"
    param :form, :areas_of_operation, :text, :optional, "Areas served, as an array"
    param :form, :closing_cta, :text, :optional, "The button text for the CTA button"
    param :form, :about_us_title, :text, :optional, "Title of about us page"
    param :form, :about_us_body, :text, :optional, "Body text of about us page"
    param :form, :about_us_image, :text, :optional, "Upload field for about us page. The URL of the uploaded image will be available as a string in this field after upload."
    param :form, :terms_title, :string, :optional, "The title of the TOS page"
    param :form, :terms_body, :text, :optional, "The text the terms of service (TOS) page"
    param :form, :storage_terms, :string, :optional, "The body of the storage rules page"
    param :form, :faq_title, :string, :optional, "The title of the FAQ page"
    param :form, :twitter_url, :string, :optional, "The business' Twitter URL (full http URL)"
    param :form, :facebook_url, :string, :optional, "The business' Facebook URL (full http URL)"
    param :form, :instagram_url, :string, :optional, "The business' Instagram URL (full http URL)"
    param :form, :pinterest_url, :string, :optional, "The business' Pinterest URL (full http URL)"
    param :form, :yelp_url, :string, :optional, "The business' Yelp URL (full http URL)"
    param :form, :default_tax, :decimal, :optional, "The default tax rate expressed as a percentage (e.g. 5.5% should be expressed as '5.5')"
    param :form, :taxed_accounting_codes, :string, :optional, "An array of the accounting codes that are taxable by the company, e.g. ['1000', '1100']. For storage: 1000, delivery: 1100, misc: 1200"

    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    product = policy_scope(Product).find(product_params[:id])
    authorize product
    if product.destroy
      render json: {status: 'SUCCESS', message: nil, data: product}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :bad_request
    end
  end

  swagger_api :destroy do
    summary "Destroys a product record for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The product ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    products = policy_scope(Product)
    authorize products
    products = products.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: products.map(&:detailed_object),
      pagination: with_paging_info(products)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all products"
    notes "Permitted roles: admin"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def user
    products = policy_scope(Product).by_user(product_params[:user_id])
    authorize products
    products = products.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: products, pagination: with_paging_info(products)},
        status: :ok
  end

  swagger_api :user do
    summary "Lists all products for a particular user"
    notes "Permitted roles: admin, customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :user_id, :integer, :required, "The user ID."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def product_params
    params.permit(:id, :name, :description, :company_id, :active, :url,
      :logo_image, :logo_image_url, :support_phone, :support_email, :currency, :empty_delivery_price,
      :packed_pickup_price, :packed_delivery_price, :empty_pickup_price, :inspectable_host, :page,
      :meta_tags, :theme, :theme, :hero_text, :description_text, :description_text, :what_we_store,
      :how_it_works1, :how_it_works2, :how_it_works3, :how_it_works4, :our_plans, :areas_of_operation,
      :closing_cta, :about_us_title, :about_us_body, :about_us_image, :terms_title, :terms_body,
      :storage_terms, :faq_title, :contact_us_title, :contact_us_image,
      :name_of_business, :address1, :address2, :city, :state, :zip, :twitter_url, :facebook_url,
      :instagram_url, :pinterest_url, :yelp_url, {taxed_accounting_codes: []}, :default_tax)
  end
end
