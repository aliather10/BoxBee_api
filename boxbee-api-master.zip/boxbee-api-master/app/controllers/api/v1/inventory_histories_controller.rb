class Api::V1::InventoryHistoriesController < ApiController
  swagger_controller :inventory_histories, "Tracks changes in inventory records"

  def user
    inventory_histories = policy_scope(InventoryHistory).by_customer(ih_params[:customer_id])
    authorize inventory_histories
    inventory_histories = filter_by_date(inventory_histories) if ih_params[:start_date]
    inventory_histories = inventory_histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventory_histories,
      pagination: with_paging_info(inventory_histories)}, status: :ok
  end

  swagger_api :user do
    summary "Lists all inventory histories for a given user"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "The customer ID"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def location
    inventory_histories = policy_scope(InventoryHistory)
      .by_location(policy_scope(Location).find(ih_params[:location_id]))
    authorize inventory_histories
    inventory_histories = filter_by_date(inventory_histories) if ih_params[:start_date]
    inventory_histories = inventory_histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventory_histories,
      pagination: with_paging_info(inventory_histories)}, status: :ok
  end

  swagger_api :location do
    summary "Lists all inventory histories for a given set of location parameters"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :location_id, :integer, :required, "The Id of the location"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def customer_item
    inventory_histories = policy_scope(InventoryHistory).by_customer_item(ih_params[:sku])
    authorize inventory_histories
    inventory_histories = filter_by_date(inventory_histories) if ih_params[:start_date]
    inventory_histories = inventory_histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventory_histories,
      pagination: with_paging_info(inventory_histories)}, status: :ok
  end

  swagger_api :customer_item do
    summary "Lists all inventory histories for a given customer item barcode #"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :sku, :integer, :required, "The barcode of the customer item whose histories are to be retrieved"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def item_type
    inventory_histories = policy_scope(InventoryHistory).by_container(ih_params[:sku])
    authorize inventory_histories
    inventory_histories = filter_by_date(inventory_histories) if ih_params[:start_date]
    inventory_histories = inventory_histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventory_histories,
      pagination: with_paging_info(inventory_histories)}, status: :ok
  end

  swagger_api :item_type do
    summary "Lists all inventory histories for a given form factor"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :sku, :integer, :required, "The form factor ID"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def appointment
    inventory_histories = policy_scope(InventoryHistory)
      .by_appointment(ih_params[:appointment_id])
    authorize inventory_histories
    inventory_histories = filter_by_date(inventory_histories) if ih_params[:start_date]
    inventory_histories = inventory_histories.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: inventory_histories,
      pagination: with_paging_info(inventory_histories)}, status: :ok
  end

  swagger_api :appointment do
    summary "Lists all inventory histories for a given appointment"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :appointment_id, :integer, :required, "The transit event ID"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def ih_params
    params.permit(:user_id, :page, :sku, :appointment_id)
  end

  def set_date(inventory_histories)
    start_date = Date.strptime("#{ih_params[:start_date]}", "%s")
    end_date = Date.strptime("#{ih_params[:end_date]}", "%s") if ih_params[:end_date]
    if start_date && end_date
      return inventory_histories.select { |ih|
        ih.created_at >= start_date && ih.created_at <= end_date
      }
    elsif start_date
      return inventory_histories.select { |ih|
        ih.created_at >= start_date && ih.created_at <= (start_date + 1.day)
      }
    else
      raise StandardError "You must specify dates in the correct format"
    end
  end
end
