class Api::V1::HolidaysController < ApiController
  swagger_controller :holidays, "Manages holiday schedules (CLIENT LEVEL)"

  def create
    holiday = HolidaySchedule.new(holiday_params.except(:company_id, :date, :end_date))
    authorize holiday
    holiday.created_by, holiday.modified_by = @user.id, @user.id
    holiday.company_id = @user.company.id
    holiday = set_date(holiday)
    if holiday.save!
      render json: {status: 'SUCCESS', message: nil, data: holiday}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new holiday schedule record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of this holiday schedule, displayed to company admins"
    param :form, :date, :integer, :required, "The start date of the holiday schedule, as: UNIX timestamp"
    param :form, :end_date, :integer, :optional, "The end date of the holiday schedule. If not specified, the holiday will be assumed to only span one day, given by the 'date' parameter above."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    holiday = policy_scope(Holiday).find(holiday_params[:id])
    authorize holiday
    render json: {status: 'SUCCESS', message: nil, data: holiday}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a holiday schedule record"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The holiday schedule ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    holiday = policy_scope(Holiday).find(holiday_params[:id])
    authorize holiday
    holiday.modified_by = @user.id
    holiday = set_date(holiday) if holiday_params[:date] || holiday_params[:end_date]
    if holiday.update_attributes!(holiday_params.except(:date, :end_date))
      render json: {status: 'SUCCESS', message: nil, data: holiday}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a holiday schedule record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The holiday schedule ID"
    param :form, :name, :string, :optional, "The name of this holiday schedule, displayed to company admins"
    param :form, :date, :integer, :optional, "The start date of the holiday schedule as a UNIX timestamp"
    param :form, :end_date, :integer, :optional, "The end date of the holiday schedule. If not specified, the holiday will be assumed to only span one day, given by the 'date' parameter above."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    holiday = policy_scope(Holiday).find(holiday_params[:id])
    authorize holiday
    if holiday.destroy!
      render json: {status: 'SUCCESS', message: nil, data: holiday}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a holiday schedule record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The holiday schedule ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    holidays = policy_scope(Holiday)
    authorize holidays
    holidays = holidays.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: holidays, pagination: with_paging_info(holidays)},
      status: :ok
  end

  swagger_api :index do
    summary "Lists all holiday schedules"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def holiday_params
    params.permit(:id, :company_id, :name, :date, :end_date)
  end

  def set_date(holiday)
    if holiday_params[:date]
      holiday.date = Date.strptime("#{holiday_params[:date]}", "%s")
    end
    if holiday_params[:end_date]
      holiday.end_date = Date.strptime("#{holiday_params[:end_date]}", "%s")
    end
    return holiday
  end
end
