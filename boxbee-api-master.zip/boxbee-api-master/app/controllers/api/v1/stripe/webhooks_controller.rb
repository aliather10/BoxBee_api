class Api::V1::Stripe::WebhooksController < ApiController
  skip_before_action :authenticate_user
  skip_after_action :verify_authorized #for Pundit
  skip_after_action :verify_policy_scoped #for Pundit

  #####Not published to the Swagger API documentation for security reasons ########

  def new
    # If app environment is production, it must check for livemode. Otherwise for staging use livemode == false
    Resque.enqueue(StripeWebhookSyncJob, params[:data][:object][:id], params[:user_id])
    head status: :ok
  end
end
