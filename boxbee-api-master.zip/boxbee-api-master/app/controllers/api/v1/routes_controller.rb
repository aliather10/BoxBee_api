class Api::V1::RoutesController < ApiController
  swagger_controller :routes, "Manages routes"
  skip_after_action :verify_policy_scoped, only: :simulate
  skip_after_action :verify_authorized, only: :simulate

  def create
    route = policy_scope(Route).new(route_params.except(:company_id))
    authorize route
    route.company_id = current_company.id
    route.created_by, route.modified_by = @user.id, @user.id
    if route.save!
      route = route.appointments.empty? ? route.detailed_object_lite : route.detailed_object
      render json: {status: 'SUCCESS', message: nil, data: route},
        status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new route for a vehicle"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :vehicle_id, :integer, :optional, "The ID of the vehicle chosen for this route"
    param :form, :driver_id, :integer, :optional, "The user ID of the driver to drive this route"
    param :form, :status, :string, :required, "The status of this route (can be: 'created', 'confirmed', 'prepping', 'ready', 'outbound', 'inbound', 'completed')"
    param :form, :name, :string, :required, "The name of the route"
    response :ok
    response :unauthorized
    response :bad_request
  end


  def show
    route = policy_scope(Route).find(route_params[:id])
    authorize route
    route = route.appointments.empty? ? route.detailed_object_lite : route.detailed_object
    render json: {status: 'SUCCESS', message: nil, data: route},
      status: :ok
  end

  swagger_api :show do
    summary "Retrieves a route by ID"
    notes "Permitted roles: driver, warehouse_staff, supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be retrieved"
    response :ok
    response :unauthorized
    response :not_found
  end

  def update
    route = policy_scope(Route).find(route_params[:id])
    authorize route
    route.modified_by = @user.id
    if route.update_attributes!(route_params.except(:company_id))
    render json: {status: 'SUCCESS', message: nil, data: route},
      status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a route for a vehicle"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be updated"
    param :form, :vehicle_id, :integer, :optional, "The ID of the vehicle chosen for this route"
    param :form, :driver_id, :integer, :optional, "The user ID of the driver to drive this route"
    param :form, :status, :string, :optional, "The status of this route (can be: 'created', 'confirmed', 'prepping', 'ready', 'outbound', 'inbound', 'completed')"
    param :form, :name, :string, :optional, "The name of the route"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def destroy
    route = policy_scope(Route).find(route_params[:id])
    authorize route
    if route.destroy!
      render json: {status: 'SUCCESS', message: nil, data: route}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a route for a vehicle"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be updated"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def company
    WillPaginate.per_page = 10
    # If a company's products are in demo mode, fastlane to AppointmentModificationCutoff so that routes can be created
    product_statuses = @user.company.products.map(&:status)
    if product_statuses.size == product_statuses.select{|status| status == 'demo'}.size && (@user.admin? || @user.supervisor?)
      appointments = policy_scope(Appointment).where(status: 'scheduled').each do |appointment|
        AppointmentCutoff.move_appointment_to_confirmed(appointment.id)
      end
    end
    if route_params[:company_id] == 'current'
      routes = policy_scope(Route)
    else
      routes = policy_scope(Route).by_company(route_params[:company_id])
    end
    authorize routes
    routes = filter_by_date(routes) if route_params[:start_date]
    routes = routes.by_status(route_params[:status]) if route_params[:status]
    routes = routes.map{|route| route.appointments.empty? ? route.detailed_object_lite : route.detailed_object}
    routes = routes.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: routes,
      pagination: with_paging_info(routes)}, status: :ok
  end

  swagger_api :company do
    summary "Lists all routes by a specified company ID"
    notes "Permitted roles: driver, warehouse_staff, supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :company_id, :integer, :required, "The ID of the company whose routes are to be returned. Use 'current' as the ID for the company of the currently logged in user"
    param :query, :status, :string, :optional, "The status to filter by. Can be: 'created', 'confirmed', 'prepping', 'ready', 'outbound', 'inbound', 'completed'"
    param :query, :start_date, :string, :optional, "The starting date to filter by according to the range of time of a route's transit events. Format: UNIX time stamp"
    param :query, :end_date, :string, :optional, "The ending date to filter by according to the range of time of a route's transit events. Format: UNIX time stamp. Requires a start_date. If end_date is not specified, it will be assumed that the range is the entire day of the start_date"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def driver
    if route_params[:user_id] == 'current'
      routes = policy_scope(Route).by_driver(@user.id)
    else
      routes = policy_scope(Route).by_driver(route_params[:user_id])
    end
    authorize routes
    routes = filter_by_date(routes) if route_params[:start_date]
    routes = routes.by_status(route_params[:status]) if route_params[:status]
    routes = routes.map{|route| route.appointments.empty? ? route.detailed_object_lite : route.detailed_object}
    routes = routes.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: routes,
      pagination: with_paging_info(routes)}, status: :ok
  end

  swagger_api :driver do
    summary "Lists all routes for the logged in driver"
    notes "Permitted roles: driver, warehouse_staff, supervisor, admin"
    param :query, :status, :string, :optional, "The status to filter by. Can be: 'created', 'confirmed', 'prepping', 'ready', 'outbound', 'inbound', 'completed'"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :user_id, :integer, :required, "The user_id of the driver to search by. Use 'current' for the currently logged in driver"
    param :query, :start_date, :string, :optional, "The starting date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp"
    param :query, :end_date, :string, :optional, "The ending date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp. Requires a start_date. If end_date is not specified, it will be assumed that the range is the entire day of the start_date"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def simulate
    if @user.company.products.map(&:status).include?('demo')
      key = "demo_route_simulator:company:#{@user.company_id}"
      service_area = @user.company.service_areas.first
      if REDIS.exists(key)
        if REDIS.hget(key, "status") == "completed"
          if REDIS.hget(key, "completed_time") && (DateTime.now > (DateTime.strptime("#{REDIS.hget(key, 'completed_time')}", "%s") + 24.hours))
            simulator(service_area)
          else
            render json: {status: 'SUCCESS', message: 'Route simulation complete', data: {status: :completed}}, status: :ok and return
          end
        elsif REDIS.hget(key, "status") == "in_progress"
          render json: {status: 'SUCCESS', message: 'Routes currently being simulated', data: {status: :in_progress}}, status: :created and return
        end
      end
      simulator(service_area)
    else
      render json: {status: 'FAILED', message: 'Cannot simulate routes for a live company', data: nil}, status: :bad_request
    end
  end

  swagger_api :simulate do
    summary "Simulates all routes for today's date"
    notes "Permitted roles: admin. Only works when a company's product is in demo mode"
    response :ok
    response :unauthorized
    response :bad_request
  end

  private
  def route_params
    params.permit(:id, :company_id, :name, {statuses: []},
      :driver_id, :status, :vehicle_id, :start_date, :end_date, :page)
  end

  def simulator(service_area)
    time_zone = service_area.time_zone
    Time.use_zone(time_zone) do
      datetime = Time.now.to_date.in_time_zone
      Resque.enqueue(DemoRouteSimulatorJob, @user.company_id, datetime.to_time.to_i)
    end
    render json: {status: 'SUCCESS', message: 'Beginning route simulation', data: {status: :started}}, status: :ok
  end

  def filter_by_date(routes)
    start_date = DateTime.strptime("#{route_params[:start_date]}", "%s") if route_params[:start_date]
    if route_params[:end_date]
      end_date = DateTime.strptime("#{route_params[:end_date]}", "%s")
    else
      end_date = start_date + 1.day
    end
    if start_date && end_date
      filtered_routes = routes.select do |route|
        range = route.datetime_range
        if range[:start] && range[:end]
          range[:start] >= start_date && range[:end] <= end_date
        end
      end
    end
    return filtered_routes
  end
end
