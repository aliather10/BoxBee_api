class Api::V1::ServiceAreaZipsController < ApiController
  swagger_controller :service_area_zips, "Associate zip codes with service areas"

  def create
    sa_zip = ServiceAreaZip.new(sa_zip_params.except(:service_area_id))
    authorize sa_zip
    sa_zip.created_by, sa_zip.modified_by = @user.id, @user.id
    sa_zip.service_area = policy_scope(ServiceArea).find(sa_zip_params[:service_area_id])
    if sa_zip.save!
      render json: {status: 'SUCCESS', message: nil, data: sa_zip.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new service area zip record for a service area"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :service_area_id, :integer, :required, "The service area ID that this schedule belongs to"
    param :form, :zip, :string, :required, "Can be 'service_area', 'city', 'state', 'zip', 'country'"
    param :form, :active, :boolean, :required, "Whether or not this record is good for use (should be true)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    sa_zip = policy_scope(ServiceAreaZip).find(sa_zip_params[:id])
    authorize sa_zip
    sa_zip.modified_by = @user.id
    sa_zip.service_area = policy_scope(ServiceArea)
      .find(sa_zip_params[:service_area_id]) if sa_zip_params[:service_area_id]
    if sa_zip.update_attributes!(sa_zip_params.except(:service_area_id))
      render json: {status: 'SUCCESS', message: nil, data: sa_zip.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a service area zip record for a service area"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area schedule ID"
    param :form, :service_area_id, :integer, :optional, "The service area ID that this schedule belongs to"
    param :form, :service_area_key, :string, :optional, "Can be 'service_area', 'city', 'state', 'zip', 'country'"
    param :form, :service_area_value, :string, :optional, "The value corresponding to the key above, e.g. '45', 'Boston', 'CT', or '10036'"
    param :form, :active, :boolean, :optional, "Whether or not this record is good for use (should be true)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    sa_zip = policy_scope(ServiceAreaZip).find(sa_zip_params[:id])
    authorize sa_zip
    if sa_zip.destroy!
      render json: {status: 'SUCCESS', message: nil, data: sa_zip}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a service area zip record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The service area schedule ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def sa_zip_params
    params.permit(:id, :service_area_id, :service_area_key, :service_area_value,
      :active)
  end
end
