class Api::V1::WarehouseTasksController < ApiController
  swagger_controller :warehouse_tasks, "Manages warehouse related tasks"

  def create
    task = WarehouseTask.new(task_params)
    authorize task
    task.company_id = @user.super_user? ? task_params[:company_id] : @user.company_id
    task.status = :created
    task.created_by, task.modified_by = @user.id, @user.id
    if task.save!
      render json: {status: 'SUCCESS', message: nil, data: task}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new warehouse task record"
    notes "Permitted roles: supervisor"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :location_id, :integer, :required, "The ID of the location"
    param :form, :customer_id, :integer, :optional, "The ID of the customer"
    param :form, :inventory_type, :string, :required, "Can be 'container', 'customer_item'"
    param :form, :inventory_name, :string, :required, "The name of the inventory e.g. 'yellow box'. It will usually be the name of the item_type"
    param :form, :sku, :string, :required, "The identifier of the inventory. Will be either the item_type ID (if it's a container) or the barcode number if it's a customer_item"
    param :form, :quantity, :integer, :required, "Should be 1 for packed customer items and some positive integer describing the quantity of containers in the location if it's a container"
    param :form, :route_id, :integer, :optional, "The ID of the associated route"
    param :form, :payload_id, :integer, :optional, "The ID of the associated payload that this task is preparing"
    param :form, :po_number, :string, :optional, "If for receiving new form factors from a supplier, this is the purchase task number"
    param :form, :task_type, :string, :optional, "Can be 'put' (for receiving orders of items arriving into the warehouse) or 'pick' (for items being prepared to leave the warehouse)"
    param :form, :status, :string, :required, "Can be 'created', 'started', 'completed', 'canceled', 'ignored', 'missing_item'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def update
    task = policy_scope(WarehouseTask).find(task_params[:id])
    authorize task
    task = set_client(task) if task_params[:company_id]
    task.modified_by = @user.id
    if task.update_attributes!(task_params)
      render json: {status: 'SUCCESS', message: nil, data: task}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a new warehouse task record"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the warehouse task to be updated"
    param :form, :location_id, :integer, :optional, "The ID of the location"
    param :form, :customer_id, :integer, :optional, "The ID of the customer"
    param :form, :inventory_type, :string, :optional, "Can be 'container', 'customer_item'"
    param :form, :inventory_name, :string, :optional, "The name of the inventory e.g. 'yellow box'. It will usually be the name of the item_type"
    param :form, :sku, :string, :optional, "The identifier of the inventory. Will be either the item_type ID (if it's a container) or the barcode number if it's a customer_item"
    param :form, :quantity, :integer, :optional, "Should be 1 for packed customer items and some positive integer describing the quantity of containers in the location if it's a container"
    param :form, :route_id, :integer, :optional, "The ID of the associated route"
    param :form, :payload_id, :integer, :optional, "The ID of the associated payload that this task is preparing"
    param :form, :po_number, :string, :optional, "If for receiving new form factors from a supplier, this is the purchase task number"
    param :form, :task_type, :string, :optional, "Can be 'put' (for receiving orders of items arriving into the warehouse) or 'pick' (for items being prepared to leave the warehouse)"
    param :form, :status, :string, :optional, "Can be 'created', 'started', 'completed', 'canceled', 'ignored', 'missing_item'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def warehouse
    tasks = policy_scope(WarehouseTask).by_warehouse(task_params[:warehouse_id])
    authorize tasks
    tasks = filter_by_date(tasks) if task_params[:start_date]
    tasks = tasks.by_task_type(task_params[:task_type]) if task_params[:task_type]
    tasks = tasks.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: tasks.map(&:detailed_object),
      pagination: with_paging_info(tasks)}, status: :ok
  end

  swagger_api :warehouse do
    summary "Lists all warehouse tasks by a specified warehouse code"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :warehouse_id, :integer, :required, "The warehouse ID"
    param :query, :task_type, :string, :optional, "Can be 'receiving' or 'shipping'"
    param :query, :start_date, :string, :optional, "The starting date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp"
    param :query, :end_date, :string, :optional, "The ending date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp. Requires a start_date. If end_date is not specified, it will be assumed that the range is the entire day of the start_date"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def route
    tasks = policy_scope(WarehouseTask).by_route(task_params[:route_id])
    authorize tasks
    tasks = filter_by_date(tasks) if task_params[:start_date]
    tasks = tasks.by_task_type(task_params[:task_type]) if task_params[:task_type]
    tasks = tasks.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: tasks.map(&:detailed_object),
      pagination: with_paging_info(tasks)}, status: :ok
  end

  swagger_api :route do
    summary "Lists all warehouse tasks by a specified route ID"
    notes "Permitted roles: supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :route_id, :string, :required, "The ID of the route to filter by"
    param :query, :task_type, :string, :optional, "Can be 'receiving' or 'shipping'"
    param :query, :start_date, :string, :optional, "The starting date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp"
    param :query, :end_date, :string, :optional, "The ending date to filter by according to the range of time of a route's transit events. Format: UNIX timestamp. Requires a start_date. If end_date is not specified, it will be assumed that the range is the entire day of the start_date"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def task_params
    params.permit(:id, :location_id, :user_id, :inventory_type, :inventory_name,
      :sku, :quantity, :route_id, :event_id, :payload_id, :po_number, :task_type,
      :status, :page, :start_date, :end_date, :warehouse_id)
  end

  def filter_by_date(tasks)
    start_date = DateTime.strptime("#{task_params[:start_date]}", "%s")
    end_date = DateTime.strptime("#{task_params[:end_date]}", "%s") if task_params[:end_date]
    if start_date && end_date
      tasks.select do |task|
        task.window_start_datetime >= start_date && task.window_end_datetime <= end_date
      end
    elsif start_date
      tasks.select do |task|
        task.window_start_datetime >= start_date && task.window_start_datetime <= (start_date + 1.day)
      end
    else
      raise StandardError "Could not obtain warehouse tasks with the date parameters specified."
    end
  end
end
