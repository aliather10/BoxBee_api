class Api::V1::PlansController < ApiController
  swagger_controller :plans, "Manages plans"
  skip_before_action :authenticate_user, only: :product
  skip_after_action :verify_policy_scoped, only: [:product, :available_item_types, :toggle_plans]
  skip_after_action :verify_authorized, only: :toggle_plans

  def create
    plan = policy_scope(Plan).new(plan_params)
    authorize plan
    plan.created_by, plan.modified_by = @user.id, @user.id
    if plan.save!
      render json: {status: 'SUCCESS', message: nil, data: plan.detailed_object}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new plan record for a product"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of the plan"
    param :form, :description, :string, :required, "The description"
    param :form, :product_id, :integer, :required, "The ID of the product this plan belongs to"
    param :form, :price_per_plan, :integer, :required, "The price of the plan in cents, e.g. $50/mo is '5000'"
    param :form, :length, :decimal, :optional, "The length of the form factor associated with this plan"
    param :form, :width, :decimal, :optional, "The width of the form factor associated with this plan"
    param :form, :height, :decimal, :optional, "The height of the form factor associated with this plan"
    param :form, :weight, :decimal, :optional, "The weight of the form factor associated with this plan"
    param :form, :active, :boolean, :required, "Whether or not this plan is good for use"
    param :form, :item_type, :integer, :required, "The item_type that this plan is attached to"
    param :form, :image, :string, :required, "A Base64 string representing the image"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def available_item_types
    authorize policy_scope(Plan)
    item_types = policy_scope(ItemType)
    render json: {status: 'SUCCESS', message: nil, data: item_types}
  end

  swagger_api :available_item_types do
    summary "Lists all of the available item types for a prospective company to choose"
    notes "Permitted roles: admin"
    response :ok
    response :not_found
  end

  def toggle_plans
    item_types = policy_scope(ItemType).find(plan_params[:item_type_ids])
    Plan.toggle_plans(item_types, @user.company.products.first)
    render json: {status: 'SUCCESS', message: nil, data: Plan.by_product(plan_params[:product_id])}
  end

  swagger_api :toggle_plans do
    summary "Adds and removes plans based on selected item_types"
    notes "Permitted roles: admin"
    param :form, :item_type_ids, :integer, :required, "A JSON array of item_type IDs, e.g. '[45, 46, 47]'"
    param :form, :product_id, :integer, :required, "The product ID to toggle plans for"
    response :ok
    response :not_found
  end

  def show
    plan = policy_scope(Plan).find(plan_params[:id])
    authorize plan
    render json: {status: 'SUCCESS', message: nil, data: plan.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a plan record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The plan ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    plan = policy_scope(Plan).find(plan_params[:id])
    authorize plan
    plan.modified_by = @user.id
    if plan.update_attributes!(plan_params)
      render json: {status: 'SUCCESS', message: nil, data: plan.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a plan record for a product"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The plan ID"
    param :form, :price_per_plan, :integer, :optional, "The price of the plan in cents, e.g. $50/mo is '5000'"
    param :form, :description, :string, :optional, "The description of the plan"
    param :form, :minimum_term, :integer, :optional, "The number of months minimum a customer must be subscribed to this plan (can be 0)"
    param :form, :name, :string, :optional, "The name of the plan"
    param :form, :active, :boolean, :optional, "Whether or not this plan is good for use"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def mass_update
    plans = []
    plan_params[:plans].each do |plan_obj|
      plan = policy_scope(Plan).find(plan_obj['plan_id'])
      authorize plan
      plan.modified_by = @user.id
      plan.price_per_plan = plan_obj['price_per_plan']
      plan.minimum_term = plan_obj['minimum_term']
      plan.save!
      plans << plan
    end
    render json: {status: 'SUCCESS', message: nil, data: plans}, status: :ok
  end

  swagger_api :mass_update do
    summary "Updates plan records en masse for a product"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :plans, :string, :required, "A JSON array of plans, prices and minimum terms, e.g.: '[{plan_id: 1, price_per_plan: 3000, minimum_term: 0}, {}, ...]' (price must be in cents)"
    response :ok
    response :bad_request
    response :unauthorized
  end


  def destroy
    plan = policy_scope(Plan).find(plan_params[:id])
    authorize plan
    if plan.destroy!
      render json: {status: 'SUCCESS', message: nil, data: plan}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Destroys a plan record for a client"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The plan ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    plans = policy_scope(Plan)
    authorize plans
    plans = plans.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: plans, pagination: with_paging_info(plans)},
        status: :ok
  end

  swagger_api :index do
    summary "Lists all plans"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :company_id, :integer, :optional, "Filter plans by client"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def product
    if plan_params[:product_id] == 'current'
      plans = Plan.by_product(current_product.id)
    else
      plans = policy_scope(Plan).by_product(plan_params[:product_id])
      verify_policy_scoped
    end
    authorize plans
    plans = plans.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: plans.map(&:detailed_object),
      pagination: with_paging_info(plans)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all plans by product"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The product ID. Can use 'current' for the current product"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def plan_params
    params.permit(:id, :name, :product_id, :length, :width, :height, :weight, :active,
      :description, :price_per_plan, :item_type_id, :page, :minimum_term,
      {plans: [:plan_id, :price_per_plan, :minimum_term]}, {item_type_ids: []})
  end
end
