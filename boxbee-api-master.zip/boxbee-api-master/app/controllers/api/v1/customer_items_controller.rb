class Api::V1::CustomerItemsController < ApiController
  swagger_controller :customer_items, "Items that belong to a customer (e.g. packed boxes)"

  def show
    ci = policy_scope(CustomerItem).find(ci_params[:id])
    authorize ci
    if ci
      render json: {status: 'SUCCESS', message: nil, data: ci.detailed_object},
        status: :ok
    end
  end

  swagger_api :show do
    summary "Retrieves an active form factor record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The active form factor ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    ci = policy_scope(CustomerItem).find(ci_params[:id])
    authorize ci
    ci.modified_by = @user.id
    ci.subscription_id = policy_scope(Subscription).find(ci_params[:subscription_id]).id if ci_params[:subscription_id]
    ci.item_type_id = policy_scope(ItemType).find(ci_params[:item_type_id]).id if ci_params[:item_type_id]
    ci.warehouse = policy_scope(Warehouse).find(ci_params[:warehouse_id]) if ci_params[:warehouse_id]
    if ci.update_attributes!(ci_params.except(:subscription_id, :item_type_id, :warehouse_id))
      render json: {status: 'SUCCESS', message: nil, data: ci.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates an existing active form factor record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The customer_item ID"
    param :form, :subscription_id, :integer, :optional, "The subscription ID representing her current subscription"
    param :form, :item_type_id, :integer, :optional, "The ID of the item_type"
    param :form, :barcode, :string, :optional, "The barcode identifier"
    param :form, :status, :integer, :optional, "The status of the customer_item: can be: 'scheduled', 'with_user', 'in_transit', 'in_storage', 'extinct'"
    param :form, :warehouse_id, :integer, :optional, "The warehouse ID"
    param :form, :name, :string, :optional, "The unique name of the customer's customer_item, e.g. 'My special box'"
    param :form, :description, :string, :optional, "The unique description of the customer's customer_item, e.g. '3 sweaters, winter hats, scarves'"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def product
    cis = policy_scope(CustomerItem).by_product(ci_params[:product_id])
    authorize cis
    cis = cis.by_status(ci_params[:status]) if ci_params[:status]
    cis = cis.by_transit_type(ci_params[:transit_type]) if ci_params[:transit_type]
    cis = cis.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: cis.map(&:detailed_object),
      pagination: with_paging_info(cis)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all customer items associated with a given product"
    notes "Permitted roles: customer_service, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :optional, "Product Id"
    param :query, :status, :integer, :optional, "The status of the customer_item: can be: 'scheduled', 'with_user', 'in_transit', 'in_storage', 'extinct'"
    param :query, :transit_type, :integer, :optional, "Further constrain results by transit type in Appointment Action Detail (can be 'pickup' or 'delivery')"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def customer
    if ci_params[:customer_id] == 'current'
      cis = policy_scope(CustomerItem).by_customer(current_customer.id)
    else
      cis = policy_scope(CustomerItem).by_customer(ci_params[:customer_id])
    end
    authorize cis
    cis = cis.by_status(ci_params[:status]) if ci_params[:status]
    cis = cis.by_transit_type(ci_params[:transit_type]) if ci_params[:transit_type]
    cis = cis.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: cis.map(&:detailed_object),
      pagination: with_paging_info(cis)}, status: :ok
  end

  swagger_api :customer do
    summary "Lists all customer items associated with the current product"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "Customer ID. Use 'current' for the current customer"
    param :query, :status, :integer, :optional, "Search for customer item by status. Can be 'scheduled', 'with_user', 'in_transit', 'in_storage', or 'extinct'"
    param :query, :transit_type, :integer, :optional, "Further constrain results by transit type in Appointment Detail (can be 'pickup' or 'delivery')"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def ci_params
    params.permit(:id, :customer_id, :subscription_id, :item_type_id, :barcode,
      :name, :description, :status, :length, :width, :height, :weight, :address_id,
      :warehouse_id, :transit_type, :product_id, :page)
  end
end
