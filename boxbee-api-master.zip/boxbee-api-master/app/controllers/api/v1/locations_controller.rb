class Api::V1::LocationsController < ApiController
  swagger_controller :locations, "Manages locations in a warehouse"

  def create
    location = Location.new(loc_params.except(:warehouse_id))
    authorize location
    location.warehouse_id = policy_scope(Warehouse).find(loc_params[:warehouse_id]).id if loc_params[:warehouse_id]
    location.created_by, location.modified_by = @user.id, @user.id
    if location.save!
      render json: {status: 'SUCCESS', message: nil, data: location}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new inventory location record"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :warehouse_id, :integer, :required, "The warehouse ID"
    param :form, :name, :string, :required, "The name of the location"
    param :form, :location_type, :string, :optional, "Can be 'permanent', 'staging', 'cart'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def update
    location = policy_scope(Location).find(loc_params[:id])
    authorize location
    location.warehouse_id = policy_scope(Warehouse).find(loc_params[:warehouse_id]).id if loc_params[:warehouse_id]
    location.modified_by = @user.id
    if location.update_attributes!(loc_params.except(:warehouse_id))
      render json: {status: 'SUCCESS', message: nil, data: location}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a inventory location record"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be updated"
    param :form, :warehouse_id, :integer, :optional, "The warehouse ID"
    param :form, :name, :string, :optional, "The name of the location"
    param :form, :location_type, :string, :optional, "Can be 'permanent', 'staging', 'cart'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def destroy
    location = policy_scope(Location).find(loc_params[:id])
    authorize location
    if location.destroy!
      render json: {status: 'SUCCESS', message: nil, data: location}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes a location by ID"
    notes "Permitted roles: supervisor, admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be deleted"
    response :ok
    response :unauthorized
    response :not_found
  end

  def warehouse
    locations = policy_scope(Location).by_warehouse(loc_params[:warehouse_id])
    authorize locations
    if loc_params[:location_types]
      loc_params[:location_types].each do |loc_type|
        locations = locations.by_location_type(loc_type)
      end
    end
    locations = locations.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: locations,
      pagination: with_paging_info(locations)}, status: :ok
  end

  swagger_api :warehouse do
    summary "Lists all locations by warehouse"
    notes "Permitted roles: supervisor, admin, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :warehouse_id, :integer, :required, "The warehouse ID"
    param :query, :location_types, :string, :optional, "e.g. '?location_types[]=reserve&location_types[]=forward'. Can be 'permanent', 'staging', or 'cart'"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  def index
    locations = policy_scope(Location)
    authorize locations
    if loc_params[:search]
      locations = Location.terms_for(loc_params[:search], @user.company_id)
      render json: {status: 'SUCCESS', message: nil, data: locations}, status: :ok and return
    end
    if loc_params[:location_types]
      loc_params[:location_types].each do |loc_type|
        locations = locations.by_location_type(loc_type)
      end
    end
    locations = locations.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: locations.map(&:detailed_object),
      pagination: with_paging_info(locations)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all locations by company"
    notes "Permitted roles: supervisor, admin, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :location_types, :string, :optional, "e.g. '?location_types[]=reserve&location_types[]=forward'. Can be 'permanent', 'staging', or 'cart'"
    param :query, :search, :string, :optional, "Search parameters for autocomplete. To return results, it must be a subset string of the location name. If this parameter is provided, all other parameters will be ignored."
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def loc_params
    params.permit(:id, :warehouse_id, :name,
      :location_type, :page, {location_types: []}, :search)
  end
end
