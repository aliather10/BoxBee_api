class Api::V1::DocsController < ApplicationController
  # before_action :authenticate_user!, only: :index
  def index
  end

  def swagger_json
    render json: JSON.parse(File.read(Rails.root.join('public', 'api-docs.json')))
  end
end
