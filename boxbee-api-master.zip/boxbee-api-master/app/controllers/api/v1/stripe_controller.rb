class Api::V1::StripeController < ApiController
  #The rest below is exception handles that return appropriate messages and corresponding
  #http status codes
  rescue_from Stripe::InvalidRequestError, :with => :invalid_request_error
  rescue_from Stripe::AuthenticationError, :with => :authentication_error
  rescue_from Stripe::CardError, :with => :card_error
  rescue_from Stripe::APIConnectionError, :with => :api_connection_error
  rescue_from Stripe::APIError, :with => :api_error
  rescue_from Stripe::RateLimitError, :with => :rate_limit_error
  rescue_from ActionDispatch::ParamsParser::ParseError, :with => :invalid_request_error

  private

  def invalid_request_error(exception)
    handle_error(exception, :bad_request)
  end

  def authentication_error(exception)
    handle_error(exception, :unauthorized)
  end

  def card_error(exception)
    handle_error(exception, :unprocessable_entity)
  end

  def api_connection_error(exception)
    handle_error(exception, :service_unavailable)
  end

  def api_error(exception)
    handle_error(exception, :service_unavailable)
  end

  def rate_limit_error(exception)
    handle_error(exception, :too_many_requests)
  end

  def handle_error(exception, status)
    render json: {status: 'failed', error: exception }, status: status
    Honeybadger.notify exception
  end
end
