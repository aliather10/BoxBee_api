class Api::V1::OnboardingsController < ApiController
  skip_before_action :authenticate_user, except: [:setup, :checklist_progress, :launch_product, :launch_demo, :request_invite]
  skip_after_action :verify_policy_scoped
  skip_after_action :verify_authorized, except: [:setup, :checklist_progress, :launch_product, :launch_demo]
  swagger_controller :onboardings, "For the onboarding process"

  def available_item_types
    item_types = Company.first.item_types
    render json: {status: 'SUCCESS', message: nil, data: item_types}
  end

  swagger_api :available_item_types do
    summary "Lists all of the available item types for a prospective company to choose"
    notes "Permitted roles: all (anonymous)"
    response :ok
    response :not_found
  end

  def new
    begin
      # Create new company
      company = Company.create!(onboarding_params.slice(:contact_name, :contact_email, :contact_number)
        .merge({
          name: onboarding_params[:company_name],
          created_by: 1,
          modified_by: 1,
          country: onboarding_params[:country]
        })
      )
      # Create and seed product
      product = Seeding::ProductSeeder.draft(company.id)
      product.status = :draft
      product.name = onboarding_params[:product_name]
      product.default_customer_portal_url = "https://#{onboarding_params[:subdomain]}.#{Figaro.env.APP_DOMAIN}"
      product.list_of_service_areas = "#{onboarding_params[:city]}"
      product.logo_image_url = decode_picture_data(onboarding_params[:product_logo]) if onboarding_params[:product_logo]
      product.save!
      # Process creation of plans and replications of images from their respective item_types in background
      # Map selected prototype item_ids to the item_ids of the company
      Resque.enqueue(SeedPlansJob, onboarding_params[:item_types], company.id)

      # Seed service areas
      Resque.enqueue(CreateDemoServiceAreaJob, onboarding_params[:city],
        onboarding_params[:state], onboarding_params[:country], company.id)
      Seeding::ProductSeeder.static_content(product.id)
      render json: {status: 'SUCCESS', message: 'Successfully created and seeded new product',
        data: product.as_json.merge({company: product.company})}
    rescue => error
      if company
        company.address_note_options.first.delete #Because this cannot be removed via destroy
        company.destroy!
      end
      #! Future suggestion for better error handling: Rollback creation of subdomain on Heroku and DNSimple
      invalid_request_or_unavailable(error)
    end
  end

  swagger_api :new do
    summary "Assembles and saves all company and product information during the onboarding process"
    notes "Permitted roles: all (anonymous)"
    param :form, :item_types, :string, :required, "An array of item type IDs to be accepted/provided by customers, e.g. '[1, 5, 7, 9]'"
    param :form, :city, :string, :required, "The name of the city (e.g. 'Baltimore')"
    param :form, :state, :string, :required, "The name of the state/province/region (e.g. 'Maryland')"
    param :form, :country, :string, :required, "The ISO abbreviation of the country (e.g. 'us')"
    param :form, :product_logo, :string, :optional, "A base 64 string of the product logo (300x500 or higher, formats: png, jpeg, jpg)"
    param :form, :subdomain, :string, :required, "The subdomain for the product e.g. 'storagesherpa' for storagesherpa.boxbee.com"
    param :form, :company_name, :string, :required, "The name of the company (not the brand/product name), e.g. 'StorageSherpa LLC'"
    param :form, :product_name, :string, :required, "The name of the product/brand, e.g. 'StorageSherpa'"
    param :form, :contact_name, :string, :required, "The name of the primary contact"
    param :form, :contact_number, :string, :required, "The phone number of the primary contact"
    param :form, :contact_email, :string, :required, "The email of the primary contact "
    response :ok
    response :not_found
    response :unauthorized
  end

  def register
    #Create admin user
    company = Company.find_by_token(onboarding_params[:company_token])
    admin_user = User.create!(
      company: company,
      first_name: onboarding_params[:first_name],
      last_name: onboarding_params[:last_name],
      email: company.contact_email,
      password: onboarding_params[:password],
      password_confirmation: onboarding_params[:password_confirmation],
      created_by: 1,
      modified_by: 1
    )
    admin_user.add_role :admin
    begin
      #Record IP address and save to companies table
      company_detail = CompanyDetail.new(company: company)
      company_detail.accepted_terms = true
      company_detail.accepted_terms_ip = request.remote_ip
      company_detail.save!

      product = company.products.first
      product.save!

      render json: {status: 'SUCCESS', message: nil, data: admin_user.detailed_object.merge({company_detail: company_detail})}
    rescue => error
      company_detail.destroy! if company_detail
      invalid_request_or_unavailable(error)
    end
  end

  swagger_api :register do
    summary "Registers an admin user and locks in temporary status of generated product"
    notes "Permitted roles: all (anonymous)"
    param :form, :company_token, :string, :required, "The token created during Company creation in the onboarding stage"
    param :form, :first_name, :string, :required, "The first name of the primary contact"
    param :form, :last_name, :string, :required, "The last name of the primary contact"
    param :form, :password, :string, :required, "The password"
    param :form, :password_confirmation, :string, :required, "The password confirmation"
    response :ok
    response :not_found
    response :unauthorized
  end

  def register_demo_only
    #Create admin user
    company = Company.create!(
                         contact_name: "#{onboarding_params[:first_name]} #{onboarding_params[:last_name]}",
                         name: onboarding_params[:company_name],
                         country: onboarding_params[:country],
                         created_by: 1,
                         modified_by: 1,
                         contact_email: onboarding_params[:contact_email],
                         contact_number: 'n/a'

    )
    password = Passgen::generate(:pronounceable => true, :lowercase => :only)
    admin_user = User.create!(
        company: company,
        first_name: onboarding_params[:first_name],
        last_name: onboarding_params[:last_name],
        email: company.contact_email,
        password: password,
        password_confirmation: password,
        created_by: 1,
        modified_by: 1
    )
    admin_user.add_role :admin
    BoxbeeMailer.log_into_demo(company, password).deliver_now
    begin
      #Record IP address and save to companies table
      company_detail = CompanyDetail.create(
                                        company: company,
                                        accepted_terms: true,
                                        accepted_terms_ip: request.remote_ip,
                                        currently_offer_storage: onboarding_params[:currently_offer_storage],
                                        currently_offer_pickup_delivery: onboarding_params[:currently_offer_pickup_delivery]
      )
      location = JSON.parse(open("http://ipinfo.io/#{request.remote_ip}").read)
      Resque.enqueue(SlackPreviewSignupJob, admin_user.id)
      render json: {status: 'SUCCESS', message: 'An email is now being sent to the registered user',
                    data: admin_user.as_json.merge({company: company, company_detail: company_detail, location_from_ip: location})}
    rescue => error
      company.destroy! if company
      admin_user.destroy! if admin_user
      company_detail.destroy! if company_detail
      invalid_request_or_unavailable(error)
    end
    # For Mixpanel tracking
    TRACKER.track(admin_user.id, 'Registered for preview')
    TRACKER.people.set(admin_user.id, {
        '$first_name' => admin_user.first_name,
        '$last_name' => admin_user.last_name,
        '$email' => admin_user.email,
        'currently_offer_storage' => company_detail.currently_offer_storage,
        'currently_offer_pickup_delivery' => company_detail.currently_offer_pickup_delivery,
        'company_name' => company.name,
        'country_from_ip' => location['country'],
        'state_from_ip' => location['region'],
        'city_from_ip' => location['city']
    })
  end

  swagger_api :register_demo_only do
    summary "Registers an admin user and locks in temporary status of generated product"
    notes "Permitted roles: all (anonymous)."
    param :form, :company_name, :string, :required, "The name of the company"
    param :form, :first_name, :string, :required, "The first name of the primary contact"
    param :form, :last_name, :string, :required, "The last name of the primary contact"
    param :form, :contact_email, :string, :required, "The email associated with the primary contact"
    param :form, :currently_offer_storage, :boolean, :required, "Whether or not the company currently offers storage"
    param :form, :currently_offer_pickup_delivery, :boolean, :required, "Whether or not the company offers pickup and delivery"
    param :form, :country, :string, :required, "The country, expressed in ISO 2 digit format (e.g. 'us' and 'ca'"
    response :ok
    response :not_found
    response :unauthorized
  end

  def cancel
    company = Company.find_by_token(onboarding_params[:company_token])
    subdomain = url_to_host(company.products.first.default_customer_portal_url).split('.')[0]
    # Delete subdomain on Heroku, DNSsimple
    Resque.enqueue(DeleteSubdomainJob, subdomain)
    company.address_note_options.first.delete
    if company.destroy!
      render json: {status: 'SUCCESS', message: nil, data: company}
    end
  end

  swagger_api :cancel do
    summary "Deletes a given company and product that doesn't complete the onboarding process"
    notes "Permitted roles: all (anonymous)"
    param :form, :company_token, :string, :required, "The token created during Company creation in the onboarding stage"
    response :ok
    response :not_found
    response :unauthorized
  end

  def send_sms_to_mobile
    confirmation = Onboarding.send_mobile_sms(onboarding_params[:phone])
    if confirmation
      render json: {status: 'SUCCESS', message: 'SMS successfully sent', data: confirmation}
    else
      render json: {status: 'FAILED', message: 'SMS could not be sent', data: nil}
    end
  end

  swagger_api :send_sms_to_mobile do
    summary "Sends a text message with a link to the Google Play store to download the Boxbee companion app"
    notes "Permitted roles: all (anonymous)"
    param :form, :phone, :string, :required, "The phone number to send the text to, e.g. '+14157894988'. Only + and trailing integers are accepted. Format: '+[country_code][number]', e.g.: '+12125558989'"
    response :ok
    response :not_found
    response :unauthorized
  end

  def launch_demo
    authorize :onboarding, :launch_demo?
    product = current_company.products.first
    #Create subdomain
    subdomain = url_to_host(product.default_customer_portal_url).split('.')[0]
    autogen_customer_portal = Onboarding.create_subdomain(subdomain)
    #Change product status to :demo
    product.status = :demo
    product.save!
    #Seeding
    Resque.enqueue(CreateDemoSeedsJob, product.id, 3.months, true)
    render json: {status: 'SUCCESS', message: 'The product is currently being seeded in the background for the demo', data: product}
  end

  swagger_api :launch_demo do
    summary "Takes a product to demo after meeting all the basic configuration requirements"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    response :ok
    response :bad_request
    response :unauthorized
  end


  def launch_product
    ### This method is deprecated ### Can safely ignore.

    
    #Must be run AFTER launch_demo #! Check product status should == :demo
    authorize :onboarding, :launch_product?
    #! Check to make sure we're at 100% completion
    #! Change product status to :active
    #! Use current_company. We need X-USER-TOKEN and pundit for this!
    #! Update Stripe managed account to LIVE one
    #! Delete select data to get to clean slate for LIVE mode
    ##* All REDIS StripeSync data need to be cleared out for that company.
    ##* Delete any customers (and their associated users, addresses, subscriptions-manual)
    ##*..appointment holds, customer_items, customer_fees,
    ##*Wipe out customer_item_histories, inventories, inventory_histories, payloads, reports, route_histories, routes, warehouse_tasks
    #! Start seeding slots, and any other standard data preparations (after basic configuration settings)
  end

  swagger_api :launch_product do
    summary "Takes a product live after meeting all the basic configuration requirements"
    notes "Permitted roles: admin"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def request_invite
    authorize :onboarding, :request_invite?
    # Update company_detail record to indicate that company has been requested to go live
    company_detail = @user.company.company_detail
    company_detail.requested_invite = true
    company_detail.save!
    render json: {status: 'SUCCESS', message: 'The request to go live has been noted and sent to Boxbee admins', data: nil}
  end

  swagger_api :request_invite do
    summary "Creates request for company to go live"
    notes "Permitted roles: admin"
    response :ok
    response :unauthorized
  end

  def setup
    authorize :onboarding, :setup?
    checklist_items = nil
    onboarding_params.keys.each do |key|
      if key.to_s.include?('_checklist_items')
        checklist_items = onboarding_params[key]
      end
    end
    if Onboarding.save_progress(@user.company_id, onboarding_params[:checklist_name],
      checklist_items)
      checklist = Onboarding.checklist_progress(@user.company_id)
      render json: {status: 'SUCCESS', message: nil, data: checklist}
    end
  end

  swagger_api :setup do
    summary "Returns a collection of checklists and whether or not they are finished"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :checklist_name, :string, :required, "Can be 'product_setup', 'vehicle_setup', 'warehouse_setup', 'barcoding_setup', 'pricing_setup', 'company_setup', 'banking_setup'"
    param :form, :product_checklist_items, :string, :optional, "A JSON array of the filled out product checklist items. Format: '{days_of_week: ['sunday', 'monday', 'tuesday'], opening_time: 3600, closing_time: 7200, default_minimum_term: 6, default_tax_rate: 12.5}' (default_minimum_term is given in months)"
    param :form, :vehicle_checklist_items, :string, :optional, "A JSON array of the filled out vehicle checklist items. Format: '{name: Ford Van 1, year: 2015, make: Ford, model: F150}'"
    param :form, :barcoding_checklist_items, :string, :optional, "A JSON array of the filled out barcode checklist items. Format: '{confirmation: true}'"
    param :form, :warehouse_checklist_items, :string, :optional, "A JSON array of the filled out warehouse checklist items. Format: '{address1: , address2: , address3: , city: , state_name: , country_name: , zip_code: , storage_location_name: , staging_location_name: , cart_name: }'"
    param :form, :pricing_checklist_items, :string, :optional, "A JSON array of the filled out pricing checklist items. Format: '{delivery_fee: 4500, pickup_fee: 3000, currency: usd, plans: [{plan_id: 1, price: 1000}] }', all pricing amounts are in cents"
    param :form, :company_checklist_items, :string, :optional, "A JSON array of the filled out company checklist items. Format: '{entity_type: , entity_name: , address1: , address2: , address3: , city: , state_name: , country_name: , zip_code: }' The entity_type choices are 'llc', 'corporation', 's_corp', 'c_corp', 'partnership', 'sole_proprietorship'"
    param :form, :banking_checklist_items, :string, :optional, "A JSON array of the filled out banking checklist items. Format: '{confirmation: true, account_holder_name: , account_holder_email: , ssn: , dob: , government_id: , ein: , bank_routing_no: , bank_account_no: }'"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def checklist_progress
    authorize :onboarding, :checklist_progress?
    checklists = Onboarding.checklist_progress(current_company.id)
    render json: {status: 'SUCCESS', message: nil, data: checklists}
  end

  swagger_api :checklist_progress do
    summary "Returns a collection of checklists and whether or not they are finished"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    response :ok
    response :bad_request
    response :unauthorized
  end


  private
  def onboarding_params
    params.permit(
      :company_id,
      :pickup_fee,
      :delivery_fee,
      {item_types: []},
      :city,
      :state,
      :country,
      :product_logo,
      :subdomain,
      :company_name,
      :product_name,
      :contact_number,
      :contact_name,
      :contact_email,
      :company_token,
      :first_name,
      :last_name,
      :password,
      :password_confirmation,
      :phone,
      :currently_offer_storage,
      :currently_offer_pickup_delivery,
      :checklist_name,
      {product_checklist_items: [{days_of_week: []}, :opening_time, :closing_time, :default_minimum_term,
        :default_tax]},
      {vehicle_checklist_items: [:name, :year, :make, :model]},
      {warehouse_checklist_items: [:address1, :address2, :address3, :city, :state_name,
        :country_name, :zip_code, :storage_location_name, :staging_location_name, :cart_name]},
      {barcoding_checklist_items: [:confirmation]},
      {pricing_checklist_items: [:currency, :delivery_fee, :pickup_fee, {plans: [:plan_id, :price]}]},
      {company_checklist_items: [:entity_type, :entity_name, :address1, :address2, :address3, :city, :state_name,
        :country_name, :zip_code]},
      {banking_checklist_items: [:confirmation, :account_holder_name, :account_holder_email,
        :ssn, :dob, :government_id, :ein, :bank_routing_no, :bank_account_no]},
    )
  end
end
