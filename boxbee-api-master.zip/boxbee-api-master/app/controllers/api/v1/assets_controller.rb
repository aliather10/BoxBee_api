class Api::V1::AssetsController < ApiController
  swagger_controller :assets, "Assets are images and other files attached to Customer Items"

  def create
    asset = Asset.new(asset_params.except(:customer_item_id, :sort_order, :asset_value))
    authorize asset
    asset.created_by, asset.modified_by = @user.id, @user.id
    asset.customer_item_id = policy_scope(CustomerItem).find(asset_params[:customer_item_id])
    asset = set_sort_order(asset)
    asset.asset_value = decode_picture_data(asset_params[:asset_value])
    if asset.save!
      render json: {status: 'SUCCESS', message: nil, data: asset}, status: :ok
    end
  end

  swagger_api :create do
    summary "For uploading a new image (or other asset) to a customer item"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :customer_item_id, :integer, :required, "The ID of the plan this asset belongs to"
    param :form, :asset_type, :string, :required, "Can be 'text', 'video', 'document', 'image', or 'html'. Almost always will be 'image'."
    param :form, :asset_value, :string, :required, "The media itself (e.g. a .png file upload). After uploading to this field, the URL corresponding to the Amazon S3 storage location will be stored here"
    param :form, :sort_order, :integer, :required, "The order in sequence to display this asset (1 being first)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def destroy
    asset = policy_scope(Asset).find(asset_params[:id])
    authorize asset
    if asset.destroy!
      render json: {status: 'SUCCESS', message: nil, data: asset}, status: :ok
    end
  end

  swagger_api :destroy do
    summary "Deletes an asset record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The asset ID"
    response :ok
    response :bad_request
    response :unauthorized
  end

  private
  def asset_params
    params.permit(:id, :customer_item_id, :asset_type, :asset_value, :sort_order)
  end

  def set_sort_order(asset)
    sort_order = asset_params[:sort_order]
    ci = CustomerItem.find(asset_params[:customer_item_id])
    assets = ci.assets
    unless assets.empty?
      if sort_order == 1
        assets.each {|asset| asset.sort_order += 1; asset.save!}
      elsif sort_order < ci.assets.size
        assets.select {|asset| asset.sort_order >= sort_order}
          .each {|asset| asset.sort_order += 1; asset.save!}
      elsif sort_oder == ci.assets.size
        assets.select {|asset| asset.sort_order == sort_order}
          .each {|asset| asset.sort_order += 1; asset.save!}
      end
    end
    asset.sort_order = sort_order
    return asset
  end
end
