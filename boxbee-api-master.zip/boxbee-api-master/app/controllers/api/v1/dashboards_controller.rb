class Api::V1::DashboardsController < ApiController
  swagger_controller :dashboards, "Provides admin portal dashboard information"
  #! This is for demo purposes at the time of writing. 
  def index
    authorize :dashboard, :index?
    todays_appointments = []
    tomorrows_appointments = []
    recently_booked_appointments = []

    policy_scope(Appointment).each do |aptmt|
      authorize aptmt
      time_zone = policy_scope(ServiceArea).by_zip(aptmt.address.zip_code).first.time_zone
      Time.use_zone(time_zone) do
        aptmt_date = aptmt.window_start_datetime.in_time_zone.to_date
        today = Time.current.in_time_zone.to_date
        tomorrow = (Time.current.in_time_zone + 24.hours).to_date
        todays_appointments << aptmt.with_time_zone.merge({name: aptmt.customer.user.full_name}) if aptmt_date == today
        tomorrows_appointments << aptmt.with_time_zone.merge({name: aptmt.customer.user.full_name}) if aptmt_date == tomorrow
        recently_booked_appointments << aptmt.with_time_zone.merge({name: aptmt.customer.user.full_name}) if aptmt.created_at >= 7.days.ago
      end
    end
    unpaid_invoices = Invoice.by_company(@user.company_id).select{|inv| !inv['paid']}
    total_customers = policy_scope(Customer).count
    new_customers = policy_scope(Customer).where('customers.created_at >= ?', 7.days.ago).count
    #Revenues $ by mm-YYYY
    time = Time.now
    revenues = [{revenue: 0, date: time.to_date.to_time.to_i}]
    while time < 13.months.from_now
      time = time.end_of_month if revenues.size > 1
      time += 1.month
      revenues << {revenue: 0, date: time.to_i}
    end

    data = {
      company_id: @user.company_id,
      todays_appointments: todays_appointments,
      tomorrows_appointments: tomorrows_appointments,
      recently_booked_appointments: recently_booked_appointments,
      unpaid_invoices: unpaid_invoices,
      total_customers: total_customers,
      new_customers: new_customers,
      revenues: revenues
    }

    render json: {status: 'SUCCESS', message: nil, data: data}, status: :ok
  end

  swagger_api :index do
    summary "Fetches all data for admin portal dashboard"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    response :ok
    response :unauthorized
  end
end
