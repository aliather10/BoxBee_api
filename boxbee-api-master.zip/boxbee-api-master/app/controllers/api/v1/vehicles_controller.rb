class Api::V1::VehiclesController < ApiController
  swagger_controller :vehicles, "Manages vehicles"

  def create
    vehicle = Vehicle.new(vehicle_params.except(:company_id))
    authorize vehicle
    vehicle.company_id = @user.super_user? ? vehicle_params[:company_id] : @user.company_id
    vehicle.created_by, vehicle.modified_by = @user.id, @user.id
    if vehicle.save!
      render json: {status: 'SUCCESS', message: nil, data: vehicle}, status: :ok
    end
  end

  swagger_api :create do
    summary "Creates a new vehicle for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :name, :string, :required, "The name of the vehicle"
    param :form, :company_id, :integer, :required, "The ID of the company the vehicle belongs to"
    param :form, :year, :integer, :optional, "The year of the vehicle"
    param :form, :make, :string, :optional, "The make of the vehicle"
    param :form, :model, :string, :optional, "The model of the vehicle"
    param :form, :vin_num, :string, :optional, "The VIN (vehicle identification number) of the vehicle"
    param :form, :license_plate_num, :string, :optional, "The license plate of the vehicle"
    param :form, :active, :boolean, :optional, "Whether or not the vehicle is good for use (defaults to true)"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def update
    vehicle = policy_scope(Vehicle).find(vehicle_params[:id])
    authorize vehicle
    vehicle.modified_by = @user.id
    if vehicle.update_attributes!(vehicle_params.except(:company_id))
      render json: {status: 'SUCCESS', message: nil, data: vehicle}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a vehicle for a company"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be updated"
    param :form, :name, :string, :optional, "The name of the vehicle"
    param :form, :company_id, :integer, :optional, "The ID of the company the vehicle belongs to"
    param :form, :year, :integer, :optional, "The year of the vehicle"
    param :form, :make, :string, :optional, "The make of the vehicle"
    param :form, :model, :string, :optional, "The model of the vehicle"
    param :form, :vin_num, :string, :optional, "The VIN (vehicle identification number) of the vehicle"
    param :form, :license_plate_num, :string, :optional, "The license plate of the vehicle"
    param :form, :active, :boolean, :optional, "Whether or not the vehicle is good for use (defaults to true)"
    response :ok
    response :unauthorized
    response :bad_request
  end

  def destroy
    vehicle = policy_scope(Vehicle).find(vehicle_params[:id])
    authorize vehicle
    if vehicle.destroy!
      render json: {status: 'SUCCESS', message: nil, data: vehicle}, status: :ok
    else
      render json: {status: 'FAILED', message: nil, data: nil}, status: :not_found
    end
  end

  swagger_api :destroy do
    summary "Deletes a vehicle by ID"
    notes "Permitted roles: admin"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the record to be retrieved"
    response :ok
    response :unauthorized
    response :not_found
  end

  def company
    if vehicle_params[:company_id] == 'current'
      company_id = current_company.id
    else
      company_id = policy_scope(Company).find(vehicle_params[:company_id]).id
    end
    # authorize policy_scope(Company)
    vehicles = policy_scope(Vehicle).by_company(company_id)
    authorize vehicles
    vehicles = vehicles.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: vehicles,
      pagination: with_paging_info(vehicles)}, status: :ok
  end

  swagger_api :company do
    summary "Lists all vehicles by a specified company ID"
    notes "Permitted roles: admin, supervisor, driver, warehouse_staff"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :company_id, :integer, :required, "The ID of the company whose vehicles are to be returned. Use 'current' for the current customer"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :unauthorized
    response :not_found
  end

  private
  def vehicle_params
    params.permit(:id, :name, :company_id, :year, :make, :model, :vin_num,
      :license_plate_num, :active, :page)
  end
end
