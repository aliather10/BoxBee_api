class Api::V1::SearchSuggestionsController < ApiController
  skip_after_action :verify_policy_scoped
  swagger_controller :search_suggestions, "Search engine for autocomplete"

  def index
    authorize :search, :index?
    render json: {status: 'SUCCESS', message: nil,
      data: SearchSuggestion.terms_for(search_params[:term], @user.company_id)}
  end

  swagger_api :index do
    summary "Performs a search for autocomplete based on some input characters"
    notes "Currently the search is indexed for Invoice IDs, Appointment IDs, and Customer names"
    param :query, :term, :string, :required, "All or part of a word that is being queried. E.g. 'in_17t' to start searching for invoice 'in_17KWH1GtWBbsCJco0y2nT7H3'. All indexed objects (customers, appointments, invoices matching will be returned)"
    response :ok
    response :internal_server_error
  end

  private
  def search_params
    params.permit(:term)
  end
end
