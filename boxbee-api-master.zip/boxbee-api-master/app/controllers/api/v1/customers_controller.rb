class Api::V1::CustomersController < ApiController
  skip_before_action :authenticate_user, only: :create
  skip_after_action :verify_policy_scoped, only: :create
  skip_after_action :verify_authorized, only: :create

  swagger_controller :customers, "Manages customers"

  def create
    customer = Customer.new(cus_params.except(:product_id, :address, :note, :company_id,
      :address_note_option_id, :roles, :contact_detail, :first_name, :last_name, :email,
      :password, :password_confirmation))
    product = current_product

    user = User.create!({
      email: cus_params[:email],
      first_name: cus_params[:first_name],
      last_name: cus_params[:last_name],
      password: cus_params[:password],
      password_confirmation: cus_params[:password_confirmation],
      company_id: product.company_id,
      created_by: 1,
      modified_by: 1
    })
    user.add_role :customer
    address = Address.create!(cus_params[:address].merge({
      addressable_id: user.id,
      addressable_type: 'User',
      created_by: 1,
      modified_by: 1
    }))
    contact_detail = ContactDetail.create!(cus_params[:contact_detail].merge({
      user_id: user.id,
      created_by: 1,
      modified_by: 1
    }))

    customer.product = product
    customer.user_id = user.id
    customer.standing = :current
    customer.preferred_address_id = address.id
    customer.modified_by, customer.created_by = 1, 1

    begin
      if customer.save!
        render json: {status: 'SUCCESS', message: nil,
          data: customer.detailed_customer(user.token)}, status: :ok
      end
    rescue => error
      #Roll back creation of user in case of failure
      #(will cascade to contact_details and address as well)
      user.destroy!
      invalid_request_or_unavailable(error)
    end
  end

  swagger_api :create do
    summary "Creates a new customer record"
    notes "Permitted roles: no roles required (anonymous request OK)"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :optional_business_name, :string, :optional, "Business name"
    param :form, :company_id, :integer, :required, "Company ID. Required for super users and company admin/CS, but inferred for everyone else"
    param :form, :first_name, :string, :required, "The first name"
    param :form, :last_name, :string, :required, "The last name"
    param :form, :email, :string, :required, "The user's email (for login). Can be omitted if invitation_token present."
    param :form, :password, :string, :required, "The user's password (for login). Must be at least 8 characters long"
    param :form, :password_confirmation, :string, :required, "Password confirmation"
    param :form, :address, :string, :required, "A hash to construct the Address object (see Address#POST endpoint in UMS)"
    param :form, :address_note_option_id, :integer, :optional, "Optional if a custom note is applied instead (see below). Use 'custom' if it's a custom note"
    param :form, :note, :string, :optional, "Optional ONLY if address_note_option_id is used instead"
    param :form, :contact_detail, :string, :optional, "Required for new user registration. A hash to construct the ContactDetail object (see ContactDetail#POST endpoint)"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def update
    customer = policy_scope(Customer).find(cus_params[:id])
    authorize customer
    customer.modified_by = @user.id
    Resque.enqueue(DefaultCardJob, customer.id, cus_params[:default_card]) if cus_params[:default_card]
    if customer.update_attributes!(cus_params.except(:default_card))
      render json: {status: 'SUCCESS', message: nil, data: customer.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a customer record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the customer"
    param :form, :optional_business_name, :string, :optional, "Business name"
    param :form, :preferred_address_id, :integer, :optional, "The ID of the preferred Address for this customer"
    param :form, :default_card, :string, :optional, "The ID of the card to set as default, e.g. 'card_17iGDk2eZvKYlo2C49RP0HZq'"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    if cus_params[:id] == 'current'
      customer = policy_scope(Customer).where(product: current_product).find(current_customer.id)
    else
      customer = policy_scope(Customer).find(cus_params[:id])
    end
    authorize customer
    render json: {status: 'SUCCESS', message: nil, data: customer.detailed_object
      .merge({
        user: customer.user,
        addresses: customer.user.addresses,
        contact_details: customer.user.contact_details
      })
    }, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a customer record for a given user and product"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The ID of the product that this customer belongs to. Use 'current' for the currently logged in customer"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def product_user
    customer = policy_scope(Customer)
      .where(product: cus_params[:product_id], user: cus_params[:user_id]).first
    authorize customer
    render json: {status: 'SUCCESS', message: nil, data: customer.detailed_object.merge({user: customer.user})}, status: :ok
  end

  swagger_api :product_user do
    summary "Retrieves a customer record for a given user and product"
    notes "Permitted roles: admin, customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The ID of the product that this customer belongs to. Required for super users, company admins and company CS"
    param :path, :user_id, :integer, :required, "The ID of the product that this customer belongs to. Required for super users, company admins and company CS"
    response :ok
    response :bad_request
    response :unauthorized
  end

  def index
    customers = policy_scope(Customer)
    if cus_params[:product_id]
      customers = customers.by_product(cus_params[:product_id])
    end
    authorize customers
    customers = customers.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: Customer.detailed_customers(customers),
      pagination: with_paging_info(customers)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all customers associated with a product (or all companies if product_id is left blank)"
    notes "Permitted roles: admin, customer_service"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    param :query, :product_id, :integer, :optional, "ID of product to filter results by. Only required for superuser if listing by product. If any role wants to retrieve a collection by company instead, leave the product_id field blank."
    response :ok
    response :not_found
    response :unauthorized
  end

  private
  def cus_params
    params.permit(:id, :product_id, :company_id, :user_id, :optional_business_name, :preferred_address_id,
      :last_appointment_address_id, :email, :password, :password_confirmation, :note, :default_card,
      :address_note_option_id, {:contact_detail => [:mode_key, :mode_value]}, :first_name, :last_name,
      {address: [:address1, :address2, :address3, :gps_latitude_point, :gps_longitude_point,
      :city, :state_name, :zip_code, :country_name]}, :page)
  end
end
