class Api::V1::UsersController < ApiController
  skip_before_action :authenticate_user, only: [:check_email]
  skip_after_action :verify_policy_scoped, only: [:check_email, :update]
  skip_after_action :verify_authorized, only: [:check_email]
  swagger_controller :users, "Manage users"

  def show
    if user_params[:id] == 'current'
      user = current_user
    else
      user = policy_scope(User).find(user_params[:id])
    end
    authorize user
    user = @user.super_user? ? User.find(user_params[:id]) : @user.company.users.find(user_params[:id])
    render json: {status: 'SUCCESS', message: nil, data: user.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Shows an individual user record"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the Client associated with user"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    if user_params[:id] == 'current'
      user = current_user
    else
      user = policy_scope(User).find(user_params[:id])
      verify_policy_scoped
    end
    authorize user
    if user_params[:add_roles] || user_params[:remove_roles]
      user = User.role_adjuster(user, user_params[:add_roles], user_params[:remove_roles])
    end
    if user.update_attributes!(user_params.except(:id, :address, :note, :address_note_option_id, :add_roles,
      :remove_roles).merge({modified_by: @user.id}))
      render json: {status: 'SUCCESS', message: nil, data: user.detailed_object}, status: :ok
    end
  end

  swagger_api :update do
    summary "Updates a user"
    notes "Permitted roles: all"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "Id of the User to be updated. Can use 'current' for the current user"
    param :form, :first_name, :string, :optional, "The full URL of the company (e.g. http://storagesherpa.com)"
    param :form, :last_name, :string, :optional, "The primary contact's phone number"
    param :form, :email, :string, :optional, "Email used for login"
    param :form, :password, :string, :optional, "New password used for login"
    param :form, :password_confirmation, :string, :optional, "Retyped new password used for login"
    param :form, :add_roles, :string, :optional, "An array of roles to be added"
    param :form, :remove_roles, :string, :optional, "An array of roles to be removed"
    response :ok
    response :bad_request
    response :not_found
    response :unauthorized
  end

  def check_email
    user = User.find_by_email(user_params[:email])
    if user || user_params[:email].nil?
      render json: {status: 'FAILED', message: 'A user already exists with this email or this is not a valid email',
        data: {available: false}}, status: :ok
    else
      render json: {status: 'SUCCESS', message: 'This email is available',
        data: {available: true}}, status: :ok
    end
  end

  swagger_api :check_email do
    summary "Checks the email submitted to make sure it's unique"
    notes "Permitted roles: all"
    param :form, :email, :string, :required, "The email to check"
    response :ok
  end

  private
  def user_params
    params.permit(:id, :page, :first_name, :middle_name, :last_name, :email,
      :password, :password_confirmation, :invitation_token,
      :note, :address_note_option_id, :roles, {:contact_detail => [:mode_key, :mode_value]},
      :company_id, {address: [:address1, :address2, :address3, :address4, :gps_latitude_ref,
      :gps_latitude_point, :gps_longitude_ref, :gps_longitude_point, :city, :state_name,
      :zip_code, :country_name]}, :add_roles, :remove_roles, {roles: []}, :phone)
  end

  def check_invitation(invitation)
    if invitation.nil?
      unauthorize
    else
      invitation.client
    end
  end
end
