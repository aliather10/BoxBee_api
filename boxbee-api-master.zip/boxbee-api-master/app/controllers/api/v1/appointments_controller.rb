class Api::V1::AppointmentsController < ApiController
  before_filter :check_creation_cutoff, only: :create
  swagger_controller :appointments, "Manages appointments"

  def create
    appointment = Appointment.new(aptmt_params.except(:customer_id, :note,
      :address_note_option_id, :cart, :appointment_hold_id, :stripe_token))
    authorize appointment
    appointment.status = :scheduled
    appointment = set_window(appointment, aptmt_params[:appointment_hold_id])
    appointment = set_customer(appointment)
    appointment.associate_address(aptmt_params[:address_id])
    appointment.created_by, appointment.modified_by = @user.id, @user.id
    #Create appointment_details, subscriptions, and customer_items from cart

    if appointment.save!
      #Create a stripe customer with card details and associate it to the Customers table
      #If a stripe token is not provided (e.g. appointment for existing customer) this will be ignored
      appointment.customer.create_and_associate_stripe_customer(aptmt_params[:stripe_token]) if aptmt_params[:stripe_token]
      valid_cart = appointment.process_cart(aptmt_params[:cart], @user.id, @user.company_id)
      unless valid_cart # If cart is not processed successfully, delete the appointment.
        appointment.delete!
        appointment.customer.destroy!
        return failed_appointment
      end
      existing_fee = CustomerFee.find_by_appointment_id(appointment.id)
      history = existing_history ||= CustomerFee.new(appointment_id: appointment.id,
        customer_id: appointment.customer_id, created_by: 1)
      history.modified_by = 1
      history = apply_prices_to_history(history, appointment.customer.product)
      history.save!
      #Create AppointmentNote
      Resque.enqueue(AppointmentAssociateNoteJob, aptmt_params[:note],
        aptmt_params[:address_note_option_id], @user.company_id,
        appointment.as_json, @user.id)
      #Sync contact details
      Resque.enqueue(AppointmentSyncContactDetailsJob, appointment.id)
      render json: {status: 'SUCCESS', message: nil, data: appointment.detailed_object}, status: :ok and return
    end
  end

  swagger_api :create do
    summary "Creates a new appointment record for a customer"
    notes "Warning: Super users may NOT use this endpoint. Only authorized for clients and their customers."
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :preferred_phone, :string, :required, "The preferred phone number of the customer (any standard phone string format is ok)"
    param :form, :preferred_email, :string, :required, "The preferred email of the customer ('abc@example.com')"
    param :form, :appointment_hold_id, :integer, :required, "The ID of the temporary appointment hold that was made when the user selected a slot on the calendar"
    param :form, :address_id, :integer, :required, "An ID of a user's address"
    param :form, :cart, :string, :required, "An array of JSON objects detailing what customer items, containers, etc. are going to/from the customer (see https://github.com/BoxbeeStorage/boxbee-api for more info on how to construct this object)"
    param :form, :customer_id, :integer, :required, "The ID of the customer that this appointment is associated to"
    param :form, :note, :string, :optional, "The custom note. REQUIRED if address_note_option_id not provided below."
    param :form, :address_note_option_id, :integer, :optional, "REQUIRED if note not provided. The ID of the company configured address note option can be used in lieu of the note above"
    param :form, :stripe_token, :integer, :optional, "The stripe token ID returned from StripeJS. If a stripe_token is not passed, it will be assumed that the customer already has a default credit card on file."
    response :ok
    response :bad_request
    response :unauthorized
  end

  def show
    appointment = policy_scope(Appointment).find(aptmt_params[:id])
    authorize appointment
    render json: {status: 'SUCCESS', message: nil,
      data: appointment.detailed_object}, status: :ok
  end

  swagger_api :show do
    summary "Retrieves a appointment record"
    notes "You must know the exact ID of the appointment record"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The appointment ID"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update
    appointment = policy_scope(Appointment).find(aptmt_params[:id])
    authorize appointment
    time_zone = ServiceArea.by_product(appointment.customer.product_id).by_zip(appointment.address.zip_code).first.time_zone
    check_cancellation_cutoff(appointment, time_zone)
    appointment = set_window(appointment, aptmt_params[:appointment_hold_id]) if aptmt_params.keys.include?('appointment_hold_id')
    appointment.associate_address(aptmt_params[:address_id]) if aptmt_params[:address_id]
    appointment.modified_by = @user.id
    handle_modification_cutoff(appointment, time_zone) do
      if appointment.update_attributes!(aptmt_params.except(:product_id, :user_id, :note,
        :address_note_option_id, :cart, :appointment_hold_id))
        appointment.process_cart(aptmt_params[:cart], @user.id, @user.company_id) if aptmt_params[:cart]
        Resque.enqueue(AppointmentAssociateNoteJob, aptmt_params[:note],
          aptmt_params[:address_note_option_id], appointment.customer.product.company_id,
          appointment.as_json, @user.id)
        render json: {status: 'SUCCESS', message: nil,
          data: appointment.detailed_object}, status: :ok
        return appointment
      end
    end
  end

  swagger_api :update do
    summary "Updates a appointment record"
    notes "Warning: Not authorized for superusers. Also, Appointments cannot be updated after reaching a status of 'completed'"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :id, :integer, :required, "The appointment ID"
    param :form, :preferred_phone, :string, :optional, "The preferred phone number of the customer (any standard phone string format is ok)"
    param :form, :preferred_email, :string, :optional, "The preferred email of the customer ('abc@example.com')"
    param :form, :appointment_hold_id, :integer, :optional, "The ID of the temporary appointment hold that was made when the user selected a slot on the calendar"
    param :form, :address_id, :integer, :optional, "An ID of a user's address"
    param :form, :cart, :string, :optional, "An array of JSON objects detailing what customer items, containers, etc. are going to/from the customer (see https://github.com/BoxbeeStorage/boxbee-api for more info on how to construct this object)"
    param :form, :note, :string, :optional, "The custom note. REQUIRED if address_note_option_id not provided below."
    param :form, :address_note_option_id, :integer, :optional, "REQUIRED if note not provided. The ID of the company configured address note option can be used in lieu of the note above"
    param :form, :stripe_token, :integer, :optional, "The stripe token returned from StripeJS. If a stripe_token is not passed, it will be assumed that the customer already has a default credit card on file."
    param :form, :status, :string, :optional, "Can be 'scheduled', 'confirmed', 'started', 'completed', 'canceled', 'failed', 'voided'"
    response :ok
    response :bad_request
    response :unauthorized
  end


  def customer
    if aptmt_params[:customer_id] == 'current'
      appointments = policy_scope(Appointment).by_product(current_product.id)
        .by_user(current_user.id)
    else
      appointments = policy_scope(Appointment).by_customer(aptmt_params[:customer_id])
    end
    authorize appointments
    appointments = Appointment.filter_by_status(appointments, aptmt_params[:statuses]) if aptmt_params[:statuses]
    appointments = appointments.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil,
      data: appointments.map(&:detailed_object),
      pagination: with_paging_info(appointments)}, status: :ok
  end

  swagger_api :customer do
    summary "Lists all appointments belonging to a specified user"
    notes "Warning: This endpoint is only permitted for users with roles of 'boxbee', 'system', and 'admin'"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :customer_id, :integer, :required, "The customer ID. (can use 'current' for the currently logged in customer)"
    param :query, :statuses, :string, :optional, "Statuses to tighten the query (e.g. ?status[]=scheduled&status[]=confirmed'. Choices are 'scheduled', 'confirmed', 'canceled', 'voided')"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end


  def product
    appointments = policy_scope(Appointment).by_product(aptmt_params[:product_id])
    authorize appointments
    appointments = filter_by_date(appointments) if aptmt_params[:start_date]
    appointments = Appointment.filter_by_status(appointments, aptmt_params[:statuses]) if aptmt_params[:statuses]
    appointments = appointments.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil,
      data: appointments, pagination: with_paging_info(appointments)}, status: :ok
  end

  swagger_api :product do
    summary "Lists all appointments belonging to a specified product"
    notes "Permitted roles: customer_service, admin, boxbee, system"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :path, :product_id, :integer, :required, "The user ID. Required for all users with roles above customer."
    param :query, :statuses, :string, :optional, "Statuses to tighten the query (e.g. ?status[]=scheduled&status[]=confirmed'. Choices are 'scheduled', 'confirmed', 'canceled', 'voided')"
    param :query, :start_date, :integer, :optional, "The start date of a range to query appointments (based on window_start_datetime). Given as UNIX timestamp"
    param :query, :end_date, :integer, :optional, "The end date of a range to query appointments (based on window_start_datetime). If blank, the system will assume the range is just the start_date. Given as UNIX timestamp"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def index
    appointments = policy_scope(Appointment)
    authorize appointments
    appointments = Appointment.filter_by_status(appointments, aptmt_params[:statuses]) if aptmt_params[:statuses]
    appointments = filter_by_date(appointments)
    appointments = appointments.paginate(page: page)
    render json: {status: 'SUCCESS', message: nil, data: appointments.map(&:detailed_object_lite),
      pagination: with_paging_info(appointments)}, status: :ok
  end

  swagger_api :index do
    summary "Lists all appointments for a specified company"
    notes "Warning: Only authorized for client admin and cs and super users"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :query, :company_id, :integer, :required, "The client ID. Required for super users"
    param :query, :statuses, :string, :optional, "Statuses to tighten the query (e.g. ?status[]=scheduled&status[]=confirmed'. Choices are 'scheduled', 'confirmed', 'canceled', 'voided')"
    param :query, :start_date, :integer, :optional, "Filter results based on start_date (expressed as UNIX timestamp, e.g. 12/25/2015 would be expressed as '1451019600'"
    param :query, :end_date, :integer, :optional, "Filter results based on end_date (if start_date is specified but no end_date, it will be assumed that the end_date is today's date)"
    param :query, :page, :integer, :optional, "Pagination page to query (defaults to page 1 if no number is provided)"
    response :ok
    response :not_found
    response :unauthorized
  end

  def update_sort_order
    route_sort_orders = aptmt_params[:route_sort_orders]
    sort_orders = route_sort_orders.map {|rso| rso['appointment_id']}
    appointments = []
    if sort_orders.size == sort_orders.uniq.size
      route_sort_orders.each do |aptmt|
        appointment = policy_scope(Appointment).find(aptmt['appointment_id'])
        authorize appointment
        appointment.route_sort_order = aptmt['route_sort_order']
        appointment.route = policy_scope(Route).find(aptmt['route_id'])
        appointment.save!
        appointments << appointment
      raise StandardError "You must submit appointment_ids belonging to the same route for each request" if !appointments.empty? && (appointment.route != appointments.first.try(:route))
      end
      render json: {status: 'SUCCESS', messsage: 'Update transit event sort orders successfully',
        data: appointments.first.route.detailed_object}, status: :ok
    else
      render json: {status: 'FAILED', messsage: 'You must supply unique appointment_id values', data: nil}, status: :bad_request
    end
  end

  swagger_api :update_sort_order do
    summary "Allows for mass updating the route sort orders of transit events"
    notes "You must submit appointment_ids belonging to the same route for each request"
    param :header, 'X-USER-TOKEN', :string, :required, "The logged in user's token must be passed in the header"
    param :form, :route_sort_orders, :string, :required, "A JSON array of of appointment IDs and route sort orders and the route that the appointment should be assigned to, ex.: '[{appointment_id: 145, route_sort_order: 1, route_id: 1}, {appointment_id: 146, route_sort_order: 2, route_id: 2}]'"
    response :ok
    response :unauthorized
    response :bad_request
  end

  private
  def aptmt_params
    params.permit(:id, :product_id, :company_id, :customer_id, :ref_num, :ship_to_first_name, :ship_to_last_name,
      :ship_to_business_name, :preferred_phone, :preferred_email, :status, :scheduled_date, :window_start_time,
      :window_end_time, :canceled_timestamp, {statuses: []}, {cart: [:plan_id, :action, :quantity, :request_type,
      :transit_type, :active_form_factor_id]}, :note, :address_note_option_id, :address_id, :appointment_hold_id, :page,
      :stripe_token, :start_date, :end_date, {route_sort_orders: [:appointment_id, :route_sort_order, :route_id]})
  end

  def set_window(appointment, appointment_hold_id = nil)
    if appointment_hold_id
        slot = AppointmentHold.slot(appointment_hold_id)
      if slot
        appointment.window_start_datetime = slot.start_datetime
        appointment.window_end_datetime = slot.end_datetime
        AppointmentHold.delete_existing_holds(appointment.preferred_email)
      else
        raise NoMethodError "The appointment hold as expired. Please try again"
      end
    end
    return appointment
  end

  def set_customer(appointment)
    customer = policy_scope(Customer).where(id: aptmt_params[:customer_id] ||= current_customer.id).first
    appointment.customer = customer
    return appointment
  end

  def check_creation_cutoff
    unless @user.customer_service?
      slot = AppointmentHold.slot(aptmt_params[:appointment_hold_id])
      raise NoMethodError "Your slot has expired" unless slot
      creation_cutoff = current_product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types['creation']).first
      time_zone = ServiceArea.by_product(aptmt_params[:product_id] ||= current_product.id)
        .by_zip(Address.find(aptmt_params[:address_id]).zip_code).first.time_zone
      Time.use_zone(time_zone) do
        if Time.current.in_time_zone + creation_cutoff.lead_time.hours < slot.start_datetime
          return true
        else
          render json: {status: 'FAILED', message: 'This is past the creation cutoff date and time for this product.', data: nil}
          return false
        end
      end
    end
  end

  def check_cancellation_cutoff(appointment, time_zone)
    unless @user.customer_service?
      if aptmt_params[:status] == 'canceled'
        cancellation_cutoff = appointment.customer.product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types['cancellation']).first
        Time.use_zone(time_zone) do
          if Time.current.in_time_zone - cancellation_cutoff.lead_time.hours < appointment.created_at
            return true
          else
            render json: {status: 'FAILED', message: 'This is past the cancellation cutoff date and time for this product.', data: nil}
            return false
          end
        end
      end
    end
  end

  def handle_modification_cutoff(appointment, time_zone)
    modification_cutoff = appointment.customer.product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types['modification']).first
    Time.use_zone(time_zone) do
      if Time.current.in_time_zone + modification_cutoff.lead_time.hours < appointment.window_start_datetime
        yield
      else
        if @user.customer_service?
          appointment = yield
          if appointment
            Resque.enqueue(TransferAppointmentsToTmsJob, appointment.id)
          end
        else
          render json: {status: 'FAILED', message: 'This appointment is past the modification cutoff for this product.',
            data: nil}, status: :bad_request
            return false
        end
      end
    end
  end

  def filter_by_date(appointments)
    start_date = Date.strptime("#{aptmt_params[:start_date]}", "%s") if aptmt_params[:start_date]
    if aptmt_params[:end_date]
      end_date = Date.strptime("#{aptmt_params[:end_date]}", "%s")
    else
      end_date = start_date + 1.day if start_date
    end
    if start_date && end_date
      return appointments.select do |appointment|
        appointment.window_start_datetime >= start_date && appointment.window_end_datetime <= end_date
      end
    else
      return appointments
    end
  end

  def failed_appointment
    render json: {status: 'FAILED', message: nil, data: nil}, status: :bad_request
  end
end
