class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  include Pundit
  include ApplicationHelper

  protect_from_forgery with: :exception

  require 'will_paginate/array' #Allows pagination to work on arrays as well as ActiveRecord queries
end
