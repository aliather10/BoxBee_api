class ApiController < ApplicationController
  skip_before_action :verify_authenticity_token
  before_action :authenticate_user
  before_action :check_product
  after_action :verify_authorized #for Pundit
  after_action :verify_policy_scoped #for Pundit

  unless Rails.env.development?
    rescue_from NoMethodError, :with => :invalid_request_or_unavailable
    rescue_from RuntimeError, :with => :runtime_error
    rescue_from ActiveRecord::RecordInvalid, :with => :record_invalid
    rescue_from ActiveRecord::RecordNotFound, :with => :record_not_found
    rescue_from Pundit::NotAuthorizedError, with: :user_not_authorized
  end

  private
  def authenticate_user
    if request.headers['X-USER-TOKEN']
      user_token = sanitize(request.headers['X-USER-TOKEN'])
      @user = User.find_by_token(user_token)
      #Set the platform (e.g. Boxbee) key. Required for all Stripe calls.
      #Check to see if first product for company is in demo mode or active
      if current_company.products.first.status == 'active'
        Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
      else
        Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
      end
      #Unauthorize if a user object is not returned
      if @user.nil?
        return unauthorize
      end
    else
      return unauthorize
    end
  end

  def unauthorize
    head status: :unauthorized
    return false
  end

  def current_user
    @user
  end


  def current_product
    if Rails.env.development?
      return Product.find(Figaro.env.DEV_DEFAULT_PRODUCT.to_i)
    end
    matching_products = Product.matching_products_for_host(url_to_host(request.headers['HTTP_ORIGIN']))
    if matching_products.empty?
      if request.headers['X-DEV-KEY'] == Figaro.env.DEV_KEY
        product = Product.find(Figaro.env.DEV_DEFAULT_PRODUCT.to_i)
      else
        unauthorize
      end
    else
      product = matching_products.first
    end
    return product
  end

  def current_customer
    customer = Customer.where(product: current_product, user: current_user).first
    return customer
  end

  def current_company
    @user.company
  end

  def check_product
    if @user && params[:product_id] && params[:product_id] != 'current'
      unless @user.super_user? || Product.find(params[:product_id]).company_id == @user.company_id.to_i
        render json: {status: 'FAILED', message: 'The product ID is not authorized for the current user',
          data: nil}, status: :unauthorized and return
      end
    end
  end

  def sanitize(string)
    string.gsub('+','%2B')
  end

  def set_company(object)
    object.company_id = @user.admin? ? @user.company_id : params[:company_id]
    return object
  end

  def url_to_host(url)
    URI.parse(url).host unless url.nil?
  end

  def with_paging_info(collection)
    {
      current_page: collection.current_page,
      per_page: collection.per_page,
      total_entries: collection.total_entries,
      total_pages: collection.total_pages
    }
  end

  def company_by_ip(ip)
    if ip == Figaro.env.DEV_IP_ADDRESS
      return Client.find(1)
    else
      return nil
    end
  end

  def decode_picture_data(picture_data)
    picture_payload = picture_data.split(',').last
    type_payload = picture_data.split(',').first.split(';').first.gsub('data:', '')
    # decode the base64
    data = StringIO.new(Base64.decode64(picture_payload))
    # assign some attributes for carrierwave processing
    data.class.class_eval { attr_accessor :original_filename, :content_type }
    data.original_filename = "upload-#{rand(1..100)}.#{type_payload.gsub('image/', '')}"
    data.content_type = type_payload
    # return decoded data
    data
  end

  def page
    page = params[:page] ||= 1
  end

  def invalid_request_or_unavailable(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "Either you provided incorrect parameters or" \
       "an external API/service is unavailable/malfunctioning. This error has been logged" \
       "and will be checked by Boxbee IT", error: exception.inspect}, status: :bad_request and return false
    Honeybadger.notify(exception)
  end

  def record_invalid(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "The record you are trying to save has " \
       "invalid parameters", error: exception.inspect}, status: :bad_request and return false
    Honeybadger.notify(exception)
  end

  def record_not_found(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "The record you are trying to locate " \
       "could not be found", error: exception.inspect}, status: :bad_request and return false
    Honeybadger.notify(exception)
  end

  def user_not_authorized(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "The credentials applied do not have sufficient " \
      "priviledges for this resource", error: exception.inspect}, status: :unauthorized and return false
  end

  def runtime_error(exception)
    puts "exception report: #{exception.inspect}"
    puts "exception backtrace: #{exception.backtrace}".truncate(4500)
    render json: {status: 'FAILED', message: "An error occurred at runtime", error: exception.inspect}, status: :bad_request and return false
  end
end
