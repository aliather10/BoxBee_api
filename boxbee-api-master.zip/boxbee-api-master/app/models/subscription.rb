class Subscription < ActiveRecord::Base
  attr_readonly :customer_id
  after_create :create_invoice_item

  belongs_to :plan
  belongs_to :customer
  has_many :customer_items
  has_many :item_types, through: :customer_items

  validates :plan, presence: true
  #validates :active, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates :price_per_plan, presence: true
  # validates :quantity, presence: true
  validates_uniqueness_of :plan, scope: :customer_id

  scope :by_user, ->(user_id) {joins(:customer)
    .where('customers.user_id = ?', user_id)}
  scope :by_company, ->(company_id) {joins(plan: :product)
    .where('products.company_id = ?', company_id)}
  scope :by_product, ->(product_id) {joins(plan: :product)
    .where('products.id = ?', product_id)}

  def detailed_object
    self.as_json.merge({plan: self.plan, customer_items: self.customer_items})
  end

  def create_invoice_item
    # This method left out for new version. Please fill in steps according to below if desired for new version.
    # Figure out prorated amount for the remainder of the month, (QTY * price_per_plan * (end_of_mo - current_day) / (days_in_month))
    # Figure out taxes for each invoice item based on global settings and indiv. taxes
    # What if just adding to a plan and not creating a whole new subscription?
  end
end
