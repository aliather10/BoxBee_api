class CustomerItemHistory < ActiveRecord::Base
  belongs_to :customer_item

  validates :customer_item_id, presence: true
  validates :current_status, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  default_scope  { order(:updated_at => :desc) }

  scope :by_customer_item, ->(aff_id) {where(customer_item_id: aff_id)}
  scope :by_appointment, ->(appointment_id) {
    where(appointment_id: appointment_id).order(:created_at => :asc)
  }
end
