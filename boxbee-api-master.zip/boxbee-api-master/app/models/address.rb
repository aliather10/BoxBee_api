class Address < ActiveRecord::Base
  belongs_to :addressable, polymorphic: true
  has_many :address_notes, dependent: :destroy
  has_many :address_note_options, through: :address_notes

  validates :address1, presence: true, length: {maximum: 100}
  validates :address2, length: {maximum: 100}
  validates :address3, length: {maximum: 100}
  validates :address4, length: {maximum: 100}
  validates :city, presence: true, length: {maximum: 50}
  validates :state_name, presence: true, length: {maximum: 50}
  validates :zip_code, presence: true, length: {maximum: 10}
  validates :country_name, presence: true, length: {maximum: 50}
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_user, ->(user_id) {
    where('addressable_type = ? AND addressable_id = ?', 'User', user_id)
  }
  scope :by_company, ->(company_id) {
    joins('JOIN users ON users.id = addressable_id')
    .joins('JOIN companies ON companies.id = users.company_id')
    .joins('JOIN warehouses ON warehouses.id = addressable_id')
    .where('companies.id = ? OR warehouses.company_id = ?', company_id, company_id)
  }

  # Make sure the same address isn't used twice.
  validates_uniqueness_of :addressable_id, scope: [:addressable_type, :address1, :address2, :address3, :address4,
    :city, :state_name, :zip_code, :country_name]

  def detailed_object
    self.as_json.merge({
      address_notes: self.address_notes,
    })
  end
end
