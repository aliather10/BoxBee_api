class InventoryHistory < ActiveRecord::Base
  validates :inventory_action, presence: true
  # validates :customer_id, presence: true
  validates :sku, presence: true, length: {maximum: 50}
  validates :inventory_type, presence: true
  validates :quantity, presence: true
  validates :created_by, presence: true

  default_scope {order(created_at: :desc)}

  scope :by_customer, ->(customer_id) {where(customer_id: customer_id)}
  scope :by_company, ->(company_id) {where(company_id: user_id)}
  scope :by_location, ->(location) {
    where(wh_code: location.wh_code, area: location.area, aisle: location.aisle,
      row: location.row, section: location.section, level: location.level)
  }
  scope :by_container, ->(it_sku) {where(inventory_type: :container, sku: it_sku)}
  scope :by_customer_item, ->(ci_sku) {where(inventory_type: :customer_item,
    sku: ci_sku)}

  enum inventory_action: [:put, :pick]
  enum inventory_type: [:container, :customer_item]
end
