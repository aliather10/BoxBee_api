class User < ActiveRecord::Base
  rolify :after_add => :update_mixpanel
  has_secure_token

  after_commit :update_search_index

  has_many :addresses, as: :addressable, dependent: :destroy
  has_many :contact_details, dependent: :destroy
  has_many :customers
  has_many :products, through: :customers
  has_many :subscriptions
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :recoverable, :rememberable,
         :trackable, :validatable, :lockable
  belongs_to :company
  validates :company, presence: true
  validates :first_name, presence: true, length: {in: 1..255}
  validates :last_name, presence: true, length: {in: 1..255}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates :email, presence: true

  scope :by_company, ->(company_id) {where(company_id: company_id)}

  def detailed_object
    self.as_json.merge({addresses: self.addresses, contact_details: self.contact_details,
      roles: self.roles_by_name, company_status: self.company.products.first.status})
  end

  def full_name
    "#{self.first_name} #{self.last_name}"
  end

  def self.apply_associations(user, user_params, roles = nil, requesting_user)
    if roles.nil?
      roles = user_params[:roles].split(", ")
    else
      roles = roles.split(", ")
    end
    roles.each {|r| user.add_role r}; user.save!

    if user_params[:address]
      address = Address.new(user_params[:address]); address.user = user
      address.created_by, address.modified_by = requesting_user.id, requesting_user.id
      address.save!
    end

    if user_params[:address_note_option_id]
      address_note = AddressNote.create(address: address,
        address_note_option: AddressNoteOption.find(user_params[:address_note_option_id]), created_by: user_params[:created_by],
        modified_by: user_params[:created_by])
    elsif user_params[:note]
      address_note = AddressNote.create(address: address,
        note: user_params[:note], created_by: user_params[:created_by],
        modified_by: user_params[:modified_by])
    end

    Rails.logger.debug "user_params[:communication #{user_params[:communication]}]"
    if user_params[:contact_detail]
      contact_detail = ContactDetail.new(user_params[:contact_detail])
      contact_detail.created_by, contact_detail.modified_by = requesting_user.id, requesting_user.id
      contact_detail.user = user; contact_detail.save!
    end
    return user
  end

  def roles_by_name
    self.roles.map {|r| r.name}
  end

  def self.role_adjuster(user, add_roles, remove_roles)
    add_roles.each {|ar| user.add_role ar} if add_roles
    remove_roles.each {|rr| user.remove_role rr} if remove_roles
    return user
  end

  def admin?
    self.has_role? :admin
  end

  def customer_service?
    self.has_role? :customer_service
  end

  def super_user?
    !(self.roles_by_name & %w{system boxbee}).empty?
  end

  def supervisor?
    self.has_role? :supervisor
  end

  def ground_staff?
    !(self.roles_by_name & %w{warehouse_staff driver}).empty?
  end

  def customer?
    !self.customers.empty?
  end

  def update_search_index
    if self.previous_changes[:first_name] || self.previous_changes[:last_name]
      self.customers.each do |customer|
        SearchSuggestion.update_customer_name(customer)
      end
    end
  end

  def update_mixpanel(args)
    TRACKER.people.union(self.id, {roles: self.roles})
  end

end
