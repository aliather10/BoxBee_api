class Plan < ActiveRecord::Base
  after_destroy :inactivate_item_type
  after_save :adjust_item_type

  belongs_to :product
  belongs_to :customer
  belongs_to :item_type
  has_many :subscriptions

  mount_uploader :image, AssetUploader

  validates :product, presence: true
  validates :item_type_id, presence: true
  validates :name, presence: true, length: {minimum: 0, maximum: 100}
  #validates :active, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :product_id, scope: :name
  validates_uniqueness_of :product_id, scope: :item_type_id

  scope :by_company, ->(company_id) {
    joins(:product)
    .where('products.company_id = ?', company_id)
  }
  scope :by_product, ->(product_id) {where(product_id: product_id)}
  scope :by_customer, ->(customer_id) {
    where(customer_id: customer_id)
  }

  def detailed_object
    self.as_json.merge({
      subscriptions: self.subscriptions,
      item_type: self.item_type
    })
  end

  def self.toggle_plans(item_types, product)
    # ItemType model has after_save method to automatically update the status of, or destroy plans
    item_type_ids_to_add = item_types.map(&:id) - product.plans.map(&:item_type).select{|it| it.active}.map{|it| it.id}
    item_type_ids_to_remove = product.plans.map(&:item_type).select{|it| it.active}.map{|it| it.id} - item_types.map(&:id)
    item_type_ids_to_add.each do |item_type_id|
      #Activate the item_type IDs to be added
      item_type = ItemType.find(item_type_id)
      item_type.active = true
      item_type.save!
      #Either activate existing plan (if it exists) or create new plan
      item_type.create_or_activate_plan(product)
    end
    item_type_ids_to_remove.each do |item_type_id|
      item_type = ItemType.find(item_type_id)
      item_type.active = false
      item_type.save!
    end
  end


  def inactivate_item_type
    item_type = self.item_type
    if item_type.active
      item_type.active = false
      item_type.save!
    end
  end

  def adjust_item_type
    if self.previous_changes[:active]
      unless self.previous_changes[:active][1] == true
        inactivate_item_type
      end
    end
  end
end
