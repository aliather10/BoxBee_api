class BalanceTransaction < StripeSync
  def self.all
    get_and_parse_cached_list('balance_transaction')
  end

  def self.by_company(company_id)
    filter_by_company('balance_transaction', company_id)
  end

  def self.by_customer(customer_id)
    filter_by_customer('balance_transaction', customer_id)
  end

  def self.by_date(balance_transactions, start_date, end_date)
    #Dates given as UNIX timestamps
    balance_transactions.select do |bt|
      bt['created'] >= start_date && bt['created'] <= end_date
    end
  end

  def self.sync(company_id)
    balance_transactions = get_list(company_id, "balance_transaction") do |stripe_args, stripe_account|
      get_balance_transactions(stripe_args, stripe_account)
    end
    synchronize(balance_transactions, "balance_transaction", company_id)
  end

  def self.retrieve(id, company_id)
    company = Company.find(company_id)
    begin
      Stripe::BalanceTransaction.retrieve(id, {stripe_account: company.stripe_account_id})
    rescue
      return nil
    end
  end

  def self.save_or_replace(stripe_object_id, stripe_account_id)
    retrieve_and_sync(Stripe::BalanceTransaction, stripe_object_id, stripe_account_id,
      "balance_transaction")
  end
end
