class ContactDetail < ActiveRecord::Base
  belongs_to :user

  validates :user, presence: true
  validates :mode_key, presence: true
  validates :mode_value, presence: true, length: {maximum: 255}
  validates :active, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :user, scope: [:mode_key, :mode_value]

  default_scope {order(:updated_at => :desc)}
  scope :by_company, ->(company_id) {
    joins(:user)
    .where('users.company_id = ?', company_id)
  }
  scope :by_user, ->(user_id) {where(user_id: user_id)}
  
  enum mode_key: [:phone, :email]
end
