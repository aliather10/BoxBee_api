class Payload < ActiveRecord::Base
  after_save :check_all_payloads
  after_commit :update_customer_item

  belongs_to :appointment_detail

  validates :appointment_detail_id, presence: true
	validates :name, presence: true, length: {maximum: 50}
	validates :sku, length: {maximum: 50}
	validates :status, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  enum status: [:scheduled, :ignored, :missing_item]

  scope :by_company, ->(company_id) {
    joins(appointment_detail: {appointment: {customer: :product}})
    .where('products.company_id = ?', company_id
  )}
  scope :by_route, ->(route_id) {
    joins(appointment_detail: {appointment: :route})
    .where('routes.id = ?', route_id
  )}
  scope :by_transit_type, ->(transit_type) {
    joins(:appointment_detail)
    .where('appointment_details.transit_types = ?', transit_type)
  }

  def detailed_object
    appointment_detail = self.appointment_detail
    self.as_json.merge({
      appointment: appointment_detail.appointment,
      appointment_detail: appointment_detail
    })
  end

  def misc_info
    self.as_json.merge({
      appointment_id: self.appointment_detail.appointment.id,
      staging_location: self.appointment_detail.appointment.customer.user.company
        .warehouses.first.locations.where(location_type: Location.location_types[:staging])
        .first.name,
      transit_type: self.appointment_detail.transit_type
    })
  end

  def check_all_payloads
    appointment = self.appointment_detail.appointment
    route = appointment.route
    #Check to see if all payloads have a staging location assigned. If so, move route status to ready
    if route
      staged_appointments = route.appointments.select do |aptmt|
        payloads = []
        aptmt.appointment_details.each do |ad|
          payloads += ad.payloads
        end
        payloads.select {|payload| payload.staging_location_id}.size == payloads.size
      end
      if route.appointments.size == staged_appointments.size
        route.status = :ready; route.save!
      else
        return true
      end
    end
  end

  def update_customer_item
    if self.previous_changes[:sku]
      customer_item = self.appointment_detail.customer_item
      customer_item.barcode = self.sku
      customer_item.save!
    end
  end
end
