class Refund < StripeSync
  def self.all
    get_and_parse_cached_list('refund')
  end

  def self.by_company(company_id)
    filter_by_company('refund', company_id)
  end

  def self.by_customer(customer_id)
    filter_by_customer('refund', customer_id)
  end

  def by_refund(stripe_refund_id)
    filter_by_refund('refund', stripe_refund_id)
  end

  def self.sync(company_id)
    refunds = get_list(company_id, "refund") do |stripe_args, stripe_account|
      get_refunds(stripe_args, stripe_account)
    end
    synchronize(refunds, "refund", company_id)
  end

  def self.save_or_replace(stripe_object_id, stripe_account_id)
    retrieve_and_sync(Stripe::Refund, stripe_object_id, stripe_account_id,
      "refund")
  end

  def self.refunder(invoice_items, company_id, reason)
    Company.find(company_id).apply_stripe_api_key
    refunds = []
    invoices = Invoice.by_company(company_id)
    invoice = invoices.select{|inv| inv['id'] == invoice_items.first['invoice']}.first
    if invoice
      charges = Charge.by_company(company_id)
      charge = charges.select{|ch| ch['id'] == invoice['charge']}.first
    end

    invoice_items.each do |ii|
      #Only refund line items that have not been previously refunded
      if invoice && invoice['closed'] && !invoice_item_previously_refunded?(ii['id'], company_id)
        accounting_code = ii['metadata']['accounting_code']
        #Find the discount contribution to each invoice itemå
        partial_refund_amount = ii['amount'].to_i - calculate_discount(ii, invoice).to_i + ii['metadata']['tax'].to_i
        refunds << Stripe::Refund.create({
          charge: charge['id'],
          amount: partial_refund_amount,
          reason: reason,
          metadata: {
            accounting_code: accounting_code,
            product_id: invoice['metadata']['product_id'],
            invoice_item_id: ii['id'],
            customer_id: Customer.find_by_stripe_customer_id(invoice['customer']).id
          }
        },
        {
          stripe_account: get_stripe_account_id(company_id)
        })
      elsif invoice && !invoice['closed'] && !invoice_item_previously_refunded?(ii['id'], company_id)
        #if invoice is still open, delete the invoice_item rather than refunding it, b/c it's not yet paid
        refunds << InvoiceItem.delete(ii['id'], company_id)
      end
    end
    return refunds
  end

  def self.refund_info(invoice_items, invoice, company_id)
    charge = Charge.by_invoice(invoice['id']).first
    customer = Customer.find_by_stripe_customer_id(invoice['customer'])
    refunds = []
    unless charge.nil? || charge.dig("metadata", "invoice_item")
      refunds = filter_by_customer("refund", customer.id)
      refunds = charge['refunds']['data'].map do |ref|
        matching_refund = refunds.index(ref['id'])
        matching_refund ? refunds[matching_refund] : {}
      end
    end
    refunds_array = []
    invoice_items.each do |ii|
      refundable = refunds ? refunds.select {|r| r.dig('metadata', 'invoice_item') ? r['metadata']['invoice_item'] == ii['id'] : false}.empty? : false
      amount_refundable = refundable ? (ii['amount'].to_i - calculate_discount(ii, invoice).to_i) : 0
      tax_refundable = refundable ? ii['metadata']['tax'].to_i : 0
      refunds_array << {amount_refundable: amount_refundable, refundable: refundable, tax_refundable: tax_refundable}
    end
    return refunds_array #returns an array of refund information for the same length as that of invoice_items
  end

  private
  def self.invoice_item_previously_refunded?(invoice_item_id, company_id)
    !Refund.by_company(company_id).select{|refund|
      refund.dig('metadata', 'invoice_item_id') ? refund['metadata']['invoice_item_id'] == invoice_item_id : false
    }.empty?
  end
end
