class Company < ActiveRecord::Base
  after_create :prepare_note_options
  after_create :replicate_item_types_job
  before_create :create_demo_stripe_account
  mount_uploader :logo, LogoUploader
  has_secure_token

  has_many :users, dependent: :destroy
  has_many :products, dependent: :destroy 
  has_many :warehouses, dependent: :destroy
  has_many :address_note_options, dependent: :destroy
  has_many :employee_invitations, dependent: :destroy
  has_many :holidays, dependent: :destroy
  has_many :item_types, dependent: :destroy
  has_many :service_areas, dependent: :destroy
  has_many :barcodes, dependent: :destroy
  has_many :vehicles, dependent: :destroy
  has_many :routes, dependent: :destroy
  has_many :reports, dependent: :destroy
  has_one :company_detail, dependent: :destroy

  enum country: ['us', 'ca', 'de', 'ch', 'br'] #The country that the company is domiciled.

  validates :contact_name, presence: true, length: {maximum: 255}
  validates :contact_number, presence: true, length: {maximum: 50}
  validates :contact_email, length: {maximum: 50}
  # validates :logo, presence: true
  validates :name, presence: true, length: {maximum: 255}
  validates :country, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_user, ->(user_id) {joins(:users).where('users.id = ?', user_id)}

  def detailed_object
    self.as_json.merge({
      products: self.products.map{|product| product.as_json
        .merge({
                   appointment_cutoffs: product.appointment_cutoffs,
                   default_tax_rate: product.default_tax
               })
      },
      company_details: self.company_detail,
    })
  end

  def apply_stripe_api_key
    product = self.products.first
    if product && product.status == 'active'
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
    else
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
    end
  end

  def create_demo_stripe_account(specified_country = nil)
    Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
    stripe_account = Stripe::Account.create(
      managed: true,
      country: specified_country ||= self.country
    )
    self.stripe_account_id = stripe_account['id']
  end

  def create_live_stripe_account(specified_country = nil)
    Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
    stripe_account = Stripe::Account.create(
      managed: true,
      country: specified_country ||= self.country
    )
    self.stripe_account_id = stripe_account['id']
    self.save!
  end

  def prepare_note_options
    address_note_option = AddressNoteOption.new(
      note: "custom",
      active: true,
      created_by: 1,
      modified_by: 1
    )
    address_note_option.company = self
    address_note_option.save!
  end

  def replicate_item_types_job
    Resque.enqueue(SeedPrototypeItemTypesJob, self.id)
  end

  def replicate_item_types
    #Replicate all prototype item_types from Company 1 to make them available for
    #the newly generated company
    key = "replicate_item_types:company:#{self.id}"
    REDIS.hset(key, "status", "started")
    REDIS.expire(key, 600)
    Company.first.item_types.each do |prototype_item_type|
      item_type = prototype_item_type.dup
      item_type.active = false
      item_type.company = self
      item_type.remote_image_url = prototype_item_type.image_url
      item_type.save!
    end
    REDIS.hset(key, "status", "completed")
    REDIS.expire(key, 600)
  end
end
