class InvoiceItem < StripeSync
  def self.all
    get_and_parse_cached_list('invoice_item')
  end

  def self.by_company(company_id)
    filter_by_company('invoice_item', company_id)
  end

  def self.by_product(product_id)
    filter_by_product('invoice_item', product_id)
  end

  def self.by_customer(customer_id)
    filter_by_customer('invoice_item', customer_id)
  end

  def self.by_invoice(stripe_invoice_id)
    filter_by_invoice('invoice_item', stripe_invoice_id)
  end

  def self.by_appointment(appointment_id)
    filter_by_appointment('invoice_item', appointment_id)
  end

  def self.by_accounting_code(accounting_code)
    filter_by_accounting_code(field_name, accounting_code)
  end

  def self.sync(company_id)
    invoice_items = get_list(company_id, "invoice_item") do |stripe_args, stripe_account|
      get_invoice_items(stripe_args, stripe_account)
    end
    synchronize(invoice_items, "invoice_item", company_id)
  end

  def self.save_or_replace(stripe_object_id, stripe_account_id)
    retrieve_and_sync(Stripe::InvoiceItem, stripe_object_id, stripe_account_id,
      "invoice_item")
  end

  def self.create(customer_id, amount, description, currency, metadata, company_id)
    Company.find(company_id).apply_stripe_api_key
    invoice_item = Stripe::InvoiceItem.create(
      {
        amount: amount,
        description: description,
        customer: Customer.find(customer_id).stripe_customer,
        currency: currency,
        metadata: metadata
      },
      {
        stripe_account: get_stripe_account_id(company_id)
      }
    )
  end

  def self.delete(invoice_item_id, company_id)
    Company.find(company_id).apply_stripe_api_key
    invoice_item = Stripe::InvoiceItem.retrieve(invoice_item_id, {stripe_account: get_stripe_account_id(company_id)})
    invoice_item.delete
  end
end
