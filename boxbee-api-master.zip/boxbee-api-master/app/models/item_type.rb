class ItemType < ActiveRecord::Base
  after_commit :check_plan
  after_commit :replicate_name_and_image_to_plan

  belongs_to :company
  has_many :plans
  has_many :customer_items
  has_many :subscriptions, through: :customer_items

  validates :name, presence: true, length: {minimum: 0, maximum: 50}
  validates :company_id, presence: true
  # validates :requires_empty_delivery, presence: true
  # validates :requires_empty_pickup, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :company_id, scope: :name

  mount_uploader :image, AssetUploader

  scope :by_company, ->(company_id) {where(company_id: company_id)}
  scope :by_plan, ->(plan_id) {joins(:plans).where('plans.id = ?', plan_id)}

  def detailed_object
    self
  end

  def check_plan
    if self.previous_changes[:active]
      if self.previous_changes[:active][1] == true
        return true
      else
        #If item_type was just made inactive, iterate through plans and either deactivate plan (if it has subscriptions attached)
        #or destroy plan
        self.plans.each do |plan|
          plan = Plan.find_by_item_type_id(self.id)
          if plan.subscriptions.empty?
            plan.destroy!
          else
            plan.active = false
            plan.save!
          end
        end
      end
    end
  end

  def create_or_activate_plan(product)
    existing_plan = Plan.by_company(self.company_id).find_by_item_type_id(self.id)
    if existing_plan
      existing_plan.active = true
      existing_plan.save!
    else
      plan = Plan.new(
        product: product,
        item_type_id: self.id,
        name: "#{self.name} Plan",
        created_by: 1,
        modified_by: 1
      )
      key = self.image.file.path
      file_path = Asset.download_image_from_s3(key)
      plan.image = File.open(file_path)
      plan.save!
    end
  end

  def replicate_name_and_image_to_plan
    #If an item_type's image or name have changed, replicate these to all corresponding plans
    self.plans.each do |plan|
      if self.previous_changes[:image]
        key = self.image.file.path
        file_path = Asset.download_image_from_s3(key)
        plan.image = File.open(file_path)
        plan.save!
      end
      if self.previous_changes[:name]
        plan.name = self.name
        plan.save!
      end
    end
  end
end
