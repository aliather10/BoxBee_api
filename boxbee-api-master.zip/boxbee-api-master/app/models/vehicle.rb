class Vehicle < ActiveRecord::Base
  belongs_to :company

  validates :company, presence: true
  validates :name, presence: true, length: {maximum: 100}
  validates :make, length: {maximum: 50}
  validates :model, length: {maximum: 50}
  validates :vin_num, length: {maximum: 50}
  validates :license_plate_num, length: {maximum: 20}
  validates :created_by, presence: true
	validates :modified_by, presence: true
  validates_uniqueness_of :name, scope: :company_id

  scope :by_company, ->(company_id) {where(company_id: company_id)}
end
