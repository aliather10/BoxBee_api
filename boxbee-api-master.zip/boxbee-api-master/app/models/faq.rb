class Faq < ActiveRecord::Base
  belongs_to :product

  validates :product, presence: true
  validates :question, presence: true
  validates :answer, presence: true

  scope :by_company, ->(company_id) {joins(:product)
    .where('products.company_id = ?', company_id)}
end
