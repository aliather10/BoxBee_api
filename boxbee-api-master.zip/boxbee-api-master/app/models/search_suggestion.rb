class SearchSuggestion
  def self.terms_for(prefix, company_id)
    {
      customers: parse(fetch_matches(prefix, 'customer', company_id)),
      appointments: parse(fetch_matches(prefix, 'appointment', company_id)),
      invoices: parse(fetch_matches(prefix, 'invoice', company_id))
    }
  end

  def self.index_main
    Company.all.each do |company|
      Customer.by_company(company.id).each do |customer|
        index_customer_name(customer, company.id)
      end

      Invoice.by_company(company.id).each do |invoice|
        index_invoice(invoice, company.id)
      end

      Location.by_company(company.id).each do |location|
        index_location_name(location, company.id)
      end

      Appointment.by_company(company.id).each do |appointment|
        index_appointment(appointment, company.id)
      end

      CustomerItem.by_company(company.id).each do |customer_item|
        index_barcode(customer_item, company.id)
      end
    end
  end

  def self.index_term(term, model_name, object, company_id)
    REDIS.set("search:company:#{company_id}:#{model_name}:#{term.to_s.downcase}", object.to_s)
  end

  def self.delete_indices(model_name, object_id, company_id)
    case model_name
      when 'barcode'
        object_id_key = 'customer_item_id'
      when 'appointment'
        object_id_key = 'appointment_id'
      when 'customer'
        object_id_key = 'customer_id'
      when 'location'
        object_id_key = 'location_id'
    end
    keys = REDIS.keys("search:company:#{company_id}:#{model_name}:*")

    keys.each do |key|
      value = REDIS.zrevrange key, 0, -1
      if SearchSuggestion.parse(value).first[object_id_key] == object_id
        REDIS.del(key)
      end
    end
  end

  def self.parse(results)
    if results.empty?
      []
    else
      results.map{|result| JSON.parse(result.gsub('=>', ':').gsub("nil", "null"))}
    end
  end

  def self.index_customer_name(customer, company_id)
      #Index customer first name and last name
      user = customer.user
      index_term(
          "#{user.first_name} #{user.last_name}",
          'customer',
          {customer_id: customer.id, name: "#{user.first_name} #{user.last_name}"}.as_json,
          company_id
      )
  end

  def self.update_customer_name(customer)
    delete_indices('customer', customer.id, customer.user.company_id)
    index_customer_name(customer, customer.user.company_id)
  end

  def self.update_location(location)
    delete_indices('location', location.id, location.warehouse.company_id)
    index_location_name(location, location.warehouse.company_id)
  end

  def self.update_customer_item(customer_item)
    delete_indices('customer_item', customer_item.id, customer_item.item_type.company_id)
    index_barcode(customer_item, customer_item.item_type.company_id)
  end

  def self.index_invoice(invoice, company_id)
    #Index invoice ID
    index_term(invoice['id'], 'invoice', {invoice_id: invoice['id']}.as_json, company_id)
  end

  def self.index_location_name(location, company_id)
    #Index location name
    index_term(location.name, 'location', {location_id: location.id, location_name: location.name}.as_json, company_id)
  end

  def self.index_appointment(appointment, company_id)
    #Index appointment ID
    index_term(appointment.id, 'appointment', {appointment_id: appointment.id}.as_json, company_id)
  end

  def self.index_barcode(customer_item, company_id)
  #Barcode
    if customer_item.barcode
      index_term(customer_item.barcode, 'barcode', {customer_item_id: customer_item.id, barcode: customer_item.barcode,
                                                    location: customer_item.summary[:last_location],
                                                    customer_name: customer_item.subscription.customer.user.full_name}.as_json, company_id)
    end
  end

  def self.fetch_matches(prefix, model_name, company_id)
    prefix = prefix.to_s #In case of integers being submitted
    puts "model_keys #{model_keys(model_name, company_id)}"
    keys = model_keys(model_name, company_id).select do |key|
      key.split(':').last.include?(prefix)
    end
    keys.map!{|key| {name: key, rank: key.split(':').last.index(prefix)}}
    sorted_keys = keys.sort_by{|key| key[:rank]}.map{|key| key[:name]}
    puts "keys #{keys}"
    puts "sorted_keys #{sorted_keys}"
    !sorted_keys.empty? ? REDIS.mget(sorted_keys) : []
  end

  def self.model_keys(model_name, company_id)
    REDIS.keys("search:company:#{company_id}:#{model_name}:*")
  end
end
