class ServiceAreaZip < ActiveRecord::Base
  before_destroy :allowed_to_destroy?

  belongs_to :service_area

  validates :service_area, presence: true
  validates :zip, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :service_area, scope: :zip

  scope :by_zip, ->(zip_code) {where(zip: zip_code)}
  scope :by_company, ->(company_id) {
    joins(:service_area)
    .where('service_areas.company_id = ?', company_id
  )}

  def detailed_object
    self.as_json.merge({service_area: self.service_area})
  end

  def allowed_to_destroy?
    # Checks to see if appointments with the corresponding zip_code exist. If so, deactivate record.
    # If not, delete record
    appointments = Appointment.by_company(self.service_area.company_id).select do |aptmt|
      aptmt.address.zip_code == self.zip.to_s
    end
    appointments.empty?
  end
end
