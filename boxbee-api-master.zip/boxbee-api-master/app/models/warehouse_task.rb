class WarehouseTask < ActiveRecord::Base
  after_save :check_new_status

  belongs_to :location

  scope :by_task_type, ->(task_type) {where(task_type: WarehouseTask.task_types[task_type])}
  scope :by_warehouse, ->(warehouse_id) {
    joins(location: :warehouse).where('warehouses.id = ?', warehouse_id)
  }
  scope :by_route, ->(route_id) {where(route_id: route_id)}
  scope :by_company, ->(company_id) {
    joins(location: :warehouse).where('warehouses.company_id = ?', company_id)
  }

  validates :location, presence: true
  validates :inventory_type, presence: true
  validates :inventory_name, presence: true
  validates :sku, presence: true
  validates :quantity, presence: true
  validates :task_type, presence: true
  validates :status, presence: true

  enum task_type: [:put, :pick]
  enum inventory_type: [:container, :customer_item]
  enum status: [:created, :started, :completed, :canceled, :ignored, :missing_item]

  def detailed_object
    appointment = Payload.find_by_id(self.payload_id).try(:appointment_detail).try(:appointment)
    self.as_json.merge({
      inventories: self.inventories,
      appointment: appointment ||= 'not available'
    })
  end

  def inventories
    Inventory.where(
      inventory_type: Inventory.inventory_types[self.inventory_type],
      sku: self.sku,
      location: self.location
    )
    .map{|inv| {inventory_id: inv.id, location: inv.location}}
  end

  def check_new_status
    # If warehouse_task gets marked as status: :ignored, or :missing_item, cascade the statuses to the corresp. payload
    if self.status == ('ignored' || 'missing_item')
      payload = Payload.find_by_id(self.payload_id)
      if payload
        payload.status = self.status
        payload.save!
      end
    end
  end
end
