class Card < StripeSync
  def self.create(stripe_customer, stripe_token, metadata, company_id, product_id)
    stripe_customer.sources.create({
      source: stripe_token,
      metadata: {product_id: product_id}
    })
  end

  def self.update(stripe_card_id, customer_id, card_params, company_id)
    card = retrieve(stripe_card_id, customer_id, company_id)
    card.exp_month = card_params[:exp_month] if card_params[:exp_month]
    card.exp_year = card_params[:exp_year] if card_params[:exp_year]
    card.address_line1 = card_params[:address_line1] if card_params[:address_line1]
    card.address_line2 = card_params[:address_line2] if card_params[:address_line2]
    card.address_city = card_params[:address_city] if card_params[:address_city]
    card.address_state = card_params[:address_state] if card_params[:address_state]
    card.address_zip = card_params[:address_zip] if card_params[:address_zip]
    card.address_country = card_params[:address_country] if card_params[:address_country]
    card.save
    return card
  end

  def self.delete(stripe_card_id, company_id)
    card = retrieve(stripe_card_id, customer_id, company_id)
    card.delete()
  end

  def self.retrieve(id, customer_id, company_id)
    Customer.find(customer_id)
      .stripe_customer.sources.retrieve(id)
  end

  def self.retrieve_from_cache(id, company_id)
    customers = filter_by_company('customer', company_id)
    customers.each do |cus|
      if cus.dig('sources', 'data')
        cus['sources']['data'].each do |card|
          return card if card['id'] == id
        end
      end
    end
  end
end
