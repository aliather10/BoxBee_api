class Invoice < StripeSync
  def self.all
    get_and_parse_cached_list('invoice')
  end

  def self.by_company(company_id)
    filter_by_company('invoice', company_id)
  end

  def self.by_customer(customer_id)
    filter_by_customer('invoice', customer_id)
  end

  def self.by_product(product_id)
    filter_by_product('invoice', product_id)
  end

  def by_invoice(stripe_invoice_id)
    filter_by_invoice('invoice', stripe_invoice_id)
  end

  def by_appointment(appointment_id)
    filter_by_appointment('invoice', appointment_id)
  end

  def self.sync(company_id)
    invoices = get_list(company_id, "invoice") do |stripe_args, stripe_account|
      get_invoices(stripe_args, stripe_account)
    end
    synchronize(invoices, "invoice", company_id)
  end

  def self.save_or_replace(stripe_object_id, stripe_account_id)
    retrieve_and_sync(Stripe::Invoice, stripe_object_id, stripe_account_id,
      "invoice")
  end

  def self.create(customer_id, metadata, tax_percent, company_id, application_fee)
    Company.find(company_id).apply_stripe_api_key
    Stripe::Invoice.create(
      {
        customer: Customer.find(customer_id).stripe_customer_id,
        metadata: metadata,
        tax_percent: tax_percent,
        application_fee: application_fee
      },
      {stripe_account: get_stripe_account_id(company_id)}
    )
  end

  def self.retrieve(id, company_id)
    Company.find(company_id).apply_stripe_api_key
    Stripe::Invoice.retrieve(id, {stripe_account: get_stripe_account_id(company_id)})
  end
end
