class Charge < StripeSync
  def self.all
    get_and_parse_cached_list('charge')
  end

  def self.by_company(company_id)
    filter_by_company('charge', company_id)
  end

  def self.by_customer(customer_id)
    filter_by_customer('charge', customer_id)
  end

  def self.by_invoice(stripe_invoice_id)
    filter_by_invoice('charge', stripe_invoice_id)
  end

  def self.sync(company_id)
    charges = get_list(company_id, "charge") do |stripe_args, stripe_account|
      get_charges(stripe_args, stripe_account)
    end
    synchronize(charges, "charge", company_id)
  end

  def self.by_appointment(appointment_id)
    filter_by_appointment('charge', appointment_id)
  end

  def self.save_or_replace(stripe_object_id, stripe_account_id)
    retrieve_and_sync(Stripe::Charge, stripe_object_id, stripe_account_id, "charge")
  end
end
