class Warehouse < ActiveRecord::Base
  belongs_to :company
  has_many :locations
  has_one :address, as: :addressable, dependent: :destroy

  validates :name, presence: true
  validates :address_id, presence: true, length: {maximum: 100}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :name, scope: :company

  scope :by_company, ->(company_id) {
    where(company_id: company_id)
  }

  def detailed_object
    self.as_json.merge({address: self.address})
  end
end
