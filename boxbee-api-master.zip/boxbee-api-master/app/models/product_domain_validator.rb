class ProductDomainValidator < ActiveModel::Validator
  def validate(record)
    unless unique_customer_portal(record) && check_other_companies_domains(record)
      record.errors[:base] << 'You must specify a unique domain for this products URLS. It is allowed to match that of the parent company, but not other products'
    end
  end

  private
  def unique_customer_portal(record)
    #1 Must be a domain that no other product has.
    if record.customer_portal_url
      customer_host = URI.parse(record.customer_portal_url).host.split('.')[1,2].join('.')
      products = Product.all.select do |product|
        if product.customer_portal_url
          match = (URI.parse(product.customer_portal_url).host.split('.')[1,2].join('.') == customer_host) &&
            (record.id ? (product.id == record.id ? false : true) : true)
          match
        end
      end
      products.size > 0 ? false : true
    else
      true
    end
  end

  def check_other_companies_domains(record)
    #2 Must be a domain that no other company has in UMS (same company is OK)
    urls_to_check = []
    urls_to_check << URI.parse(record.customer_portal_url).host if record.customer_portal_url
    unless urls_to_check.empty?
      companies = []
      urls_to_check.each do |host|
        company =  Company.all.select {|company| url_to_host(company.custom_admin_url) == host}.first
        companies << company if company
      end
      if companies.nil? || companies.empty?
        return true
      elsif companies.size == companies.select{|company| company['id'] == record.company_id}.size
        return true
      else
        return false
      end
    else
      return true
    end
  end

  def url_to_host(url)
    URI.parse(url).host if url
  end
end
