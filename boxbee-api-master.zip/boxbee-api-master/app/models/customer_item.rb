class CustomerItem < ActiveRecord::Base
  include ActiveModel::Validations

  after_create :replicate_info
  before_save :check_extinct
  after_save :create_history
  after_save :update_search_index
  before_destroy :delete_search_index

  belongs_to :item_type
  belongs_to :subscription
  has_many :appointment_details
  has_many :appointments, through: :appointment_details
  has_many :assets
  has_many :customer_item_histories, dependent: :destroy

  enum status: [:scheduled, :with_user, :in_transit, :in_storage, :extinct]

  validates :status, presence: true
  # validates :subscription, presence: true
  validates :item_type, presence: true
  validates :barcode, length: {maximum: 50}
  validates :name, length: {maximum: 50}
  validates :description, length: {maximum: 255}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_with CustomerItemValidator

  scope :by_customer, ->(customer_id) {joins(:subscription)
    .where('subscriptions.customer_id = ?', customer_id)}
  scope :by_user, ->(user_id) {joins(subscription: :customer)
    .where('customers.user_id = ?', user_id)}
  scope :by_status, ->(status) {where(status: CustomerItem.statuses[status])}
  scope :by_transit_type, ->(transit_type) {joins(:appointment_details)
    .where('appointment_details.transit_type = ?', AppointmentDetail.transit_types[transit_type])}
  scope :by_product, ->(product_id) {joins(appointments: :customer)
    .where('customers.product_id = ?', product_id)}
  scope :by_company, ->(company_id) {joins(:item_type).where('item_types.company_id = ?',
    company_id)}
  scope :by_customer, ->(customer_id) {
    joins(subscription: :customer)
    .where('customers.id = ?', customer_id)
  }

  def detailed_object
    self.as_json.merge({
      item_type: self.item_type,
      subscription: self.subscription,
      latest_appointment_detail: self.appointment_details.by_latest_appointment,
      assets: self.assets,
      filled_status: self.filled_status
    })
  end

  #Delete subscription after marking customer_item extinct
  def check_extinct
    if self.changes[:status]
      if self.changes[:status][1] == self.class.statuses[:extinct]
        subscription = self.subscription
        currently_with_user = self.changes[:status][0] == self.class.statuses[:with_user]
        past_min_term = DateTime.now >= (self.created_at + subscription.plan.minimum_term)
        unless currently_with_user && past_min_term
          raise ActiveRecord::RecordInvalid "Customer Item cannot be extincted unless it is " \
          "subscribed past the minimum term requirement and has status with_user"
        end
        # If subscription still has customer_items, keep active. Else, delete subscription
        subscription.destroy! if subscription.customer_items.empty?
      end
    end
  end

  def create_history
    history = CustomerItemHistory.by_customer_item(self.id).first
    if history && self.status != history.current_status
      CustomerItemHistory.create(customer_item_id: self.id,
        current_status: self.status, previous_status: history.current_status,
        current_filled_status: self.filled_status,
        previous_filled_status: history.current_filled_status, created_by: created_by,
        modified_by: created_by)
    end
  end

  def self.from_original_appointment(appointment_id, customer_items)
    customer_items.select do |ci|
      ci.customer_item_histories.first.appointment_id == appointment_id
    end
  end

  def filled_status
    if match_status(:in_storage)
      if last_appointment_detail(:packed, :pickup, :completed)
        return :packed
      elsif last_appointment_detail(:empty, :pickup, :completed) && self.item_type.requires_empty_pickup
        return :empty
      end
    elsif match_status(:scheduled)
      if last_appointment_detail(:empty, :delivery, :scheduled) && self.item_type.requires_empty_delivery
        return :empty
      elsif last_appointment_detail(:packed, :pickup, :scheduled) && !self.item_type.requires_empty_delivery
        return :packed
      elsif last_appointment_detail(:empty, :pickup, :scheduled) && self.item_type.requires_empty_pickup
        return :empty
      end
    elsif match_status(:with_user)
      if last_appointment_detail(:packed, :delivery, :completed)
        return :packed
      elsif last_appointment_detail(:empty, :delivery, :completed) && self.item_type.requires_empty_delivery
        return :empty
      end
    else
      return :unknown
    end
  end

  def replicate_info
    item_type = self.item_type
    self.name = item_type.name
    self.description = self.description
    self.save!
  end

  def summary
    last_location = nil
    case self.status
      when 'in_storage'
        last_location = "Warehouse loc: #{Inventory.where(sku: self.barcode, inventory_type: Inventory.inventory_types[:customer_item]).first.location.name}"
      when 'with_customer'
        last_location = Address.find(self.last_appointment_address_id).address1
      when 'in_transit'
        last_location = 'n/a'
      else
        last_location = 'n/a'
    end
    {
        name: self.name,
        barcode: self.barcode,
        last_location: last_location,
        status: self.status
    }
  end

  def update_search_index
    Resque.enqueue(SearchSuggestionIndexJob, 'barcode', self.id, self.item_type.company_id)
  end

  def delete_search_index
    Resque.enqueue(DeleteSearchSuggestionIndexJob, 'barcode', self.id, self.item_type.company_id)
  end

  private
  def match_status(status)
    self.status.to_i == self.class.statuses[status]
  end

  def last_appointment_detail(request_type, transit_type, appointment_status)
    appointment_detail = AppointmentDetail.by_customer(self.subscription.customer_id)
      .where(customer_item_id: self.id).by_latest_appointment.first
    appointment_detail.transit_type.to_i == AppointmentDetail.transit_types[transit_type] &&
    appointment_detail.request_type.to_i == AppointmentDetail.request_types[request_type] &&
    appointment_detail.appointment.status.to_i == Appointment.statuses[appointment_status]
  end
end
