class Onboarding
  CHECKLIST_NAMES = ['product_setup', 'vehicle_setup', 'warehouse_setup', 'barcoding_setup',
      'pricing_setup', 'company_setup', 'banking_setup']

  def self.new(item_type_ids, product)
    item_type_ids.each do |item_type_id|
      # Activate the item_types specified and create the corresponding plans
      item_type = ItemType.find(item_type_id)
      item_type.active = true
      # Create associated plans
      plan = Plan.new(
        product: product,
        item_type_id: item_type.id,
        name: "#{item_type.name} Plan",
        created_by: 1,
        modified_by: 1
      )
      plan.remote_image_url = item_type.image_url
      plan.save!
    end

    hash = {completed: false}
    Onboarding::CHECKLIST_NAMES.each do |checklist_name|
      hash = hash.merge({plans: product.plans.as_json}) if checklist_name == 'pricing_setup'
      Onboarding.save_checklist(checklist_name, product.company_id, hash)
    end
  end

  def self.save_progress(company_id, checklist_name, checklist_items)
    # Mark as completed if all checklist items present and saved
    company = Company.find(company_id)
    product = company.products.first
    service_area = ServiceArea.by_product(product.id).first
    case checklist_name
    when 'product_setup'
      product.default_days_of_week = checklist_items['days_of_week'] if checklist_items['days_of_week']
      product.default_daily_start = checklist_items['opening_time'] if checklist_items['opening_time']
      product.default_daily_end = checklist_items['closing_time'] if checklist_items['closing_time']
      product.default_tax = checklist_items['default_tax_rate'] if checklist_items['default_tax_rate']
      product.default_minimum_term = checklist_items['default_minimum_term'] if checklist_items['default_minimum_term']
      product.default_max_appointments_per_slot = 2
      product.default_slot_duration = 60
      product.save!
      service_area_schedules = ServiceAreaSchedule.where(service_area: service_area)
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        product: product.as_json,
        service_area_schedules: service_area_schedules.as_json
      })
    when 'vehicle_setup'
      vehicle = company.vehicles.first
      vehicle = vehicle ||= FactoryGirl.create(
        :vehicle,
        company: company,
        name: checklist_items[:name],
        year: checklist_items[:year],
        make: checklist_items[:make],
        model: checklist_items[:model],
        vin_num: nil,
        license_plate_num: nil
      )
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        vehicle: vehicle.as_json
      })
    when 'warehouse_setup'
      warehouse = company.warehouses.first
      if warehouse
        address = warehouse.address
      else
        address = Address.create!(
          address1: checklist_items[:address1],
          address2: checklist_items[:address2],
          address3: checklist_items[:address3],
          city: checklist_items[:city],
          state_name: checklist_items[:state_name],
          zip_code: checklist_items[:zip_code],
          country_name: checklist_items[:country_name],
          created_by: 1,
          modified_by: 1
        )
        warehouse = FactoryGirl.create(
          :warehouse,
          company: company,
          name: "Warehouse #{checklist_items['address1']}",
          address_id: address.id
        )
        address.addressable_type = 'Warehouse'
        address.addressable_id = warehouse.id
        address.save!
      end
      # Create storage location
      storage_location = first_location_by_type(warehouse, :permanent)
      unless storage_location
        storage_location = FactoryGirl.create(
          :location,
          warehouse: warehouse,
          name: checklist_items['storage_location_name'],
          location_type: :permanent
        )
      end
      storage_location.name = checklist_items['storage_location_name'] if checklist_items['storage_location_name']
      storage_location.save!
      # Create staging location
      staging_location = first_location_by_type(warehouse, :staging)
      unless staging_location
        staging_location = storage_location.dup
        staging_location.location_type = :staging
      end
      staging_location.name = checklist_items['staging_location_name'] if checklist_items['staging_location_name']
      staging_location.save!
      # Create cart location if requested
      if checklist_items['cart_name']
        cart_location = first_location_by_type(warehouse, :cart)
        unless cart_location
          cart_location = storage_location.dup
          cart_location.location_type = :cart
        end
        cart_location.name = checklist_items['cart_name']
        cart_location.save!
      end
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        warehouse: warehouse.as_json.merge({
          address: address.as_json,
          locations: warehouse.locations.as_json
        })
      })
    when 'barcoding_setup'
      #Confirm acknowledgement of having read that barcodes are important
      #Proceed to Redis setter below unless :confirmation is false/nil
      if checklist_items['confirmation']
        response = save_checklist(checklist_name, company_id, {completed: true})
      end
    when 'pricing_setup'
      #Set product's transit pricing and currency
      product.packed_pickup_price = checklist_items['pickup_fee'] if checklist_items['pickup_fee']
      product.packed_delivery_price = checklist_items['delivery_fee'] if checklist_items['delivery_fee']
      product.currency = checklist_items['currency']
      product.save!
      #Set pricing for each plan
      checklist_items['plans'].each do |plan_obj|
        plan = Plan.by_product(product.id).find(plan_obj['plan_id'])
        plan.price_per_plan = plan_obj['price'] if plan_obj['price']
        plan.save!
      end
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        plans: product.plans.as_json
      })
      response = save_checklist('product_setup', company_id, {
        completed: completed?('product_setup', company_id),
        product: product.as_json,
        service_area_schedules: company.service_areas.first.service_area_schedules.as_json
      })
    when 'company_setup'
      company_detail = company.company_detail
      company_detail.entity_type = checklist_items['entity_type'] if checklist_items['entity_type']
      company_detail.address1 = checklist_items['address1'] if checklist_items['address1']
      company_detail.address2 = checklist_items['address2'] if checklist_items['address2']
      company_detail.address3 = checklist_items['address3'] if checklist_items['address3']
      company_detail.city = checklist_items['city'] if checklist_items['city']
      company_detail.state_name = checklist_items['state_name'] if checklist_items['state_name']
      company_detail.country_name = checklist_items['country_name'] if checklist_items['country_name']
      company_detail.zip_code = checklist_items['zip_code'] if checklist_items['zip_code']
      if checklist_items['entity_name']
        company_detail.entity_name = checklist_items['entity_name']
        company.name = company_detail.entity_name
      end
      company_detail.save!
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        company: company.as_json.merge({
          company_detail: company_detail.as_json
        })
      })
      save_checklist('banking_setup', company_id, {
        completed: completed?('banking_setup', company_id),
        company: company.as_json.merge({
          company_detail: company_detail.as_json
        })
      })
    when 'banking_setup'
      # if filled out completely AND checkbox false, OK
      # if checkbox true, OK
      keys = ['account_holder_name', 'account_holder_email', 'ssn', 'dob', 'government_id',
        'ein', 'bank_routing_no', 'bank_account_no']
      completed_checklist = keys.select{|key| checklist_items.dig(key)}.size == keys.size
      unless checklist_items['confirmation'] || completed_checklist
        raise "Cannot proceed unless acknwoledgement of payment summary is confirmed OR all information is filled in"
      end
      company.contact_name = checklist_items['account_holder_name'] if checklist_items['account_holder_name']
      company.contact_email = checklist_items['account_holder_email'] if checklist_items['account_holder_email']
      company.save!
      company_detail = company.company_detail.update_attributes!(checklist_items.slice('ssn', 'dob', 'government_id', 'ein',
        'bank_routing_no', 'bank_account_no'))
      company_detail = CompanyDetail.find_by_company_id(company.id)
      #Save to REDIS
      response = save_checklist(checklist_name, company_id, {
        completed: true,
        company: company.as_json.merge({
          company_detail: company_detail.as_json
        })
      })
      save_checklist('company_setup', company_id, {
        completed: completed?('company_setup', company_id),
        company: company.as_json.merge({
          company_detail: company_detail.as_json
        })
      })
    else
      raise "Invalid checklist_name"
    end
    #If REDIS successfully saved info, return true, otherwise raise error
    if response == "OK"
      return true
    else
      raise "Could not save checklist"
    end
  end

  def self.checklist_progress(company_id)
    checklists = []
    keys = REDIS.keys("onboarding_setup:*:company:#{company_id}")

    keys.each do |key|
      checklists << {checklist_name: key.split(':')[1]}.merge(
        JSON.parse(REDIS.get(key).gsub('=>', ':').gsub("nil", "null"))
      )
    end
    return checklists
  end

  def self.send_mobile_sms(phone_number)
    twilio_client = Twilio::REST::Client.new Figaro.env.TWILIO_ACCOUNT_SID,
      Figaro.env.TWILIO_AUTH_TOKEN

    message = twilio_client.account.messages.create(
      :body => "Welcome to Boxbee! Download the Boxbee Operations Companion App here: #{Figaro.env.GOOGLE_PLAY_DOWNLOAD_URL}",
      :to => phone_number,
      :from => Figaro.env.TWILIO_DEFAULT_PHONE
    )
    message.sid
  end

  def self.create_subdomain(subdomain)
    #In Heroku
    heroku_domain_response = HTTParty.post("#{Figaro.env.HEROKU_API_BASE_PATH}/#{Figaro.env.LOAD_BALANCER_APP_NAME}/domains",
      :headers => {
        "Accept" => "application/vnd.heroku+json; version=3",
        "Authorization" => "Bearer #{Figaro.env.HEROKU_AUTH_TOKEN}"
      },
      :body => {
        "hostname" => "#{subdomain}.#{Figaro.env.APP_DOMAIN}"
      }
    ).as_json
    raise "could not post subdomain to Heroku" unless heroku_domain_response['hostname']
    #Get SSL endpoint from Heroku
    heroku_ssl_endpoint = heroku_domain_response['cname']
    #In DNSimple
    dnsimple_response = HTTParty.post("#{Figaro.env.DNSIMPLE_API_BASE_PATH}/#{Figaro.env.APP_DOMAIN}/records",
      :headers => {
        "Accept" => "application/json",
        "Content-Type" => "application/json",
        "X-DNSimple-Token" => Figaro.env.DNSIMPLE_TOKEN
      },
      :query => {
        "record" => {
          "name" => subdomain,
          "record_type" => "CNAME",
          "content" => heroku_ssl_endpoint
        }
      }
    ).as_json
    raise "Subdomain could not be registered with DNS provider" unless dnsimple_response.dig('record', 'id')
  end

  def self.delete_subdomain(subdomain)
    #In Heroku
    heroku_domain_response = HTTParty.delete("#{Figaro.env.HEROKU_API_BASE_PATH}/#{Figaro.env.LOAD_BALANCER_APP_NAME}/domains/#{subdomain}.#{Figaro.env.APP_DOMAIN}",
      :headers => {
        "Accept" => "application/vnd.heroku+json; version=3",
        "Authorization" => "Bearer #{Figaro.env.HEROKU_AUTH_TOKEN}"
      }
    ).as_json
    #In DNSimple
    records = HTTParty.get("#{Figaro.env.DNSIMPLE_API_BASE_PATH}/#{Figaro.env.APP_DOMAIN}/records",
      :headers => {
        "Accept" => "application/json",
        "Content-Type" => "application/json",
        "X-DNSimple-Token" => Figaro.env.DNSIMPLE_TOKEN
      }
    ).as_json
    #Find record ID corresponding to cname record to be deleted
    record_id = records.select{|record| record['record']['name'] == "#{subdomain}"}
      .first['record']['id']
    #Delete record
    HTTParty.delete("#{Figaro.env.DNSIMPLE_API_BASE_PATH}/#{Figaro.env.APP_DOMAIN}/records/#{record_id}",
      :headers => {
        "Accept" => "application/json",
        "Content-Type" => "application/json",
        "X-DNSimple-Token" => Figaro.env.DNSIMPLE_TOKEN
      }
    ).as_json
  end

  private
  def self.key(checklist_name, company_id)
    "onboarding_setup:#{checklist_name}:company:#{company_id}"
  end

  def self.first_location_by_type(warehouse, location_type)
    warehouse.locations
      .where(location_type: Location.location_types[location_type]).first
  end

  def self.save_checklist(checklist_name, company_id, hash)
    #Save to REDIS
    REDIS.set(key(checklist_name, company_id), hash.as_json.to_s)
  end

  def self.completed?(checklist_name, company_id)
    checklist_progress(company_id).select{|list| list[:checklist_name] == checklist_name}.first['completed']
  end
end
