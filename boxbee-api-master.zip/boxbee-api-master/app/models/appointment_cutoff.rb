class AppointmentCutoff < ActiveRecord::Base
  belongs_to :product

  validates :product, presence: true
  validates :cutoff_type, presence: true
  validates :lead_time, presence: true, numericality: {greater_than_or_equal_to: 0}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :product_id, scope: :cutoff_type

  enum cutoff_type: [:creation, :modification, :cancellation]

  scope :by_company, ->(company_id) {joins(:product).where('products.company_id = ?',
    company_id)}
  scope :by_product, ->(product_id) {joins(:product).where('products.id = ?',
    product_id)}

  def detailed_object
    self.as_json.merge({product: self.product})
  end

  def self.move_appointment_to_confirmed(appointment_id)
    appointment = Appointment.find(appointment_id)
    appointment.status = :confirmed
    appointment.save!
    puts "appointment *** #{appointment.inspect}"

    appointment_details = appointment.appointment_details
    puts "apptmt details: #{appointment_details.inspect}"
    appointment_details.each do |ad|
      customer_item = ad.customer_item
      sku = customer_item.barcode if ad.transit_type == 'delivery'
      payload = Payload.create!({
        appointment_detail_id: ad.id,
        name: ad.customer_item.item_type.name,
        status: :scheduled,
        sku: sku,
        warehouse_id: ad.appointment.customer.product.company.warehouses.first.id,
        created_by: 1,
        modified_by: 1
      })
      puts "created payload #{payload.inspect}"
    end

    route = appointment.assign_to_route
    puts "route that appointment has been assigned to: #{route.inspect}"

    appointment_details.each do |ad|
      if ad.transit_type == 'delivery'
        inventory = Inventory.by_company(route.company_id).where(sku: ad.customer_item.barcode).first
        puts "then the inventory: #{inventory.inspect}"
        location = inventory.location
        puts "then the location #{location.inspect}"
        puts "about to create warehouse_task..."
        payload = ad.payloads.where(sku: inventory.sku).last
        warehouse_task = WarehouseTask.create!(
          location: location,
          sku: ad.customer_item.barcode,
          quantity: 1,
          payload_id: payload.try(:id),
          task_type: :pick,
          route_id: route.id,
          inventory_type: :customer_item,
          inventory_name: inventory.inventory_name,
          status: :created,
          created_by: 1,
          modified_by: 1
        )
        puts "created warehouse task: #{warehouse_task.inspect}"
      end
    end
  end
end
