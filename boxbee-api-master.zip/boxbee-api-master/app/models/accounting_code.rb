class AccountingCode < ActiveRecord::Base
  belongs_to :product

  validates :product, presence: true
  validates :name, presence: true
  validates :code, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :code, scope: :product_id
  validates_uniqueness_of :name, scope: :product_id

  default_scope {order('id ASC')}
  scope :ordered_by_accounting_code, -> {order('code ASC')}
  scope :by_company, ->(company_id) {
    joins(:product)
    .where('products.company_id = ?', company_id)
  }
  scope :by_product, ->(product_id) {
    joins(:product)
    .where('products.id = ?', product_id)
  }

  def detailed_object
    self.as_json.merge({product_name: self.product.name})
  end
end
