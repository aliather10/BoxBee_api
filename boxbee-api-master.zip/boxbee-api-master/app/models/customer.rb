class Customer < ActiveRecord::Base
  after_save :update_search_index

  belongs_to :product
  belongs_to :user
  has_many :appointments
  has_many :routes, through: :appointments
  has_many :subscriptions

  validates :user, presence: true
  validates :product, presence: true
  validates :preferred_address_id, presence: true
  validates :standing, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :user_id, scope: :product_id
  validates_uniqueness_of :stripe_customer_id, allow_nil: true


  enum standing: [:current, :hold, :closed]

  scope :by_company, ->(company_id) {joins(:product).where('products.company_id = ?',
    company_id)}
  scope :by_user, ->(user_id) {where(user_id: user_id)}
  scope :by_product, ->(product_id) {where(product_id: product_id)}
  scope :by_standing, ->(standing) {where(standing: Customer.standings[standing])}

  def detailed_object
    last_appointment_address = Address.find_by_id(self.last_appointment_address_id)
    preferred_address = Address.find_by_id(self.preferred_address_id)
    product = self.product
    recent_invoices = Invoice.by_customer(self.id)
    self.as_json.merge({
      recent_appointments: Appointment.by_product(product.id)
        .where('appointments.status = ? OR appointments.status = ?', Appointment.statuses[:scheduled],
          Appointment.statuses[:confirmed]).limit(3).map(&:with_time_zone),
      recent_invoices: recent_invoices ||= 'not available',
      cards: self.cards ||= 'not available',
      default_card: self.stripe_customer['default_source'],
      last_appointment_address: last_appointment_address ||= 'not available',
      preferred_address: preferred_address ||= 'not available',
      user: self.user,
      customer_items: self.ci_summary
    })
  end

  #Returns detailed user information for a given customer
  def detailed_customer(token = nil)
    user = self.user
    self.as_json.merge({first_name: user.first_name, last_name: user.last_name,
      email: user.email, addresses: user.addresses,
      contact_details: user.contact_details, token: token})
  end

  #Returns detailed UMS user information for an array of product_users
  def self.detailed_customers(customers)
    modified_customers = []
    customers.each do |cus|
      user = cus.user
      modified_customers << cus.as_json.merge({first_name: user.first_name,
        last_name: user.last_name, contact_details: user.contact_details,
        email: user.email})
    end
    return modified_customers
  end

  #Create and associate stripe customer ID to a customer
  def create_and_associate_stripe_customer(stripe_token)
    if self.product.company.products.first.status == 'active'
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
    else
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
    end
    stripe_account_id = self.product.company.stripe_account_id
    stripe_customer = Stripe::Customer.create({source: stripe_token}, {stripe_account: stripe_account_id})
    self.stripe_customer_id = stripe_customer['id']
    self.save!
  end

  def stripe_customer
    if self.user.company.products.first.status == 'active'
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_LIVE_KEY
    else
      Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY
    end
    stripe_account_id = self.product.company.stripe_account_id
    Stripe::Customer.retrieve(self.stripe_customer_id, {stripe_account: stripe_account_id})
  end

  def self.sync(company_id) #For Stripe
    customers = StripeSync.get_list(company_id, "customer") do |stripe_args, stripe_account|
      StripeSync.get_customers(stripe_args, stripe_account)
    end
    StripeSync.synchronize(customers, "customer", company_id)
  end

  def cards
    sc = self.stripe_customer
    cards = sc.sources.all.as_json['data']
  end

  def ci_summary
    CustomerItem.by_customer(self.id).map do |ci|
      ci.summary
    end
  end

  def update_search_index
    Resque.enqueue(SearchSuggestionIndexJob, 'customer', self.id, self.user.company_id)
  end
end
