class EmployeeInvitation < ActiveRecord::Base
  belongs_to :company

  has_secure_token

  validates :company, presence: true
  validates :roles, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
end
