class AppointmentHold
  attr_accessor :slot, :email

  def initialize(slot_id, email)
    @slot = Slot.find(slot_id)
    @email = email
    raise StandardError "This email has a slot reserved already" unless REDIS.keys("appointment_hold*email:#{email}*").empty?
  end

  def reserve
    keys = REDIS.keys("appointment_hold*")
    id = keys.count + 1
    key = "appointment_hold:slot:#{slot.id}:email:#{email}:id:#{id}"
    REDIS.hset(key, 'reserved', true)
    REDIS.expire(key, 600) #Expire after 10 minutes (600 sec)
    return id
  end

  def self.slot(id)
    key = REDIS.keys("appointment_hold*id:#{id}").first
    key_dividers = key.split(':')
    slot_id = key_dividers[key_dividers.index('slot') + 1]
    Slot.find_by_id(slot_id)
  end

  def self.delete_existing_holds(email)
    keys = REDIS.keys("appointment_hold*email:#{email}*")
    keys.each do |key|
      REDIS.del(key)
    end
  end
end
