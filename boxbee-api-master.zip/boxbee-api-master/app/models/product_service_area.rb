class ProductServiceArea < ActiveRecord::Base
  belongs_to :product
  belongs_to :service_area
  validates_uniqueness_of :product_id, scope: :service_area_id
end
