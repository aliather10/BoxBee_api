class JobState < ActiveRecord::Base
  enum job_type: [:revenue, :daily_biller]
  validates :job_type, presence: true
end
