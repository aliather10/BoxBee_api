class ServiceArea < ActiveRecord::Base
  after_create :associate_to_all_products

  include ActiveModel::Validations

  belongs_to :company
  has_many :product_service_areas
  has_many :products, through: :product_service_areas
  has_many :service_area_zips, dependent: :destroy
  has_many :service_area_schedules, dependent: :destroy

  validates :name, presence: true, length: {maximum: 50}
  validates :company_id, presence: true
  validates :time_zone, presence: true
  #validates :active, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_with ServiceAreaValidator

  scope :by_company, ->(company_id) {where(company_id: company_id)}
  scope :by_active_status, ->(active) {where(active: active)}
  scope :by_product, ->(product_id) {joins(:products).where('products.id = ?',
    product_id)}
  scope :by_zip, ->(zip) {
    joins(:service_area_zips)
    .where('service_area_zips.zip = ?', zip)
  }
  def detailed_object
    self.as_json.merge({
      service_area_schedules: self.service_area_schedules,
      service_area_zips: self.service_area_zips})
  end

  def associate_to_all_products
    self.company.products.each do |product|
      ProductServiceArea.create!(product: product, service_area: self)
    end
  end
end
