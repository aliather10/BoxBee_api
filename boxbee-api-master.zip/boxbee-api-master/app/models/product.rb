class Product < ActiveRecord::Base
  include ActiveModel::Validations

  before_save :sync_default_values
  after_commit :check_status
  after_create :generate_default_accounting_codes

  belongs_to :company
  has_many :users, through: :customers
  has_many :product_service_areas
  has_many :service_areas, through: :product_service_areas
  has_many :customers, dependent: :destroy
  has_many :appointment_cutoffs, dependent: :destroy
  has_many :plans, dependent: :destroy
  has_many :appointments
  has_many :faqs, dependent: :destroy
  has_many :accounting_codes, dependent: :destroy
  has_many :taxes, dependent: :destroy
  validates :currency, length: {minimum: 3, maximum: 3}, presence: true


  validates :name, presence: true, length: {maximum: 50}
  validates :description, length: {maximum: 255}
  validates :company_id, presence: true
  validates :status, presence: true
  validates :customer_portal_url, length: {maximum: 255}
  validates :default_customer_portal_url, length: {maximum: 255}
  validates_uniqueness_of :customer_portal_url, allow_nil: true
  validates_uniqueness_of :default_customer_portal_url
  # validates :logo_image_url, presence: true
  validates :support_phone, presence: true, length: {maximum: 50}
  validates :support_email, presence: true, length: {maximum: 255}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :company_id, scope: :name
  validates_with ProductDomainValidator
  validates :hero_text, presence: true
  validates :description_text, presence: true
  validates :what_we_store, presence: true
  # validates :how_it_works1, presence: true
  # validates :how_it_works2, presence: true
  # validates :how_it_works3, presence: true
  validates :our_plans, presence: true
  validates :list_of_service_areas, presence: true
  validates :closing_cta, presence: true
  # validates :about_us_title, presence: true
  # validates :about_us_body, presence: true
  # validates :about_us_image, presence: true
  validates :terms_title, presence: true
  validates :terms_body, presence: true
  validates :faq_title, presence: true

  mount_uploader :logo_image_url, ProductContentImageUploader
  mount_uploader :about_us_image, ProductContentImageUploader
  validates_integrity_of :logo_image_url
  validates_processing_of :logo_image_url
  validates_integrity_of :about_us_image
  validates_processing_of :about_us_image

  scope :by_company, ->(company_id) {where(company_id: company_id)}
  scope :by_user, ->(user_id) {joins(:product_users).where('product_users.user_id = ?',
    user_id)}

  enum status: [:draft, :demo, :active]
  enum currency: ['usd', 'cad', 'aud', 'czk', 'dkk', 'eur', 'hkd', 'huf', 'ils',
    'jpy', 'mxn', 'nok', 'nzd', 'php', 'pln', 'gbp', 'sgd', 'sek', 'chf', 'twd',
    'thb']

  DEFAULT_ACCOUNTING_CODES = [
    {name: 'Storage Revenue', code: 1000, description: 'Recurring storage subscription revenue'},
    {name: 'Delivery Revenue', code: 1100, description: 'One time fees due to pickups and deliveries'},
    {name: 'Misc Revenue', code: 1200, description: 'Other misc. fees'}
  ]

  def detailed_object
    self.as_json.merge({plans: plans, faqs: self.faqs,
      appointment_cutoffs: self.appointment_cutoffs, service_areas: self.service_areas})
  end

  def self.delivery_code
    DEFAULT_ACCOUNTING_CODES.select {|dac| dac[:name] == 'Delivery Revenue'}.first[:code]
  end

  def self.storage_code
    DEFAULT_ACCOUNTING_CODES.select {|dac| dac[:name] == 'Storage Revenue'}.first[:code]
  end

  def self.misc_code
    DEFAULT_ACCOUNTING_CODES.select {|dac| dac[:name] == 'Misc Revenue'}.first[:code]
  end

  def self.matching_products_for_host(host)
    Product.all.select do |product|
      url_to_host(product.customer_portal_url) == host ||
      url_to_host(product.default_customer_portal_url) == host
    end
  end

  def sync_default_values
    #If default_days_of_week, default_daily_start, or default_daily_end are changed, add or
    #subtract service_area_schedules as necessary
    #Iterate through each service_area

    self.service_areas.each do |sa|
      service_area_schedules = sa.service_area_schedules
      sa.service_area_schedules.each do |sas|
        sas.start_time = self.default_daily_start if self.default_daily_start
        sas.end_time = self.default_daily_end if self.default_daily_end
        sas.max_appointments_per_slot = self.default_max_appointments_per_slot if self.default_max_appointments_per_slot
        sas.duration_value_mins = self.default_slot_duration if self.default_slot_duration
        sas.save!
      end
      days = self.default_days_of_week
      ServiceAreaSchedule.day_of_weeks.keys.each do |day|
        #Iterate through each day of the week.
        schedules_on_day = service_area_schedules.select{ |sas|
          sas.day_of_week == day
        }
        if schedules_on_day.empty? && self.default_days_of_week.include?(day)
          #If that day does not have a schedule and should have one, create one
          ServiceAreaSchedule.create!(
            service_area: sa,
            name: "Schedule for #{day}",
            active: true,
            day_of_week: day,
            max_appointments_per_slot: self.default_max_appointments_per_slot,
            duration_value_mins: self.default_slot_duration,
            start_time: self.default_daily_start,
            end_time: self.default_daily_end,
            created_by: self.modified_by,
            modified_by: self.modified_by
          )
        elsif !schedules_on_day.empty? && !self.default_days_of_week.include?(day)
          #If that day does have a schedule but should not have one, delete the schedule
          schedules_on_day.each {|sched| sched.destroy!}
        end
      end
    end
  end

  def check_status
    # Make sure to create and associate stripe live account if first product in company to turn active
    if self.previous_changes[:status] && self.previous_changes[:status][1] == 'active'
      unless self.company.products.where.not(id: self.id).map(&:status).include?('active')
        self.company.create_live_stripe_account
      end
    end
  end

  private
  def generate_default_accounting_codes
    #Generate default accounting codes
    DEFAULT_ACCOUNTING_CODES.each do |code|
      ac = AccountingCode.create(name: code[:name], code: code[:code], description: code[:description],
        created_by: 1, modified_by: 1, product_id: self.id)
    end
  end

  def self.url_to_host(url)
    URI.parse(url).host unless url.nil?
  end
end
