class AddressNoteOption < ActiveRecord::Base
  before_destroy :check_for_custom
  belongs_to :company
  has_many :address_notes
  has_many :addresses, through: :address_notes

  validates :company, presence: true
  validates :note, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_company, ->(company_id) {
    where(company_id: company_id)
  }

  def check_for_custom
    if self.note == "custom"
      errors[:base] << "Cannot delete the custom note template"
      return false
    end
  end
end
