class ServiceAreaScheduleValidator < ActiveModel::Validator

  def validate(record)
    overlapping_service_area_schedules = conflicting_schedules(record)
    unless overlapping_service_area_schedules.empty?
      record.errors[:base] << "Service area schedules are not allowed to overlap for a given service area. Please delete schedules with the following names to continue: #{overlapping_service_area_schedules.map(&:name)}"
    end

    unless record.start_time < record.end_time
      record.errors[:base] << "start_time must be earlier than end_time"
    end
  end

  private
  def conflicting_schedules(record)
    overlapping_service_area_schedules = []
    service_area = record.service_area
    service_area.service_area_schedules.each do |sas|
      if sas.day_of_week == record.day_of_week
        if ((record.start_time >= sas.start_time) && (record.start_time <= sas.end_time)) ||
          ((record.end_time >= sas.start_time) && (record.end_time <= sas.end_time))
          overlapping_service_area_schedules << sas unless record.id && (sas.id == record.id)
        end
      end
    end
    return overlapping_service_area_schedules
  end
end
