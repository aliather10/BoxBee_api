class Route < ActiveRecord::Base
  before_save :check_all_payloads
  before_save :status_changes
  after_save :check_status
  before_destroy :disassociate_appointments

  belongs_to :company
  has_many :appointments
  has_many :customers, through: :appointments

  validates :company_id, presence: true
  validates :name, presence: true, length: {maximum: 50}
  validates :status, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  # validates_uniqueness_of :name, scope: :company_id

  enum status: [:draft, :confirmed, :ready, :outbound, :inbound, :completed]

  scope :by_company, ->(company_id) {where(company_id: company_id)}
  scope :by_driver, ->(driver_id) {where(driver_id: driver_id)}
  scope :by_status, ->(status) {where(status: Route.statuses[status])}

  def detailed_object
    detailed_appointment = self.appointments.first.detailed_object
    time_zone = detailed_appointment[:time_zone]; utc_offset = detailed_appointment[:utc_offset]
    driver_name = self.driver_id ? User.find(self.driver_id).full_name : 'no driver assigned'
    self.as_json.merge({
      vehicle: self.vehicle,
      appointments: self.appointments.map(&:detailed_children),
      payloads: Payload.by_route(self.id).map(&:misc_info),
      route_start: self.datetime_range[:start],
      route_end: self.datetime_range[:end],
      route_transit_histories: RouteHistory.by_route(self.id),
      driver_name: driver_name,
      time_zone: time_zone, utc_offset: utc_offset
    })
  end

  def detailed_object_lite
    self.as_json.merge({
      vehicle: self.vehicle,
      route_transit_histories: RouteHistory.by_route(self.id),
      appointments: self.appointments
    })
  end

  def check_all_payloads
    history = RouteHistory.where(route_id: self.id).first
    if self.status == :outbound && history.current_status == :ready
      appointments = self.appointments
      in_transit_appointments = appointments.select do |te|
        payloads = te.payloads
        in_transit_payloads = payloads
          .select {|payload| payload.payload_status == TransitEventPayload.payload_statuses[:in_transit]}
        payloads.size == in_transit_payloads.size
      end
      if appointments.size == in_transit_appointments.size
        return true
      else
        raise ActiveRecord::RecordInvalid "Cannot move route status from ready to outbound unless all payloads are on truck"
      end
    end
  end

  def check_status
    history = RouteHistory.where(route_id: self.id).first
    if history && self.status != history.current_status
      history = RouteHistory.create(route_id: self.id, previous_status: history.current_status,
        current_status: self.status, created_by: 1, modified_by: 1)
    else
      history = RouteHistory.create(route_id: self.id, current_status: self.status,
        created_by: 1, modified_by: 1)
    end
    return true
  end

  #require the route to have at least 1 transit event in order for status to be changed from "created/draft" to "ready".
  #when all transit events have been removed from a route, ensure status changes from "ready" to "created".
  def status_changes
    changes = self.changes
    unless changes.empty?
      if changes[:status]
        if changes[:status][0] == self.class.statuses[:draft] && changes[:status][1] == self.class.statuses[:ready]
          raise ActiveRecord::RecordInvalid "For a route to have its status to be changed from draft to ready, the route must have at least 1 appointment" if self.appointments.empty?
        elsif changes[:status][0] == self.class.statuses[:ready] && self.appointments.empty?
          self.status = :draft
        elsif changes[:status][1] == self.class.statuses[:outbound]
          self.appointments.each do |aptmt|
            aptmt.appointment_details.each do |ad|
              # Delete inventory records for all payloads that have been loaded on to van
              ad.payloads.each do |payload|
                Inventory.where(sku: payload.sku).first.destroy! unless (payload.status == 'ignored' || 'missing_item')
                warehouse_task = WarehouseTask.where(payload_id: payload.id).first
                warehouse_task.status = :completed
              end
              # Mark the status of all customer_items in the route as :in_transit (unless already ignored (check using payloads))
              customer_item = ad.customer_item
              unless payload.status == ('ignored' || 'missing_item')
                customer_item.status = :in_transit
                customer_item.save!
              end
            end
          end
        elsif (changes[:status][1] == self.class.statuses[:draft]) && !(Inventory.by_route(self.id).select{|inv| inv.location.location_type == 'staging'}.empty?)
          # As soon as 1st item in payload is scanned for picking, route status cannot be reverted back to draft.
          return false
        end
      end
    end
  end

  def datetime_range
    appointments = self.appointments
    range = {}
    if appointments.empty?
      range[:start] = nil; range[:end] = nil;
    else
      te_starts = appointments.map {|te| te.window_start_datetime}
      te_ends = appointments.map {|te| te.window_end_datetime}
      range[:start] = te_starts.min; range[:end] = te_ends.max;
    end
    return range
  end

  def disassociate_appointments
    self.appointments.each do |aptmt|
      aptmt.route_id = nil; aptmt.save!
    end
  end

  def vehicle
    Vehicle.find_by_id(self.vehicle_id)
  end
end
