class Tax < ActiveRecord::Base
  belongs_to :product

  validates :product, presence: true
  validates :tax_percent, presence: true
  validates :zips, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :zips, scope: [:product]
  scope :by_company, ->(company_id) {joins(:product)
    .where('products.company_id = ?', company_id)}
end
