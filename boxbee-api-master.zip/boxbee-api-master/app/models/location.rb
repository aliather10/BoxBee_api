class Location < ActiveRecord::Base
  after_save :update_search_index
  before_destroy :delete_search_index

  belongs_to :warehouse
  has_many :inventories
  has_many :warehouse_orders

  validates :warehouse, presence: true
  validates :location_type, presence: true
  validates :name, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :warehouse_id, scope: [:name]

  enum location_type: [:permanent, :staging, :cart]

  scope :by_warehouse, ->(warehouse_id) {
    joins(:warehouse).where('warehouses.id = ?', warehouse_id)
  }
  scope :by_location_type, ->(loc_type) {
    where(location_type: Location.location_types[loc_type])
  }
  scope :by_company, ->(company_id) {
    joins(:warehouse)
    .where('warehouses.company_id = ?', company_id)
  }

  def detailed_object
    self.as_json
  end

  def update_search_index
    Resque.enqueue(SearchSuggestionIndexJob, 'location', self.id, self.warehouse.company_id)
  end

  def delete_search_index
    Resque.enqueue(DeleteSearchSuggestionIndexJob, 'location', self.id, self.warehouse.company_id)
  end

  def self.terms_for(prefix, company_id)
    SearchSuggestion.parse(
      SearchSuggestion.fetch_matches(prefix, 'location', company_id)
    )
  end

  def delete_search_index
    SearchSuggestion.delete_indices('location', self.id, self.warehouse.company_id)
  end
end
