class Inventory < ActiveRecord::Base
  after_create :update_statuses

  belongs_to :location

  validates :location, presence: true
  validates :inventory_type, presence: true
  validates :inventory_name, presence: true, length: {maximum: 50}
  validates :sku, presence: true, length: {maximum: 50}
  validates :quantity, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  enum inventory_type: [:container, :customer_item]

  scope :by_route, ->(route_id) {where(route_id: route_id)}
  scope :by_company, ->(company_id) {
    joins(location: :warehouse)
    .where('warehouses.company_id = ?', company_id)
  }
  scope :by_inventory_type, ->(type) {where(inventory_type: Inventory.inventory_types[type])}
  scope :by_location_type, ->(loc_type) {joins(:location)
    .where('locations.location_type = ?', Location.location_types[loc_type])}
  scope :by_warehouse, ->(warehouse_id) {
    joins(location: :warehouse)
    .where('warehouses.id = ?', warehouse_id)
  }

  def detailed_object
    self.as_json.merge({location: self.location})
  end

  def self.mass_transfer(inventories, destination_id, company_id)
    updated_inventories = []
    inventories.each do |item|
      task = WarehouseTask.by_company(company_id).find_by_id(item[:warehouse_task_id])
      inventory = Inventory.by_company(company_id).find_by_sku(item[:sku])
      inv_histories_for_this_task = InventoryHistory.where(warehouse_task_id: task.id) if task
      #If the task has not been started yet, start it.
      if task && inv_histories_for_this_task.empty?
        task.status = :started
        task.save!
      end
      if task
        customer_id = task.customer_id
        task_type = task.task_type
      end
      location_type_of_destination = Location.find(destination_id).location_type
      #If moved away from storage inventory_action is :pick
      if location_type_of_destination == 'staging'
        inventory_action = :pick
      #Elsif moved to storage inventory_action is :put
      elsif location_type_of_destination == 'permanent'
        inventory_action = :put
      end
      #For customer_items, we move the same inventory record from one location to another
      if inventory.inventory_type == 'customer_item'
        inventory.location_id = destination_id
        inventory.save!
        set_task_and_payload(task, destination_id, inventory)
        create_inventory_history(task, customer_id,
          inventory.sku, inventory.inventory_type, inventory.location_id,
          inventory.quantity, inventory_action)
        updated_inventories << inventory
      #For containers (e.g. item_types), because we can move partial quantities from one location
      #to another, we create a new inventory record.
      elsif inventory.inventory_type == 'container'
        new_inventory = inventory.dup
        inventory.quantity = inventory.quantity - item[:quantity]
        if inventory.quantity > 0
          inventory.save!
          create_inventory_history(task, customer_id,
            inventory.sku, inventory.inventory_type, inventory.location_id,
            inventory.quantity, inventory_action)
        elsif inventory.quantity == 0
          inventory.destroy!
        else
          raise StandardError "You are trying to remove more items than exist at this location!"
        end
        new_inventory.quantity = item[:quantity]
        new_inventory.location_id = destination_id
        new_inventory.save!
        set_task_and_payload(task, destination_id, new_inventory)
        create_inventory_history(task, customer_id,
          new_inventory.sku, new_inventory.inventory_type, new_inventory.location_id,
          new_inventory.quantity, inventory_action)
        updated_inventories << new_inventory
      end
      updated_inventories << inventory if inventory
    end
    return updated_inventories
  end

  def update_statuses
    if self.inventory_type == 'customer_item'
      customer_item = CustomerItem.by_company(self.location.warehouse.company_id)
        .where(barcode: self.sku).first
      customer_item.status = :in_storage
      customer_item.save!
    end
  end

  private
  def self.create_inventory_history(task, customer_id, sku, inventory_type,
    destination_id, quantity, inventory_action)
    InventoryHistory.create!(inventory_action: inventory_action,
      customer_id: customer_id, sku: sku, inventory_type: inventory_type,
      location_id: destination_id, warehouse_task_id: task.try(:id), quantity: quantity,
      created_by: 1)
  end

  #If a payload moves INTO staging or into storage, the task moves to completed status and payload is
  #updated with location_id
  def self.set_task_and_payload(task, destination_id, inventory)
    if inventory.changes[:location_id]
      destination_type = Location.find(inventory.changes[:location_id][1].to_i).location_type
    else
      destination_type = inventory.location.location_type
    end
    if task && task.task_type == 'put'
      if destination_type == 'permanent'
        task.status = :completed
        task.save!
      end
    elsif task && task.task_type == 'pick'
      if destination_type == 'staging'
        task.status = :completed
        task.save!
        payload = Payload.find(task.payload_id)
        payload.staging_location_id = destination_id
        payload.save!
      end
    end
  end
end
