class ServiceAreaValidator < ActiveModel::Validator
  def validate(record)
    unless valid_time_zone(record)
      record.errors[:base] << 'You must specify a valid time zone name'
    end
  end

  private
  def valid_time_zone(record)
    puts "in Validator, time_zone: #{record.time_zone}"
    puts ActiveSupport::TimeZone.find_tzinfo(record.time_zone).now
    return true
  rescue
    return false
  end
end
