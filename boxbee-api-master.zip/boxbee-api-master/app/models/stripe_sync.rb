class StripeSync
  def self.synchronize(list, field_name, company_id)
    puts "list #{list.class}"
    FIREBASE.update("stripe/#{field_name}/company/#{company_id}", {data: list}).body
  end

  def self.get_stripe_account_id(company_id)
    Company.find(company_id).stripe_account_id
  end

  def self.paginate_all
    has_more = true
    array = []
    starting_after = nil
    while has_more
      obj = yield(starting_after)
      unless obj.empty? || obj['data'].empty?
        obj['has_more'] == true ? has_more = true : has_more = false
        starting_after = obj['data'].last['id']
        obj['data'].each {|element| array << element}
      else
        has_more = false
      end
    end
    return array
  end

  def self.get_list(company_id, field_name, start_date = nil, end_date = nil)
    Company.find(company_id).apply_stripe_api_key
    start_date = Date.new(2015,1,1).to_time.to_i if start_date.nil?
    end_date = Date.tomorrow.to_time.to_i if end_date.nil?
    stripe_account = {stripe_account: get_stripe_account_id(company_id)}
    paginate_all do |starting_after|
      stripe_args = {
        limit: 100,
        created: {gte: start_date, lte: end_date},
        date: {gte: start_date, lte: end_date},
        starting_after: starting_after
      }

      case field_name
      when 'balance_transaction', 'charge', 'customer', 'invoice_item'
        stripe_args = stripe_args.slice(:limit, :created, :starting_after)
      when 'refund'
        stripe_args = stripe_args.slice(:limit, :starting_after)
      when 'invoice'
        stripe_args = stripe_args.slice(:limit, :date, :starting_after)
      else
        stripe_args
      end

      yield(stripe_args, stripe_account)
    end
  end

  def self.get_balance_transactions(stripe_args, stripe_account)
    Stripe::BalanceTransaction.all(stripe_args, stripe_account).as_json
  end

  def self.get_charges(stripe_args, stripe_account)
    Stripe::Charge.all(stripe_args, stripe_account).as_json
  end

  def self.get_customers(stripe_args, stripe_account)
    Stripe::Customer.all(stripe_args, stripe_account).as_json
  end

  def self.get_refunds(stripe_args, stripe_account)
    Stripe::Refund.all(stripe_args, stripe_account).as_json
  end

  def self.get_invoices(stripe_args, stripe_account)
    Stripe::Invoice.all(stripe_args, stripe_account).as_json
  end

  def self.get_invoice_items(stripe_args, stripe_account)
    Stripe::InvoiceItem.all(stripe_args, stripe_account).as_json
  end


  def self.calculate_discount(invoice_item, invoice)
    if invoice_item['discountable'] == true && !invoice['discount'].nil?
      if invoice['discount']['coupon']['percent_off']
        discount = invoice_item['amount'] * invoice['discount']['coupon']['percent_off']
      elsif invoice['discount']['coupon']['amount_off']
        sum_discountable_invoice_lines = invoice['lines'].select {|il| il['discountable'] == true}
          .map {|dil| dil['amount']}.sum
        discount = invoice_item['amount'] * invoice['discount']['coupon']['amount_off'] / sum_discountable_invoice_lines
      else
        discount = 0
      end
    else
      return 0
    end
  end

  ###################From scopes#######################
  def self.filter_by_company(field_name, company_id)
    get_and_parse_cached_list(field_name, company_id)
  end

  def self.filter_by_customer(field_name, customer_id)
    list = get_and_parse_cached_list(field_name)
    stripe_customer_id = Customer.find(customer_id).stripe_customer_id
    case list.first['id'][0..1]
    when 'tx'
      refunds = get_and_parse_cached_list("refund")
      charges = get_and_parse_cached_list("charge")
      list.select do |item|
        if item['source'][0..1] == 're'
          refund = refunds.select{|re| re['id'] == item['source']}.first
          charge = charges.select{|ch| ch['id'] == refund['charge']}.first
        elsif item['source'][0..1] == 'ch'
          charge = charges.select{|ch| ch['id'] == item['source']}.first
        else
          return false
        end
        charge['customer'] == stripe_customer_id
      end
    when 'ch'
      list.select do |item|
        item['customer'] == stripe_customer_id
      end
    when 're'
      charges = get_and_parse_cached_list("charge")
      list.select do |item|
        charge = charges.select{|ch| ch['id'] == item['charge']}.first
        charge ? (charge['customer'] == stripe_customer_id) : false
      end
    when 'cu'
      list.select do |item|
        item['id'] == stripe_customer_id
      end
    when 'in', 'ii'
      list.select do |item|
        item['customer'] == stripe_customer_id
      end
    else
      return []
    end
  end

  def self.filter_by_product(field_name, product_id) #allowable field names: customers, invoices, invoice_items
    get_and_parse_cached_list(field_name).select do |item|
      item['metadata']['product_id'].to_i == product_id
    end
  end

  def self.filter_by_appointment(field_name, appointment_id) #For invoices, invoice items only
    case field_name
    when 'invoice'
      get_and_parse_cached_list('invoice').select do |inv|
        unless inv.dig('lines', 'data', 'metadata')
          inv['lines']['data']['metadata']['appointment_id'].to_i == appointment_id
        end
      end
    when 'invoice_item'
      get_and_parse_cached_list('invoice_item').select do |item|
        unless item.dig('metadata')
          item['metadata']['appointment_id'].to_i == appointment_id
        end
      end
    when 'charge'
      charges = get_and_parse_cached_list('charge')
      invoices = get_and_parse_cached_list('invoice').select do |inv|
        unless inv.dig('lines', 'data', 'metadata').nil?
          inv['lines']['data']['metadata']['appointment_id'].to_i == appointment_id
        end
      end
      if invoices.empty?
        return {}
      else
        invoices.map do |inv|
          charges.select{|ch| ch['id'] == inv['charge']}.first
        end
      end
    else
      return []
    end
  end

  def self.filter_by_invoice(field_name, stripe_invoice_id) #only for invoice_items, charges
    get_and_parse_cached_list(field_name).select do |item|
      item['invoice'] == stripe_invoice_id
    end
  end

  def self.filter_by_accounting_code(field_name, accounting_code) #For invoice_items
    get_and_parse_cached_list(field_name).select do |item|
      item['metadata']['accounting_code'].to_i == accounting_code
    end
  end

  def self.get_and_parse_cached_list(field_name, company_id = nil)
    if company_id
      response = FIREBASE.get("stripe/#{field_name}/company/#{company_id}/data").body
      list = response ? response : []
    else
      puts "in else"
      list = []
      all_companies_list = FIREBASE.get("stripe/#{field_name}/company").body
      Company.all.map(&:id).each do |company_id|
        puts "company_id #{company_id}"
        puts "all_companies_list #{all_companies_list[company_id]}"
        sublist = all_companies_list[company_id]['data'] if all_companies_list[company_id]
        puts "sublist #{sublist}"
        list += sublist if sublist
      end
    end
    return list
  end

  def self.filter_by_date(array, start_date, end_date = nil) #Give dates as Unix timestamps
    end_date = (Date.strptime("#{start_date}", "%s") + 24.hours) unless end_date
    array.select{|element| element['created'] >= start_date && element['created'] <= end_date}
  end

  def self.retrieve_and_sync(stripe_class, stripe_object_id, stripe_account_id, field_name)
    company = Company.find_by_stripe_account_id(stripe_account_id)
    company.apply_stripe_api_key
    object = stripe_class.retrieve(stripe_object_id, {stripe_account: stripe_account_id})
    synchronize([object], field_name, company.id)
  end

  def self.cleaner(field_name, company_id)
    # Wipes out cached Stripe records that no longer pertain to current customers/companies in the database
    stripe_customer_ids = Customer.all.map(&:stripe_customer_id)
    current_stripe_account_id = Company.find(company_id).stripe_account_id
    case field_name
    when 'balance_transaction'
      BalanceTransaction.by_company(company_id).each do |bt|
        unless BalanceTransaction.retrieve(bt['id'], company_id)
          #If a valid BT object is not returned for that company, delete it from REDIS
          key = "stripe_#{field_name}:#{bt['id']}:company:#{company_id}"
          REDIS.del(key) if REDIS.exists(key)
        end
      end
    when 'charge'
      Charge.by_company(company_id).each do |chg|
        key = "stripe_#{field_name}:#{chg['id']}:company:#{company_id}"
        REDIS.del(key) if !stripe_customer_ids.include?(chg['customer']) && REDIS.exists(key)
      end
    when 'refund'
      Refund.by_company(company_id).each do |ref|
        key = "stripe_#{field_name}:#{ref['id']}:company:#{company_id}"
        REDIS.del(key) if ref.dig('metadata', 'customer_id') &&
          !stripe_customer_ids.include?(ref['metadata']['customer_id']) && REDIS.exists(key)
      end
    when 'invoice_item'
      InvoiceItem.by_company(company_id).each do |ii|
        key = "stripe_#{field_name}:#{ii['id']}:company:#{company_id}"
        REDIS.del(key) if !stripe_customer_ids.include?(ii['customer']) && REDIS.exists(key)
      end
    when 'invoice'
      Invoice.by_company(company_id).each do |inv|
        key = "stripe_#{field_name}:#{inv['id']}:company:#{company_id}"
        REDIS.del(key) if !stripe_customer_ids.include?(inv['customer']) && REDIS.exists(key)
      end
    else
    end
  end
end
