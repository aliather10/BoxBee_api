class AppointmentDetail < ActiveRecord::Base
  after_create :create_invoice_item

  belongs_to :appointment
  belongs_to :customer_item
  has_many :payloads

  enum transit_type: [:delivery, :pickup]
  enum request_type: [:empty, :packed]

  validates :appointment, presence: true
  validates :customer_item, presence: true
  validates :transit_type, presence: true
  validates :request_type, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :appointment_id, scope: :customer_item_id

  scope :by_user, ->(user_id) {joins(appointment: :customer)
    .where('customers.user_id = ?', user_id)}
  scope :by_customer, ->(customer_id) {joins(appointment: :customer)
    .where('customers.id = ?', customer_id)}
  scope :by_company, ->(company_id) {joins(appointment: {customer: :product})
    .where('products.company_id = ?', company_id)}
  scope :by_appointment, ->(appointment_id) {where(appointment_id: appointment_id)}
  scope :by_latest_appointment, -> {joins(:appointment).order('appointments.created_at DESC')}

  def create_invoice_item
    # Future suggestion: Move into the background for more efficient processing
    customer = self.appointment.customer
    product = customer.product
    if self.transit_type == 'delivery'
      if self.request_type == 'packed'
        amount = product.packed_delivery_price
      else
        amount = product.empty_delivery_price
      end
    else
      if self.request_type == 'packed'
        amount = product.packed_pickup_price
      else
        amount = product.empty_pickup_price
      end
    end
    accounting_code = Product.delivery_code
    zip = self.appointment.address
    tax_by_zip = product.taxes.select{|tax| tax.zips.include?(zip)}.first
    tax_percent = product.taxed_accounting_codes.include?(accounting_code.to_s) ? (tax_by_zip ? tax_by_zip.tax_percent : product.default_tax) : 0
    tax = tax_percent * amount
    metadata = {
        product_id: product.id,
        tax: tax,
        accounting_code: accounting_code,
        appointment_id: self.appointment_id
    }
    description = "#{self.transit_type.capitalize} on #{self.appointment.window_start_datetime.to_date.to_formatted_s(:short)}"
    currency = product.currency
    InvoiceItem.create(customer.id, amount, description, currency, metadata, product.company_id)
  end
end
