class AppointmentNote < ActiveRecord::Base
  belongs_to :appointment

  validates :appointment, presence: true
  validates :note, presence: true, length: {maximum: 255}
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_company, ->(company_id) {joins(appointment: :product)
    .where(company_id: company_id)}
  scope :by_customer, ->(customer_id) {joins(:appointment).where(customer_id: customer_id)}
  scope :by_user, ->(user_id) {joins(appointment: :customer).where('customers.user_id = ?', user_id)}

  def detailed_object
    self.as_json.merge({appointment: self.appointment})
  end
end
