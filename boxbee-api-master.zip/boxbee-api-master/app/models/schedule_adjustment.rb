class ScheduleAdjustment < ActiveRecord::Base
  include ActiveModel::Validations
  belongs_to :service_area_schedule

  validates :service_area_schedule, presence: true
  validates :name, presence: true, length: {maximum: 50}
  validates :date, presence: true
  validates :new_max_appointments_per_slot, presence: true
  #validates :active, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_with ScheduleAdjustmentValidator

  scope :by_company, ->(company_id) {joins(:service_area)
    .joins(:company).where('companies.id = ?', company_id)}

  def detailed_object
    time_zone = self.service_area_schedule.service_area.time_zone
    self.as_json.merge({service_area_schedule: self.service_area_schedule,
      time_zone: time_zone,
      utc_offset: Time.now.in_time_zone(time_zone).utc_offset/3600
    })
  end
end
