require 'barby'
require 'barby/barcode/code_128'
require 'barby/outputter/cairo_outputter'
require 'prawn'
require "prawn/measurement_extensions"

class Barcode < ActiveRecord::Base
  belongs_to :company

  validates :code, presence: true
  validates :company, presence: true
  validates :created_by, presence: true
  validates_uniqueness_of :code, scope: :company_id

  scope :by_company, ->(company_id) {where(company_id: company_id)}

  def self.generate(quantity, company_id)
    barcodes = []
    used_barcodes = Barcode.by_company(company_id)
    last_code = used_barcodes.empty? ? 1000 : used_barcodes.map(&:code).max
    code = last_code.to_i + 1
    quantity.times do
      barcode = Barcode.create!(company_id: company_id, created_by: 1, code: code)
      barby_barcode = Barby::Code128B.new("#{code}")

      file_path = "#{Rails.root}/tmp/barcode#{code}-client#{company_id}-#{Time.now.to_i}.png"
      file = File.open(file_path, 'wb'){|f| f.write barby_barcode.to_png({xdim: 3, height: 200})}
      raise IOError "Could not save barcode image to file" unless file
      barcodes << {code: code, image_path: file_path}

      code += 1
    end
    return barcodes
  end

  def self.make_csv(barcodes, company_id)
    file_path = "#{Rails.root}/tmp/barcodes-#{Time.now.to_i}-client#{company_id}.csv"
    csv_file = CSV.open(file_path, 'wb') do |csv|
      csv << %w{barcodes}
      barcodes.each do |bc|
        csv << [bc[:code]]
      end
    end
    return file_path
  end

  def self.make_pdf(barcodes, company_id)
    file_path = "#{Rails.root}/tmp/barcodes-#{Time.now.to_i}-client#{company_id}.pdf"
    Prawn::Document.generate(file_path, left_margin: 0.125.in, right_margin: 0.125.in,
      top_margin: 0.5.in, bottom_margin: 0.5.in) do
      no_of_barcodes = barcodes.size
      pages = no_of_barcodes / 10 + (no_of_barcodes % 10 > 0 ? 1 : 0)
      page = 1
      while page <= pages
        bounding_box([0.125.in, 10.in], :width => 8.in, :height => 10.in) do
          define_grid(:columns => 2, :rows => 5, :gutter => 0.0625.in)
          for m in 0..4
            for n in 0..1
              grid(m, n).bounding_box do
                move_down 0.125.in
                image barcodes.first[:image_path], width: 1.5.in, position: :center
                text barcodes.first[:code].to_s, align: :center, size: 18
              end
              barcodes.delete_at 0
            end
          end
          start_new_page if page < pages
          page += 1
        end
      end
    end
    return file_path
  end

  def self.terms_for(prefix, company_id)
    SearchSuggestion.parse(
      SearchSuggestion.fetch_matches(prefix, 'barcode', company_id)
    )
  end
end
