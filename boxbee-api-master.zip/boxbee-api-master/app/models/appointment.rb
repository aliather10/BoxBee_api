class Appointment < ActiveRecord::Base
  before_save :check_status
  after_commit :order_in_route
  after_save :update_search_index
  before_destroy :delete_search_index


  belongs_to :customer
  belongs_to :route
  has_many :appointment_details, dependent: :destroy
  has_many :customer_items, through: :appointment_details
  has_many :customer_fees
  has_many :customers, through: :customer_fees
  has_one :appointment_note, dependent: :destroy

  enum status: [:scheduled, :confirmed, :started, :ignored, :completed, :canceled, :failed]

  validates :customer, presence: true
  validates :address_id, presence: true
  validates :preferred_phone, presence: true, length: {maximum: 20}
  validates :preferred_email, presence: true, length: {maximum: 50}
  validates :status, presence: true
  validates :window_start_datetime, presence: true
  validates :window_end_datetime, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  mount_uploader :approved_signature_url, AssetUploader

  default_scope {
    order('route_sort_order ASC')
    .order('window_start_datetime ASC')
  }
  scope :by_user, ->(user_id) {
    joins(:customer)
    .where('customers.user_id = ?', user_id
  )}
  scope :by_customer, ->(customer_id) {
    where(customer_id: customer_id)
  }
  scope :by_company, ->(company_id) {
    joins(customer: :product)
    .where('products.company_id = ?', company_id
  )}
  scope :by_product, ->(product_id) {
    joins(:customer)
    .where('customers.product_id = ?', product_id
  )}
  scope :by_status, ->(status) {where(status: Appointment.statuses[status])}

  def detailed_object
    price_history = CustomerFee.find_by_appointment_id(self.id)
    appointment_details = self.appointment_details
    fee = price_history.try(:fee, appointment_details)
    product = self.customer.product
    charge = Charge.by_appointment(self.id).first
    time_zone = ServiceArea.by_product(product.id).by_zip(self.address.zip_code).first.time_zone
    card = charge ? self.customer.cards.select{|card| card['id'] == charge['source']}.first : nil
    invoice_items = InvoiceItem.by_appointment(self.id)
    tax = invoice_items.map{ |ii|
      if ii.dig('metadata', 'tax') && ii.dig('metadata', 'accounting_code')
        ii['metadata']['accounting_code'].to_i == Product.delivery_code.to_i ? ii['metadata']['tax'] : 0
      else
        0
      end
    }.sum

    detailed_object = self.as_json.merge({
      user: self.customer.user,
      customer: self.customer,
      product_id: product.id,
      address: self.address,
      appointment_details: appointment_details,
      appointment_note: self.appointment_note,
      price_history: price_history.try(:detailed_object).try(:merge, {fee: fee}),
      tax: tax,
      customer_items: self.customer_items,
      card: (card ||= 'not available'),
      time_zone: time_zone,
      utc_offset: Time.now.in_time_zone(time_zone).utc_offset/3600
    })
    return detailed_object
  end

  def detailed_object_lite
    time_zone = ServiceArea.by_product(self.customer.product.id).by_zip(self.address.zip_code).first.time_zone
    self.as_json.merge({
        user: self.customer.user,
        contact_details: self.customer.user.contact_details,
        time_zone: time_zone,
        utc_offset: Time.now.in_time_zone(time_zone).utc_offset/3600
                       })
  end

  def detailed_children
    self.as_json.merge({
      appointment_note: self.appointment_note,
      # payloads: payloads,
      user: self.customer.user,
      product_id: self.customer.product_id,
      address: self.address.detailed_object
    })
  end

  def payloads
    payloads = []
    self.appointment_details.each {|ad| payloads += ad.payloads}
    return payloads
  end

  def address
    Address.find(self.address_id)
  end

  def with_time_zone
    time_zone = ServiceArea.by_product(self.customer.product_id).by_zip(self.address.zip_code).first.time_zone
    self.as_json.merge({
      time_zone: time_zone,
      utc_offset: Time.now.in_time_zone(time_zone).utc_offset/3600
    })
  end

  def delivery_tax_percent
    product = self.customer.product
    if product.taxed_accounting_codes.include?(Product.delivery_code.to_s)
      product.taxes.select{|tax| tax.zips.include?(self.address.zip_code)}.first
        .tax_percent
    else
      return 0.0
    end
  end

  def self.filter_by_status(appointments, statuses)
    unless statuses.nil?
      appointments_by_status = []
      statuses.each do |status|
        appointments_by_status += appointments.by_status(status)
      end
      appointments = appointments_by_status
    end
  end

  def associate_address(address_id)
    customer = self.customer
    customer.last_appointment_address_id = address_id
    customer.preferred_address_id = address_id
    customer.save!
  end

  def process_cart(cart, created_by, company_id)
    valid_items = []
    cart.each do |cart_obj|
      ##cart_obj must have one of the permitted fields (action always required)
      permitted_fields = !(cart_obj.keys & %w{action customer_item_id request_type transit_type plan_id quantity}).empty?
      ##If action is "new_plan", must have required fields
      if cart_obj['action'] == 'new_plan'
        required_fields = cart_obj['plan_id'] && cart_obj['quantity'] && cart_obj['request_type'] && cart_obj['transit_type']
      end
      ##If action is "update_customer_item", must have required fields
      if cart_obj['action'] == 'update_customer_item'
        required_fields = cart_obj['customer_item_id'] && cart_obj['request_type'] && cart_obj['transit_type']
      end
      ##If action is "remove_customer_item", must have required fields
      if cart_obj['action'] == 'remove_customer_item'
        required_fields = cart_obj['customer_item_id']
      end
      ##If action is "remove_plan", must have required fields
      if cart_obj['action'] == 'remove_plan'
        required_fields = cart_obj['plan_id']
      end
      ##If action is "update_plan", must have required fields
      if cart_obj['action'] == 'update_plan'
        required_fields = cart_obj['plan_id'] && cart_obj['quantity']
      end

      valid_items << permitted_fields && required_fields

      if valid_items.last #Only proceed if cart cart_obj is properly formatted
        #Now that validations are done, actually process the cart.
        if cart_obj['action'] == 'new_plan'
          plan = Plan.by_company(company_id).find(cart_obj['plan_id'])
          subscription = Subscription.where(plan: plan, customer_id: self.customer_id, active: true).first
          # Create invoice_item for the remainder of this month for the newly added items.
          create_invoice_item_for_new_plan(plan, cart_obj['quantity'])
          subscription = subscription ||= Subscription.create!(plan: plan, customer_id: self.customer_id, active: true,
            price_per_plan: plan.price_per_plan, created_by: created_by, modified_by: created_by)
          item_type = plan.item_type #v1
          cart_obj['quantity'].to_i.times do
            customer_item = CustomerItem.create!(
              subscription: subscription,
              item_type: item_type,
              status: :scheduled,
              created_by: created_by,
              modified_by: created_by
            )
            create_ci_history(customer_item.id, :scheduled, self.id, created_by)
            create_appointment_detail(self.id, customer_item, cart_obj['transit_type'],
            cart_obj['request_type'], created_by)
          end
          #Case: Request delivery or pickup for a customer_item
        elsif cart_obj['action'] == 'update_customer_item'
          customer_item = CustomerItem.by_customer(self.customer_id).find(cart_obj['customer_item_id'])
          customer_item.status = :scheduled; customer_item.save!
          puts "about to create appointment detail..."
          create_appointment_detail(self.id, customer_item, cart_obj['transit_type'],
            cart_obj['request_type'], created_by)
          #Case: Remove an active form factor from an existing appointment
        elsif cart_obj['action'] == 'remove_customer_item'
          customer_item = CustomerItem.by_customer(self.customer_id).find(cart_obj['customer_item_id'])
          AppointmentDetail.by_appointment(self.id)
            .find_by_customer_item_id(customer_item.id).destroy
          #Revert AFF back to its previous status
          history = CustomerItemHistory.by_customer_item(customer_item.id)
            .by_appointment(self.id).first
          customer_item.status = history.current_status
          new_history = create_ci_history(customer_item.id, customer_item.status, self.id, created_by)
          new_history.previous_status = history.current_status
          new_history.save!
          #Case: Remove a plan that was requested as part of an existing appointment
        elsif cart_obj['action'] == 'remove_plan'
          # Refund or delete invoice_item associated with the last appointment
          invoice_items = InvoiceItem.by_appointment(self.id).select do |ii|
            ii.dig('metadata', 'plan_id') ? ii['metadata']['plan_id'].to_i == cart_obj['plan_id'].to_i : false
          end
          Refund.refunder(invoice_items, self.customer.user.company_id, nil)

          plan = Plan.by_company(company_id).find(cart_obj['plan_id'])
          subscription = plan.subscriptions.find_by_customer_id(self.customer.id)
          subscription.customer_items.each do |ci|
            AppointmentDetail.by_appointment(self.id)
            .find_by_customer_item_id(ci.id).destroy
            #Update history
            create_ci_history(ci.id, :extinct, nil, created_by)
            ci.destroy!
          end
          subscription.destroy! if subscription.customer_items.empty?
          #Case: Change of ordered plan quantity for an existing appointment or a plan
          #that the customer already subscribes to.
        elsif cart_obj['action'] == 'update_plan'
          plan = Plan.by_company(company_id).find(cart_obj['plan_id'])
          subscription = Subscription.where(plan: plan, customer_id: self.customer_id).first
          #For modifying the quantity of a subscription in an *existing* appointment
          customer_items = subscription.customer_items
          item_type = plan.item_type #v1
          ad = customer_items.first.appointment_details.where(appointment: self).first
          transit_type = ad.transit_type
          request_type = ad.request_type
          if customer_items.size < cart_obj['quantity'].to_i #add CIs to a plan
            qty_to_add = cart_obj['quantity'].to_i - customer_items.size
            # Pay for the remainder of the month for the new items added
            create_invoice_item_for_new_plan(plan, qty_to_add)
            qty_to_add.times do
              customer_item = CustomerItem.create(subscription: subscription,
                item_type: item_type, status: :scheduled, created_by: created_by,
                modified_by: created_by)
              create_ci_history(customer_item.id, :scheduled, self.id, created_by)
              create_appointment_detail(self.id, customer_item, transit_type,
                request_type, created_by)
            end
          else #remove CIs from a plan
            qty_to_remove = customer_items.size - cart_obj['quantity'].to_i
            #Find the subset of customer_items which were created in this particular appointment
            removable_cis = CustomerItem.from_original_appointment(self.id, customer_items)
            for ii in 1..qty_to_remove
              ci = removable_cis.to_a[ii]
              AppointmentDetail.by_appointment(self.id)
                .find_by_customer_item_id(ci.id).destroy!
              create_ci_history(ci.id, :extinct, nil, created_by)
              ci.destroy!
            end
            # No refunds for removed quantities of a plan.
          end
        end
      end
    end
    valid_items.size == cart.size
  end

  def assign_to_route
    puts "in assign_to_route"
    company = self.customer.product.company
    #Account for timezone
    zip_code = self.address.zip_code.to_s
    time_zone = self.customer.product.service_areas.by_zip(zip_code).first.time_zone
    Time.use_zone(time_zone) do
      #Check first to see if a route already exists for that day for a particular warehouse
      current_warehouse_id = self.appointment_details.first.payloads.first.warehouse_id
      payloads = AppointmentDetail.by_company(self.customer.product.company_id)
        .map{|ad| ad.payloads.first}
      routes = payloads.select { |payload|
        if payload
          payload.warehouse_id == current_warehouse_id &&
          payload.appointment_detail.appointment.window_start_datetime.to_date == self.window_start_datetime.to_date
        end
      }
        .map{|payload| payload.appointment_detail.appointment.route}
        .select{|route| !route.nil? && (route.status == 'draft' || route.status == 'confirmed')}
      routes.uniq!{|r| r.id}

      if routes.empty?
        #Create route
        route = Route.create!(
          company: company,
          vehicle_id: company.vehicles.first.id,
          name: "#{Time.now.to_date} - 1",
          status: :draft,
          created_by: 1,
          modified_by: 1
        )
        self.route = route
        self.save!
        puts "creating route..."
      else
        #Add to existing route
        self.route = routes.first
        self.save!
        puts "adding appointment to existing route..."
      end
      puts "THE route: #{self.route.inspect}"
      return self.route
    end
  end

  def update_search_index
    Resque.enqueue(SearchSuggestionIndexJob, 'appointment', self.id, self.customer.user.company_id)
  end

  def delete_search_index
    Resque.enqueue(DeleteSearchSuggestionIndexJob, 'appointment', self.id, self.customer.user.company_id)
  end

  private
  def create_appointment_detail(appointment_id, customer_item, transit_type, request_type, created_by)
    AppointmentDetail.create!(appointment_id: appointment_id,
      customer_item: customer_item, transit_type: transit_type,
      request_type: request_type, created_by: created_by, modified_by: created_by)
  end

  def create_ci_history(ci_id, status, appointment_id, created_by)
    CustomerItemHistory.create(customer_item_id: ci_id,
      current_status: status, appointment_id: appointment_id,
      created_by: created_by, modified_by: created_by)
  end

  def create_invoice_item_for_new_plan(plan, quantity)
    time_zone = ServiceArea.by_zip(self.address.zip_code).first.time_zone
    amount = nil
    Time.use_zone(time_zone) do
      now = Time.current.in_time_zone
      today = now.day
      end_of_month = now.end_of_month.day
      amount = ((end_of_month - today) / (end_of_month - 1)) * quantity.to_i * plan.price_per_plan
    end
    product = plan.product
    accounting_code = Product.storage_code
    zip = self.address.zip_code
    tax_by_zip = product.taxes.select{|tax| tax.zips.include?(zip)}.first
    tax_percent = product.taxed_accounting_codes.include?(accounting_code.to_s) ? (tax_by_zip ? tax_by_zip.tax_percent : product.default_tax) : 0
    tax = tax_percent * amount
    metadata = {
      plan_id: plan.id,
      product_id: product.id,
      tax: tax,
      accounting_code: accounting_code,
      quantity: quantity.to_i,
      appointment_id: self.id
    }
    currency = product.currency
    description = "Storage subscription for #{plan.name} plan through #{Date::MONTHNAMES[Date.today.month]} end, QTY: #{quantity}"
    InvoiceItem.create(self.customer_id, amount, description, currency, metadata, self.customer.user.company.id)
  end

  def check_status
    puts "in check status"
    changes = self.changes
    unless changes.empty?
      if changes[:status]
        raise ActiveRecord::RecordInvalid "Appointments cannot be changed after reaching status: complete" if changes[:status][0] == self.class.statuses[:completed]
        if changes[:status][1] == self.class.statuses[:completed]
          # Update all statuses of customer_items in this appointment that were delivered to customer to :with_user
          # Update all statuses of customer_items in this appointment that were picked up from customer to :in_transit
          # Unless already ignored/missing (check using payloads)
          self.appointment_details.map(&:customer_item).each do |customer_item|
            case customer_item.appointment_detail.transit_type
            when 'pickup'
              customer_item.status = :in_transit
            when 'delivery'
              customer_item.status = :with_user
            end
            customer_item.save!
          end
          # Mark the time that the appointment was completed
          self.event_end_time = DateTime.now
        elsif changes[:status][1] == self.class.statuses[:canceled]
          # Remove all subscriptions, customer_items
          removable_cis = CustomerItem.from_original_appointment(self.id, customer_items)
          removable_cis.each do |ci|
            create_ci_history(ci.id, :extinct, nil, self.customer.user_id)
            ci.destroy!
          end
          subscription = removable_cis.first.subscription
          subscription.destroy! if subscription.customer_items.empty?
          # Refund or delete invoice_items as applicable
          invoice_items = InvoiceItem.by_appointment(self.id)
          Refund.refunder(invoice_items, self.customer.user.company_id, nil)
          self.canceled_timestamp = DateTime.now
        elsif changes[:status][1] == self.class.statuses[:started]
          self.event_start_time = DateTime.now
        end
      end
    end
  end

  protected
  def order_in_route
    if previous_changes[:route_id] && previous_changes[:route_id][1] && previous_changes[:route_id][0].nil?
      groups = []; ct = 1; hash = {}
      self.route.appointments.each do |aptmt|
        puts "in appointment #{aptmt.id}"
        within_group = groups.select{|g| aptmt.window_start_datetime >= g[:start] && aptmt.window_end_datetime <= g[:end]}.first
        # self_within_group = groups.select{|g| self.window_start_datetime >= g[:start] && self.window_end_datetime <= g[:end]}.first
        if within_group
          hash[within_group[:id]] = [] if hash[within_group[:id]].nil?
          hash[within_group[:id]] += [aptmt]
          # elsif self_within_group
          #   hash[self_within_group[:id]] += [self]
        else
          groups << {id: ct, start: aptmt.window_start_datetime, end: aptmt.window_end_datetime}
          hash[ct] = [] if hash[ct].nil?
          # if !within_group && !self_within_group
          #   hash[ct] += [self]
          # else
          hash[ct] += [aptmt]
          # end
          ct += 1
        end
      end
      puts "hash of appointments and groups #{hash.inspect}"
      ct = 1
      hash.each do |group_id, aptmts|
        aptmts.each do |aptmt|
          aptmt.route_sort_order = ct
          aptmt.save!
          ct += 1
        end
      end
    end
  end
end
