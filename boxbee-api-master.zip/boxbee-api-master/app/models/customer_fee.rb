class CustomerFee < ActiveRecord::Base
  belongs_to :customer
  belongs_to :appointment

  validates :customer, presence: true
  validates :appointment, presence: true
  validates :empty_delivery_price, presence: true
  validates :packed_pickup_price, presence: true
  validates :packed_delivery_price, presence: true
  validates :empty_pickup_price, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :appointment_id

  scope :by_customer, ->(customer_id) {
    joins(:customer)
    .where('customers.id = ?', customer_id)
  }

  def detailed_object(fee = nil)
    fee = fee ||= self.fee
    appointment = self.appointment
    appointment_details = appointment.appointment_details
    hproc = Proc.new {|ad, request_type, transit_type| ad.transit_type == transit_type && ad.request_type == request_type}
    self.as_json.merge({
      fee: fee,
      empty_delivery_quantity: appointment_details.select{|ad| hproc.call(ad, 'empty', 'delivery')}.size,
      packed_pickup_quantity: appointment_details.select{|ad| hproc.call(ad, 'packed', 'pickup')}.size,
      packed_delivery_quantity: appointment_details.select{|ad| hproc.call(ad, 'packed', 'delivery')}.size,
      empty_pickup_quantity: appointment_details.select{|ad| hproc.call(ad, 'empty', 'pickup')}.size,
      tax: appointment.delivery_tax_percent * fee
    })
  end

  def fee(appointment_details = nil)
    # !!! To use this method in the new app, All of this logic needs to be fixed- it is still legacy.
    # appointment_details = appointment_details ||= AppointmentDetail.find_by_appointment_id(self.appointment_id)
    # billable_transit_count = Billing::StripeTransitBiller.billable_transit_counter(appointment_details)
    # amount = 0
    # billable_transit_count.each do |key, value|
    #   amount += Billing::StripeTransitBiller.transit_subtotaler(self.customer.product, key, value)
    # end
    # return amount
    return 0
  end
end
