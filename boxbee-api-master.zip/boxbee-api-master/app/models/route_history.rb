class RouteHistory < ActiveRecord::Base
  validates :route_id, presence: true
  validates :previous_status, length: {maximum: 50}
  validates :current_status, presence: true, length: {maximum: 50}
  validates :created_by, presence: true
  validates :modified_by, presence: true

  default_scope  { order(:updated_at => :desc) }

  scope :by_route, ->(route_id) {where(route_id: route_id)}
end
