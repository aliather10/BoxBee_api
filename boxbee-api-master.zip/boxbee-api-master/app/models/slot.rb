class Slot < ActiveRecord::Base
  belongs_to :service_area_schedule

  validates :service_area_schedule, presence: true
  validates :start_datetime, presence: true
  validates :end_datetime, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_product, ->(product_id) {joins(service_area_schedule: {service_area: :products})
    .where('products.id = ?', product_id)}
  scope :by_date, ->(date) {where('start_datetime > ? AND start_datetime < ?', date, date + 1.day)}

  def self.unavail_slots_by_month(mo, yr, product, zip)
    # Construct a start and end_date, non inclusive for end date.
    unavailable_days = []
    appointment_cutoff = product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types['creation']).first
    service_areas = ServiceArea.by_product(product.id).by_zip(zip)
    service_areas.each do |service_area|
      service_area_schedules = service_area.service_area_schedules.by_active(true)
      time_zone = service_area.time_zone
      Time.use_zone(time_zone) do
        start_datetime = Time.zone.local(yr, mo, 1)
        end_datetime = (start_datetime + 5.months).end_of_month
        next_avail_datetime = Time.current.in_time_zone + appointment_cutoff.lead_time.hours

        holiday_schedules = Holiday.by_company(product.company_id)

        month = start_datetime.to_date...end_datetime.to_date
        for date_of_mo in month
          # Eliminate holidays from results, make sure date is available in OAS
          if date_of_mo < next_avail_datetime.to_date || !Slot.within_any_oa_schedule(date_of_mo, service_area_schedules)
            unavailable_days << date_of_mo
          end
          holiday_schedules.each do |holiday|
            if holiday.end_date
              if date_of_mo <= holiday.end_date && date_of_mo >= holiday.date
                unavailable_days << date_of_mo
              end
            else
              unavailable_days << date_of_mo if ((holiday.date == date_of_mo) && (!unavailable_days.include? date_of_mo))
            end
          end
        end
    end
    end
    return unavailable_days.map(&unix_time).uniq
  end

  def self.avail_slots_by_date(date, product, zip)
    # Find all operating area schedules that a customer belongs to.
    # Only allow ACTIVE sas s
    service_areas = ServiceArea.by_product(product.id).by_zip(zip)
    service_areas.each do |service_area|
      time_zone = service_area.time_zone
      Time.use_zone(time_zone) do
        service_area_schedules = service_area.service_area_schedules.by_active(true).by_day_of_week(date.strftime('%A').downcase)
        return [] if service_area_schedules.empty?
        service_area_schedules = service_area_schedules.to_a.select do |sas|
          if sas.schedule_start_date
            date >= sas.schedule_start_date
          elsif sas.schedule_start_date && sas.schedule_end_date
            date >= sas.schedule_start_date && date <= sas.schedule_end_date
          else
            true
          end
        end

        service_area_schedules.each do |sas|
          # Check for any schedule_adjustments
          # Find max_appointment_per_slot and slot_duration for each sas (account for schedule_adjustments)
          schedule_adjustments = sas.schedule_adjustments.select do |adj|
            if adj.end_date
              date >= adj.date && date <= adj.end_date && sas.day_of_week == date.strftime('%A').downcase
            else
              date >= adj.date && sas.day_of_week == date.strftime('%A').downcase
            end
          end

          if schedule_adjustments.empty?
            max_appointments_per_slot = sas.max_appointments_per_slot
          else
            max_appointments_per_slot = schedule_adjustments.first.new_max_appointments_per_slot
          end

          appointment_cutoff = product.appointment_cutoffs.where(cutoff_type: AppointmentCutoff.cutoff_types['creation']).first
          soonest_avail_datetime = Time.current.in_time_zone + appointment_cutoff.lead_time.hours
          slots = sas.slots.by_date(date).to_a
          # Iterate through all slots in the sas.
          categorized_slots = []

          slots.each do |slot|
            count = 0
            # Determine the current appointments + appointment_hold count for that appointment
            appointments = Appointment.by_product(product.id).where(window_start_datetime: slot.start_datetime,
              window_end_datetime: slot.end_datetime)
            count += appointments.to_a.size
            count += 1 if slot.appointment_hold?
            # Compare count against max_appointment_per_slot
            # If < max_appointment_per_slot, allow the slot to be available
            if (slot.start_datetime < soonest_avail_datetime) || (count > max_appointments_per_slot)
              #Mark as unavailable
              availability = false
            else
              #Mark as available
              availability = true
            end
            categorized_slots << {
              id: slot.id,
              service_area_schedule_id: slot.service_area_schedule_id,
              available: availability,
              start_datetime: slot.start_datetime.to_time.to_i,
              end_datetime: slot.end_datetime.to_time.to_i
            }
          end
          return categorized_slots
        end
      end
    end
  end

  def self.create_future_slots(duration, override_time_check=nil)
    ServiceArea.all.each do |service_area|
      create_future_slots_by_service_area(service_area, duration, override_time_check)
    end
  end

  def self.create_future_slots_by_service_area(service_area, duration, override_time_check = nil)
    time_zone = service_area.time_zone
    Time.use_zone(time_zone) do
      right_now = Time.current.in_time_zone
      if override_time_check || (not_run_in_last_24_hrs(service_area.id) && right_now.hour >= Figaro.env.EARLIEST_SLOT_CREATION_TIME.to_i)
        start_date = Date.current.in_time_zone + 1.day
        end_date = start_date + duration
        #Iterate through each Operating Area Schedule for each operating area
        service_area_schedules = service_area.service_area_schedules
        service_area_schedules.each do |sas|
          #Loop through each day for the next 6 months
          for day in start_date.to_date..end_date.to_date
            schedule_adjustments = sas.schedule_adjustments.select do |adj|
              if adj.end_date
                day >= adj.date && day <= adj.end_date && sas.day_of_week == day.strftime('%A').downcase
              else
                day >= adj.date && sas.day_of_week == day.strftime('%A').downcase
              end
            end

            if schedule_adjustments.empty?
              slot_duration = sas.duration_value_mins
            else
              slot_duration = schedule_adjustments.first.new_duration_value_mins
            end

            last_slot_end = (day + sas.start_time.seconds).to_datetime
            while last_slot_end <= day + sas.end_time.seconds - slot_duration.minutes
              start_datetime = last_slot_end
              end_datetime = start_datetime + slot_duration.minutes
              if sas.slots.where(start_datetime: start_datetime, end_datetime: end_datetime).empty?
                slot = Slot.create(service_area_schedule: sas, start_datetime: start_datetime,
                                   end_datetime: end_datetime, created_by: 1, modified_by: 1)
              end
              last_slot_end = end_datetime
            end
          end
        end
        # Tell Redis that this iteration (operating area) was successfully completed.
        redis_result = REDIS.hmset("service_area:#{service_area.id}:slot_creation", "last_run", Time.current.in_time_zone.to_i)
      end
    end
  end

  def appointment_hold?
    !REDIS.keys("appointment_hold:slot:#{self.id}:*").empty?
  end

  private
  def self.within_any_oa_schedule(date_of_mo, service_area_schedules)
    date_check = []; dow_check = [];
    service_area_schedules.each do |sas|
      if sas.schedule_start_date && sas.schedule_end_date
        date_check << date_of_mo >= sas.schedule_start_date && date_of_mo <= sas.schedule_end_date
      elsif sas.schedule_start_date
        date_check << date_of_mo >= sas.schedule_start_date
      elsif sas.schedule_end_date
        date_check << date_of_mo <= sas.schedule_end_date
      else
        date_check << true
      end
      dow_check << (sas.day_of_week == date_of_mo.strftime('%A').downcase)
    end
    (date_check.include?(true) && dow_check.include?(true)) ? true : false
  end

  def self.unix_time
    return Proc.new {|datetime| datetime.to_time.to_i}
  end

  def self.not_run_in_last_24_hrs(service_area_id)
    if REDIS.exists("service_area:#{service_area_id}:slot_creation")
      last_run_time_unix = REDIS.hget("service_area:#{service_area_id}:slot_creation", "last_run")
      last_run_time = DateTime.strptime("#{last_run_time_unix}", "%s")
      if (Time.current.in_time_zone - last_run_time) >= 24.hours
        return true
      else
        puts "it hasn't been 24 hours yet"
        return false
      end
    else
      return true
    end
  end
end
