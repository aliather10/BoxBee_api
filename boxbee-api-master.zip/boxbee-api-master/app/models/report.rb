class Report < ActiveRecord::Base
  enum report_type: [:revenue]
  mount_uploader :csv_file, ReportUploader

  validates :company_id, presence: true
  validates :report_type, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
end
