class ScheduleAdjustmentValidator < ActiveModel::Validator
  def validate(record)
    unless non_overlap(record)
      record.errors[:base] << 'Schedule schedule_adjustments are not allowed to overlap for a given service area schedule'
    end
  end

  private
  def non_overlap(record)
    other_schedule_adjustments = record.service_area_schedule.schedule_adjustments
    unless other_schedule_adjustments.empty?
      other_schedule_adjustments.each do |other_adj|
        if record.date
          if other_adj.date >= record.date
            return false
          else
            return true
          end
        elsif record.date && record.end_date
          if other_adj.date >= record.date && other_adj.date <= record.end_date
            return false
          else
            return true
          end
        end
      end
    else
      return true
    end
  end
end
