class CustomerItemValidator < ActiveModel::Validator
  def validate(record)
    unless barcode_is_unique?(record)
      record.errors[:base] << 'Barcodes must be unique for a given company'
    end
  end

  private
  def barcode_is_unique?(record)
    company = record.item_type.company
    Company.where('id != ?', company.id).each do |company|
      unless record.barcode.nil?
        return false if CustomerItem.by_company(company.id).map(&:barcode).include?(record.barcode)
      end
    end
  end
end
