class CompanyDetail < ActiveRecord::Base
  before_save :mail_go_live_request

  belongs_to :company
  enum entity_type: [:llc, :corporation, :sole_proprietorship, :partnership,
    :s_corp, :c_corp]
  validates_uniqueness_of :company_id

  def mail_go_live_request
    if self.changes[:requested_invite]
      if self.changes[:requested_invite][1]
        BoxbeeMailer.go_live_mailer(self.company).deliver_now
      end
    end
  end
end
