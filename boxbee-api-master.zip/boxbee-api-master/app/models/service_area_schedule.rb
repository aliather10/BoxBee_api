class ServiceAreaSchedule < ActiveRecord::Base
  include ActiveModel::Validations

  belongs_to :service_area
  has_many :schedule_adjustments, dependent: :destroy
  has_many :slots

  validates :service_area, presence: true
  validates :name, presence: true, length: {maximum: 50}
  validates :day_of_week, presence: true, length: {maximum: 10}
  validates :start_time, presence: true
  validates :end_time, presence: true
  validates :max_appointments_per_slot, presence: true
  validates :duration_value_mins, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :service_area, scope: :name
  validates_with ServiceAreaScheduleValidator

  enum day_of_week: [:sunday, :monday, :tuesday, :wednesday, :thursday, :friday, :saturday]

  scope :by_company, ->(company_id) {joins(:service_area)
    .where('service_areas.company_id = ?', company_id)}
  scope :by_active, ->(active) {where(active: active)}
  scope :by_day_of_week, ->(day_of_week) {where(day_of_week: ServiceAreaSchedule.day_of_weeks[day_of_week])}

  def detailed_object
    time_zone = self.service_area.time_zone
    self.as_json.merge({service_area: self.service_area, schedule_adjustments: self.schedule_adjustments,
      time_zone: time_zone, utc_offset: Time.now.in_time_zone(time_zone).utc_offset/3600})
  end
end
