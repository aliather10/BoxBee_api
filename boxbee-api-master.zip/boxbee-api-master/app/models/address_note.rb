class AddressNote < ActiveRecord::Base
  belongs_to :address
  belongs_to :address_note_option

  validates :address, presence: true
  validates :note, length: {maximum: 140}
  validates :created_by, presence: true
  validates :modified_by, presence: true
  validates_uniqueness_of :address

  def fetch_note
    if self.address_note_option.note == "custom"
      self.note
    else
      self.address_note_option.note
    end
  end

  def detailed_object
    self.as_json.merge({address: self.address})
  end
end
