class Holiday < ActiveRecord::Base
  belongs_to :company

  validates :company, presence: true
  validates :name, presence: true, length: {maximum: 50}
  validates :date, presence: true
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_company, ->(company_id) {where(company_id: company_id)}
end
