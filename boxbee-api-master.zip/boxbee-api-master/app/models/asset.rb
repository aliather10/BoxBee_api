class Asset < ActiveRecord::Base
  belongs_to :customer_item
  mount_uploader :asset_value, AssetUploader

  enum asset_type: [:video, :document, :image]

  validates :customer_item, presence: true
  validates :asset_type, presence: true
  validates :asset_value, presence: true
  validates :sort_order, presence: true, numericality: {greater_than_or_equal_to: 0}
  validates :created_by, presence: true
  validates :modified_by, presence: true

  scope :by_company, ->(company_id) {joins(customer_item: :item_type)
    .where('item_types.company_id = ?', company_id)}
  scope :by_customer, ->(customer_id) {joins(customer_item: :subscription)
    .where('subscriptions.customer_id = ?', customer_id)}

  def self.download_image_from_s3(key)
    s3 = Aws::S3::Resource.new(
      region: Figaro.env.AWS_REGION,
      access_key_id: Figaro.env.AWS_ACCESS_KEY_ID,
      secret_access_key: Figaro.env.AWS_SECRET_ACCESS_KEY
    )
    split_file_name = key.split('.')
    file_path = "tmp/#{[split_file_name[0].parameterize, split_file_name[1]].join('.')}"
    s3.bucket(Figaro.env.AWS_BUCKET).object(key)
      .get(response_target: file_path)
    return file_path
  end
end
