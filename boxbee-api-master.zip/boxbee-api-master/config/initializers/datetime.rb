Time::DATE_FORMATS[:boxbee_datetime] = "%m/%d/%Y %H:%M"
