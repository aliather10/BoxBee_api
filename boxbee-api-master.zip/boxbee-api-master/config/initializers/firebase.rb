unless Rails.env.test?
  base_uri = Figaro.env.FIREBASE_BASE_URI
  secret = Figaro.env.FIREBASE_TOKEN

  FIREBASE = Firebase::Client.new(base_uri, secret)
end
