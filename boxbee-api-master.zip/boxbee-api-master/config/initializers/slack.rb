if Figaro.env.SLACK_PREVIEW_SIGNUP_URL
  SLACK_SIGNUP_NOTIFIER = Slack::Notifier.new Figaro.env.SLACK_PREVIEW_SIGNUP_URL
  SLACK_CRITICAL_NOTIFIER = Slack::Notifier.new Figaro.env.SLACK_PREVIEW_SIGNUP_URL,
    '#new-relic'
end
