unless Rails.env.test?
  CarrierWave.configure do |config|
    config.fog_credentials = {
      provider:               'AWS',
      aws_access_key_id:      Figaro.env.AWS_ACCESS_KEY_ID,
      aws_secret_access_key:  Figaro.env.AWS_SECRET_ACCESS_KEY,
      region:                 Figaro.env.AWS_REGION
    }
    config.fog_directory  = Figaro.env.AWS_BUCKET
    config.fog_public     = true
  end
end

# Ref:
# https://support.cloud.engineyard.com/entries/20996881-Use-CarrierWave-and-Optionally-Fog-to-Upload-and-Store-Files#update3
# http://stackoverflow.com/questions/7946819/carrierwave-and-amazon-s3
