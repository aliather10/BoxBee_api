unless Rails.env.test?
  Timezone::Lookup.config(:geonames) do |c|
    c.username = Figaro.env.GEONAMES_USER
  end
end
