#Initialize a tracker for mixpanel to be used throughout the app
require 'mixpanel-ruby'

TRACKER = Mixpanel::Tracker.new(Figaro.env.MIXPANEL_TOKEN)