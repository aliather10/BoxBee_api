ActionMailer::Base.delivery_method = :smtp
if Rails.env.production? || Rails.env.staging?
  ActionMailer::Base.smtp_settings = {
    address:        'smtp.sendgrid.net',
    port:           '587',
    authentication: :plain,
    user_name:      Figaro.env.SENDGRID_USERNAME,
    password:       Figaro.env.SENDGRID_PASSWORD,
    domain:         'heroku.com',
    enable_starttls_auto: true
  }
elsif Rails.env.development?
  ActionMailer::Base.smtp_settings = {
      address:        'localhost',
      port:           '1025'
  }
end
