require 'resque/server'

class AdminRestriction
  def self.matches?(request)
    user = request.env['warden'].authenticate!(:database_authenticatable, :rememberable, :scope => :user)
    return user && user.super_user?
  end
end

Rails.application.routes.draw do
  authenticated :user do
    root :to => "api/v1/docs#index", as: :authenticated_root
  end

  # root :to => "licensing#index"

  get 'documentation', to: 'api/v1/docs#index'
  root 'api/v1/docs#index'
  devise_for :users
  get 'licensing', to: 'licensing#index'
  namespace :api do
    namespace :v1 do
      get 'docs', to: 'docs#index'
      get 'docs/data/json/apidocs', to: 'docs#swagger_json'
    end
  end

  namespace :api do
    namespace :v1 do
      devise_for :users, controllers: {
        sessions: 'api/v1/users/sessions',
        passwords: 'api/v1/users/passwords',
        unlocks: 'api/v1/users/unlocks'
      }

      namespace :reports do
        get 'revenues'
      end

      namespace :stripe do
        post 'webhooks/new'
      end

      resources :accounting_codes, only: [:index]

      resources :address_note_options, only: [:create, :update, :show, :destroy, :index]

      resources :addresses, only: [:create, :update, :destroy, :show, :index]

      get 'appointment_cutoffs/product/:product_id', to: 'appointment_cutoffs#product'
      resources :appointment_cutoffs, only: [:create, :show, :update]

      resources :appointment_notes, only: [:create, :update]

      get 'appointments/customer/:customer_id', to: 'appointments#customer'
      get 'appointments/product/:product_id', to: 'appointments#product'
      post 'appointments/update_sort_order'
      resources :appointments, only: [:create, :show, :update, :index]

      get 'assets/customer_item/:customer_item_id', to: 'assets#customer_item'
      resources :assets, only: [:create, :destroy]

      get 'availabilities/zip'
      get 'availabilities/host'

      post 'barcodes/change'
      resources :barcodes, only: [:create, :index]

      resources :billing_adjustments, only: :create

      get 'cards/customer/:customer_id', to: 'cards#customer'
      resources :cards, only: [:create, :show, :update, :index, :destroy]

      resources :charges, only: [:show]

      put 'companies/global_settings', to: 'companies#update_global_settings'
      get 'companies/global_settings', to: 'companies#get_global_settings'
      resources :companies, only: [:create, :show, :update, :index]

      resources :contact_details, only: [:create, :update, :destroy, :index]

      get 'customer_fees/appointment/:appointment_id', to: 'customer_fees#appointment'
      get 'customer_fees/customer/:customer_id', to: 'customer_fees#customer'

      get 'customer_items/user/:user_id', to: 'customer_items#user'
      get 'customer_items/product/:product_id', to: 'customer_items#product'
      get 'customer_items/customer/:customer_id', to: 'customer_items#customer'
      resources :customer_items, only: [:show, :update]

      get '/customers/product/:product_id/user/:user_id', to: 'customers#product_user'
      resources :customers, only: [:create, :show, :update, :index]

      resources :dashboards, only: :index

      resources :employee_invitations, only: [:create]

      get 'employees/drivers'
      post 'employees/new'
      resources :employees, only: [:index, :create, :update, :destroy]

      resources :faqs, only: [:create, :update, :destroy]

      resources :holidays, only: [:create, :show, :update, :destroy, :index]

      get 'inventories/customer_item/warehouse/:warehouse_id', to: 'inventories#customer_item'
      get 'inventories/container/warehouse/:warehouse_id', to: 'inventories#container'
      get 'inventories/route/:route_id', to: 'inventories#route'
      post 'inventories/move_to_staging'
      post 'inventories/load_cart'
      post 'inventories/move_to_storage'
      resources :inventories, only: [:create, :update, :destroy]

      get 'inventory_histories/customer/:customer_id', to: 'inventory_histories#customer'
      get 'inventory_histories/location/:location_id', to: 'inventory_histories#location'
      get 'inventory_histories/customer_item/:customer_item_id', to: 'inventory_histories#customer_item'
      get 'inventory_histories/item_type/:item_type_id', to: 'inventory_histories#item_type'
      get 'inventory_histories/appointment/:appointment_id', to: 'inventory_histories#appointment'

      resources :invoice_items, only: [:show, :index]

      post 'invoices/pay'
      get 'invoices/customer/:customer_id', to: "invoices#customer"
      resources :invoices, only: [:show, :index]

      get 'item_types/plan/:plan_id', to: 'item_types#plan'
      resources :item_types, only: [:create, :show, :update, :destroy, :index]

      get 'locations/warehouse/:warehouse_id', to: 'locations#warehouse'
      resources :locations, only: [:create, :update, :index, :destroy]

      get 'onboardings/available_item_types'
      post 'onboardings/new'
      post 'onboardings/register'
      post 'onboardings/register_demo_only'
      post 'onboardings/cancel'
      post 'onboardings/launch_demo'
      post 'onboardings/launch_product'
      get 'onboardings/request_invite'
      post 'onboardings/send_sms/mobile_app', to: 'onboardings#send_sms_to_mobile'
      get 'onboardings/setup/checklist_progress/company/:company_id', to: 'onboardings#checklist_progress'
      put 'onboardings/setup/checklist/:checklist_name/company/:company_id', to: 'onboardings#setup'

      get 'payloads/company/:company_id', to: 'payloads#company'
      get 'payloads/route/:route_id', to: 'payloads#route'
      post 'payloads/load_van'
      post 'payloads/unload_van'
      post 'payloads/load_van'
      post 'payloads/mass_assign_barcodes'
      resources :payloads, only: [:create, :show, :update, :destroy]

      get 'plans/product/:product_id', to: 'plans#product'
      put 'plans/mass_update'
      get 'plans/available_item_types'
      put 'plans/toggle_plans'
      resources :plans, only: [:create, :show, :update, :destroy, :index]

      get 'products/user/:user_id', to: 'products#user'
      resources :products, only: [:create, :show, :update, :destroy, :index]

      resources :refunds, only: [:create]

      get 'route_histories/company/:company_id', to: 'route_histories#company'
      get 'route_histories/route/:route_id', to: 'route_histories#route'

      get 'routes/company/:company_id', to: 'routes#company'
      get 'routes/warehouse/:warehouse_id', to: 'routes#warehouse'
      get 'routes/driver/:user_id', to: 'routes#driver'
      get 'routes/simulate'
      resources :routes, only: [:create, :show, :update, :destroy]

      resources :search_suggestions, only: :index

      resources :schedule_adjustments, only: [:create, :show, :update, :destroy, :index]

      resources :service_area_schedules, only: [:create, :show, :update, :destroy]

      resources :service_area_zips, only: [:create, :update, :destroy]

      get 'service_areas/product/:product_id', to: 'service_areas#product'
      resources :service_areas, only: [:create, :show, :update, :index, :destroy]

      get 'slots/month'
      get 'slots/date'
      post 'slots/reserve'

      get 'subscriptions/customer/:customer_id', to: 'subscriptions#customer'
      get 'subscriptions/plan/:plan_id', to: 'subscriptions#plan'
      get 'subscriptions/product/:product_id', to: 'subscriptions#product'
      resources :subscriptions, only: [:update, :show]

      get 'taxes/product/:product_id', to: 'taxes#product'
      resources :taxes, only: [:create, :index, :update, :destroy]

      post 'users/check_email'
      resources :users, only: [:show, :update]

      get 'vehicles/company/:company_id', to: 'vehicles#company'
      resources :vehicles, only: [:create, :update, :destroy]

      get 'warehouse_tasks/route/:route_id', to: 'warehouse_tasks#route'
      get 'warehouse_tasks/warehouse/:warehouse_id', to: 'warehouse_tasks#warehouse'
      resources :warehouse_tasks, only: [:create, :update]

      resources :warehouses, only: [:create, :update, :destroy, :index]
    end
  end
  mount Resque::Server => '/resque', :constraints => AdminRestriction
end
