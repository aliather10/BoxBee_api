require 'clockwork'
require './config/boot'
require './config/environment'

module Clockwork
  handler do |job|
    puts "Running #{job}"
  end

  every(10.minutes, 'AppointmentModificationCutoffJob', tz: 'UTC') { Resque.enqueue(AppointmentModificationCutoffJob) }
  every(1.hour, 'CreateFutureSlotsJob', tz: 'UTC') { Resque.enqueue(CreateFutureSlotsJob, 6.months, false) }
  every(24.hours, 'SyncStripeObjectsJob', tz: 'UTC') { Resque.enqueue(SyncStripeObjectsJob) }
  every(24.hours, 'SlackCriticalNotifierJob', tz: 'UTC') { Resque.enqueue(SlackCriticalNotifierJob) }
  every(24.hours, 'SlackFailedResqueNotifierJob', tz: 'UTC') { Resque.enqueue(SlackFailedResqueNotifierJob) }
  every(1.day, 'MonthlyBillerJob', tz: 'UTC', at: '06:00', if: lambda { |t| t.day == 1 }) { Resque.enqueue(MonthlyBillerJob) }
end
