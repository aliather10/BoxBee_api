class AddWarehouseOrders < ActiveRecord::Migration
  def change
    create_table :warehouse_orders do |t|
      t.references :location, index: true, foreign_key: true
      t.integer  :user_id
      t.integer  :inventory_type, null: false
      t.string   :inventory_name, null: false
      t.string   :sku,            null: false
      t.integer  :quantity,       null: false
      t.integer  :route_id
      t.integer  :event_id
      t.integer  :payload_id
      t.integer  :created_by,     null: false
      t.integer  :modified_by,    null: false
      t.string   :po_number
      t.integer  :order_type
      t.datetime :created_at,     null: false
      t.datetime :updated_at,     null: false
      t.integer  :status,         null: false
    end
  end
end
