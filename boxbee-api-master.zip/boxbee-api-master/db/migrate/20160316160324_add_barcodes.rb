class AddBarcodes < ActiveRecord::Migration
  def change
    create_table :barcodes do |t|
      t.references  :client,  index: true, foreign_key: true
      
      t.string   :code,       null: false
      t.integer  :created_by, null: false
      t.datetime :created_at, null: false
      t.datetime :updated_at, null: false
    end
  end
end
