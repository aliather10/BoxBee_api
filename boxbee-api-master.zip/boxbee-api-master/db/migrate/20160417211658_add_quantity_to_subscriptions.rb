class AddQuantityToSubscriptions < ActiveRecord::Migration
  def change
    add_column :subscriptions, :quantity, :integer
  end
end
