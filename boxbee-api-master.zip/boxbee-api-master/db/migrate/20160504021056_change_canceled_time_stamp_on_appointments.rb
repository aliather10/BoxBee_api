class ChangeCanceledTimeStampOnAppointments < ActiveRecord::Migration
  def change
    change_column :appointments, :canceled_timestamp, :datetime
  end
end
