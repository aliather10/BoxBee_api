class AddTransitEvents < ActiveRecord::Migration
  def change
    create_table :transit_events do |t|
      t.belongs_to :route, index: true
      t.belongs_to :booking, index: true

      t.integer  :warehouse_id
      t.string   :first_name,             null: false
      t.string   :last_name,              null: false
      t.string   :business_name
      t.string   :address1,               null: false
      t.string   :address2
      t.string   :address3
      t.string   :address4
      t.string   :city,                   null: false
      t.string   :state_name,             null: false
      t.string   :state_code
      t.string   :full_zip_code,          null: false
      t.string   :country_name,           null: false
      t.string   :country_code
      t.integer  :gps_latitude_ref
      t.decimal  :gps_latitude_point
      t.integer  :gps_longitude_ref
      t.decimal  :gps_longitude_point
      t.datetime :window_start_datetime,  null: false
      t.datetime :window_end_datetime,    null: false
      t.datetime :event_start_time
      t.datetime :event_end_time
      t.integer  :route_sort_order,       null: false
      t.integer  :status,                 null: false
      t.string   :preferred_phone,        null: false
      t.string   :preferred_email,        null: false
      t.string   :approved_signature_url
      t.integer  :created_by,             null: false
      t.integer  :modified_by,            null: false
      t.datetime :created_at,             null: false
      t.datetime :updated_at,             null: false
      t.datetime :canceled_timestamp
    end
  end
end
