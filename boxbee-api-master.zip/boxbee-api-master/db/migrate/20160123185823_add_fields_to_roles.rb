class AddFieldsToRoles < ActiveRecord::Migration
  def change
    add_column :roles, :description, :string
    add_column :roles, :internal, :boolean
  end
end
