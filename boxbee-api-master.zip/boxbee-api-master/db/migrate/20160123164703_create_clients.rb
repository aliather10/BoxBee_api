class CreateClients < ActiveRecord::Migration
  def change
    create_table :clients do |t|
      t.string :client_name, null: false
      t.string :url, null: false
      t.string :contact_name, null: false
      t.string :contact_number, null: false
      t.string :billing_acct_code, null: false
      t.string :client_code, null: false
      t.integer :created_by, null: false
      t.integer :modified_by, null: false

      t.timestamps null: false
    end
  end
end
