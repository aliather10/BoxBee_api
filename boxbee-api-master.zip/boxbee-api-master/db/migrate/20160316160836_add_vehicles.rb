class AddVehicles < ActiveRecord::Migration
  def change
    create_table :vehicles do |t|
      t.references :client, index: true, foreign_key: true
      t.string   :name,                             null: false
      t.integer  :year
      t.string   :make
      t.string   :model
      t.string   :vin_num
      t.string   :license_plate_num
      t.integer  :created_by,                       null: false
      t.integer  :modified_by,                      null: false
      t.datetime :created_at,                       null: false
      t.datetime :updated_at,                       null: false
      t.boolean  :active,            default: true
    end
  end
end
