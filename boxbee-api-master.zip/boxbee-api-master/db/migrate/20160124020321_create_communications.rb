class CreateCommunications < ActiveRecord::Migration
  def change
    create_table :communications do |t|
      t.references :user, index: true, foreign_key: true
      t.integer :mode_key, null: false
      t.string :mode_value, null: false
      t.boolean :active, null: false, default: true
      t.integer :created_by, null: false
      t.integer :modified_by, null: false
      t.timestamps null: false
    end
  end
end
