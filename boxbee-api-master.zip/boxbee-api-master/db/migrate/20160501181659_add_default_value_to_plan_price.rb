class AddDefaultValueToPlanPrice < ActiveRecord::Migration
  def change
    change_column :plans, :price_per_plan, :integer, default: 0
  end
end
