class AddUserBookingPriceHistories < ActiveRecord::Migration
  def change
    create_table :user_booking_price_histories do |t|
      t.belongs_to  :booking, index: true
      t.belongs_to  :product_user, index: true
      
      t.integer  :empty_delivery_price,  default: 0
      t.integer  :packed_pickup_price,   default: 0
      t.integer  :packed_delivery_price, default: 0
      t.integer  :empty_pickup_price,    default: 0
      t.integer  :created_by,                        null: false
      t.integer  :modified_by,                       null: false
      t.datetime :created_at,                        null: false
      t.datetime :updated_at,                        null: false
    end
  end
end
