class AddImageToItemType < ActiveRecord::Migration
  def change
    add_column :item_types, :image, :string
  end
end
