class RemoveCodeFromWarehouse < ActiveRecord::Migration
  def change
    remove_column :warehouses, :code, :string
  end
end
