class AddProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.references :client, index: true, foreign_key: true
      t.string   :name,                                        null: false
      t.string   :description
      t.integer  :company_id,                                   null: false
      t.boolean  :active,                      default: false, null: false
      t.string   :logo_image_url,                              null: false
      t.string   :support_phone,                               null: false
      t.string   :support_email,                               null: false
      t.integer  :created_by,                                  null: false
      t.integer  :modified_by,                                 null: false
      t.string   :marketing_url
      t.string   :customer_portal_url
      t.string   :default_marketing_url
      t.string   :default_customer_portal_url
      t.string   :meta_tags
      t.string   :theme,                                       null: false
      t.string   :hero_text,                                   null: false
      t.text     :description_text,                            null: false
      t.string   :what_we_store,                               null: false
      t.string   :how_it_works1,                               null: false
      t.string   :how_it_works2,                               null: false
      t.string   :how_it_works3,                               null: false
      t.string   :how_it_works4,                               null: false
      t.string   :our_plans,                                   null: false
      t.string   :areas_of_operation,                          null: false
      t.string   :closing_cta,                                 null: false
      t.string   :about_us_title,                              null: false
      t.text     :about_us_body,                               null: false
      t.string   :about_us_image,                              null: false
      t.string   :terms_title,                                 null: false
      t.text     :terms_body,                                  null: false
      t.string   :storage_rules_title,                         null: false
      t.text     :storage_rules_body,                          null: false
      t.string   :faq_title,                                   null: false
      t.string   :contact_us_title,                            null: false
      t.string   :contact_us_image,                            null: false
      t.string   :name_of_business,                            null: false
      t.string   :address1,                                    null: false
      t.string   :address2
      t.string   :city,                                        null: false
      t.string   :state,                                       null: false
      t.string   :zip,                                         null: false
      t.string   :twitter_url
      t.string   :facebook_url
      t.string   :instagram_url
      t.string   :pinterest_url
      t.string   :yelp_url

    t.timestamps null: false
  end

  end
end
