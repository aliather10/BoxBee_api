class AddProductOperatingAreas < ActiveRecord::Migration
  def change
    create_table :product_operating_areas do |t|
      t.belongs_to  :product, index: true
      t.belongs_to  :operating_area, index: true
      t.integer  :created_by,        null: false
      t.integer  :modified_by,       null: false
      t.datetime :created_at,        null: false
      t.datetime :updated_at,        null: false
    end
  end
end
