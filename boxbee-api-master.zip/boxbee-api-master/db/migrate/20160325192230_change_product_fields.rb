class ChangeProductFields < ActiveRecord::Migration
  def change
    remove_column :products, :service_areas
    add_column :products, :list_of_service_areas, :string, null: false

  end
end
