class MiscRenaming < ActiveRecord::Migration
  def change
    # remove_column :appointment_cutoffs, :days_prior_to_booking, :integer
    # add_column :appointment_cutoffs, :days_prior_to_appointment, :integer, null: false
    remove_column :companies, :client_portal_url, :string
    remove_column :companies, :default_client_portal_url, :string
    add_column :companies, :custom_admin_url, :string

    drop_table :product_service_areas
    remove_column :products, :marketing_url
    remove_column :products, :default_marketing_url
    remove_column :products, :how_it_works4
    remove_column :products, :areas_of_operation
    add_column :products, :service_areas, :string
    remove_column :products, :storage_rules_title
    remove_column :products, :storage_rules_body
    remove_column :products, :about_us_image
    remove_column :products, :contact_us_title
    remove_column :products, :contact_us_image

    remove_column :products, :name_of_business
    remove_column :products, :address1
    remove_column :products, :address2
    remove_column :products, :city
    remove_column :products, :state
    remove_column :products, :zip

    remove_column :schedule_adjustments, :new_max_bookings_per_slot
    add_column :schedule_adjustments, :new_max_appointments_per_slot, :integer

    remove_column :subscriptions, :ceiling_subscription_quantity
    remove_column :subscriptions, :stripe_subcription_id
  end
end
