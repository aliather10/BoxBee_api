class AddFieldsToCompanyDetails < ActiveRecord::Migration
  def change
    add_column :company_details, :currently_offer_storage, :boolean
    add_column :company_details, :currently_offer_pickup_delivery, :boolean
  end
end
