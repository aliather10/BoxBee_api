class AddSlots < ActiveRecord::Migration
  def change
    create_table :slots do |t|
      t.references :operating_area_schedule, index: true, foreign_key: true
      
      t.datetime :start_datetime
      t.datetime :end_datetime
      t.integer  :created_by,                 null: false
      t.integer  :modified_by,                null: false
      t.datetime :created_at,                 null: false
      t.datetime :updated_at,                 null: false
    end
  end
end
