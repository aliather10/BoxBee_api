class AddCountryNameToCompanyDetailsAndMisc < ActiveRecord::Migration
  def change
    add_column :company_details, :country_name, :string
  end
end
