class ModifyAppointmentCutoffs < ActiveRecord::Migration
  def change
    remove_column :appointment_cutoffs, :days_prior_to_appointment, :integer
    remove_column :appointment_cutoffs, :exact_time, :integer
    add_column :appointment_cutoffs, :lead_time, :integer
    
  end
end
