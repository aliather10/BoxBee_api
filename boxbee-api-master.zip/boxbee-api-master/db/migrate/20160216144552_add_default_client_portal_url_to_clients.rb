class AddDefaultClientPortalUrlToClients < ActiveRecord::Migration
  def change
    add_column :clients, :default_client_portal_url, :string
  end
end
