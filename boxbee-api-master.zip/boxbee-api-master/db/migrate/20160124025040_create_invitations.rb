class CreateInvitations < ActiveRecord::Migration
  def change
    create_table :invitations do |t|
      t.references :client, index: true, foreign_key: true
      t.string :email, null: false
      t.text :roles, array: true, null: false
      t.integer :created_by, null: false
      t.integer :modified_by, null:false

      t.timestamps null: false
    end
  end
end
