class AddCustomerItemToAssets < ActiveRecord::Migration
  def change
    add_reference :assets, :customer_item, index: true
    remove_reference :plans, :customer
  end
end
