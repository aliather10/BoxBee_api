class MoreMassNameChanges2 < ActiveRecord::Migration
  def change
    remove_reference :address_notes, :note_template
    add_reference :address_notes, :address_note_option, index: true

    remove_column :addresses, :alt_name
    add_column :addresses, :display_name, :string
    remove_column :addresses, :full_zip_code
    add_column :addresses, :zip_code, :string

    remove_column  :warehouses, :gps_latitude_ref
    remove_column  :warehouses, :gps_latitude_point
    remove_column  :warehouses, :gps_longitude_ref
    remove_column  :warehouses, :gps_longitude_point
    remove_column   :warehouses, :address1
    remove_column   :warehouses, :address2
    remove_column   :warehouses, :address3
    remove_column   :warehouses, :address4
    remove_column   :warehouses, :city
    remove_column   :warehouses, :state_name
    remove_column   :warehouses, :state_code
    remove_column   :warehouses, :full_zip_code
    remove_column   :warehouses, :country_name
    remove_column   :warehouses, :country_code
    add_column :warehouses, :address_id, :integer

    remove_reference :appointments, :customer_item
    remove_reference :appointments, :product
    add_reference :appointments, :customer, index: true

    remove_column :item_types, :booking_limit_qty
    add_column :item_types, :appointment_max_qty, :integer

    remove_column :companies, :url, :string
    add_column :companies, :contact_email, :string

    remove_column :customer_items, :tag_num
    add_column :customer_items, :barcode, :string

    remove_column :payloads, :active_plan_name
    remove_column :payloads, :payload_name
    remove_column :payloads, :payload_status
    remove_column :payloads, :payload_value
    add_column :payloads, :name, :string, null: false
    add_column :payloads, :status, :integer, null: false
    add_column :payloads, :sku, :string

    remove_column :service_area_schedules, :allowed_break_hours
    remove_column :service_area_schedules, :max_break_count

    remove_column :customers, :primary_communication_id
    remove_column :customers, :secondary_communication_id

    remove_column :warehouse_tasks, :user_id
    add_column :warehouse_tasks, :customer_id, :integer
  end
end
