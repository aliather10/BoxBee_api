class MiscChanges < ActiveRecord::Migration
  def change
    remove_column :inventory_histories, :inventory_type
    add_column :inventory_histories, :inventory_type, :integer, null: false

    remove_column :warehouse_tasks, :event_id

    remove_column :payloads, :warehouse_id
    add_column :payloads, :warehouse_id, :integer
  end
end
