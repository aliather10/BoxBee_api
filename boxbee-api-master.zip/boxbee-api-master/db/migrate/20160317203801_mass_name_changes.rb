class MassNameChanges < ActiveRecord::Migration
  def change
    rename_table :active_form_factors, :customer_item
    rename_table :form_factors, :item_type
    rename_table :active_form_factor_histories, :customer_item_histories
    rename_table :active_plans, :subscriptions
    rename_table :address_note_templates, :address_notes
    rename_table :adjustments, :schedule_adjustments
    rename_table :bookings, :appointments
    rename_table :booking_action_details, :appointment_details
    rename_table :booking_cutoffs, :appointment_cutoffs
    rename_table :booking_notes, :appointment_notes
    rename_table :clients, :companies
    rename_table :communications, :contact_details
    rename_table :holiday_schedules, :holidays
    rename_table :invitations, :employee_invitations
    rename_table :note_templates, :address_note_options
    rename_table :operating_areas, :service_areas
    rename_table :operating_area_schedules, :service_area_schedules
    rename_table :route_transit_histories, :route_histories
    rename_table :temp_reservations, :appoitment_holds
    rename_table :transit_event_notes, :route_notes
    rename_table :transit_event_payloads, :payloads
    rename_table :product_content_faqs, :faqs
    rename_table :product_users, :customers
    rename_table :user_booking_price_histories, :customer_fees
    rename_table :warehouse_orders, :warehouse_tasks

    remove_reference :route_notes, :transit_event
    remove_reference :payloads, :transit_event
    add_reference :route_notes, :appointment, index: true, foreign_key: true
    add_reference :payloads, :appointment, index: true, foreign_key: true
    drop_table :transit_events
    drop_table :plan_assets
    remove_reference :plan_form_factor_assets, :plan_form_factor
    drop_table :plan_form_factors
    drop_table :plan_form_factor_assets
    drop_table :operating_area_collections
    drop_table :product_operating_areas

    add_column :plans, :image, :string
    add_column :appointments, :event_start_time, :datetime
    add_column :appointments, :event_end_time, :datetime
    add_column :appointments, :route_sort_order, :integer
    add_column :appointments, :approved_signature_url, :string
    remove_column  :appointments, :ship_to_first_name
    remove_column  :appointments, :ship_to_last_name
    remove_column  :appointments, :ship_to_business_name
    remove_column  :appointments, :ship_to_address1
    remove_column  :appointments, :ship_to_address2
    remove_column  :appointments, :ship_to_address3
    remove_column  :appointments, :ship_to_address4
    remove_column  :appointments, :ship_to_city
    remove_column  :appointments, :ship_to_state_name
    remove_column  :appointments, :ship_to_state_code
    remove_column  :appointments, :ship_to_zip_code
    remove_column  :appointments, :ship_to_country_name
    remove_column  :appointments, :ship_to_country_code
    remove_column  :appointments, :gps_latitude_ref
    remove_column  :appointments, :gps_latitude_point
    remove_column  :appointments, :gps_longitude_ref
    remove_column  :appointments, :gps_longitude_point
    remove_reference :appointments, :product
    add_reference :appointments, :product, index: true
    add_reference :appointments, :route, index: true

    create_table :product_service_areas do |t|
      t.belongs_to :product, index: true
      t.belongs_to :service_area, index: true
    end

    create_table :service_area_zips do |t|
      t.references :service_area, index: true, foreign_key: true
      t.integer  :zip,                  null: false
      t.boolean  :active,               default: true
      t.integer  :created_by,           null: false
      t.integer  :modified_by,          null: false
      t.datetime :created_at,           null: false
      t.datetime :updated_at,           null: false
    end
  end
end
