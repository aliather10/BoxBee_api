class AddClientPortalUrlToClients < ActiveRecord::Migration
  def change
    add_column :clients, :client_portal_url, :string
  end
end
