class AddActiveToItemTypes < ActiveRecord::Migration
  def change
    add_column :item_types, :active, :boolean, default: false
  end
end
