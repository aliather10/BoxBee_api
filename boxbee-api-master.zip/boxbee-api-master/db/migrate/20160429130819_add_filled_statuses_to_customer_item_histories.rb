class AddFilledStatusesToCustomerItemHistories < ActiveRecord::Migration
  def change
    add_column :customer_item_histories, :current_filled_status, :string
    add_column :customer_item_histories, :previous_filled_status, :string
  end
end
