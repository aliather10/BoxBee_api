class CreateAddresses < ActiveRecord::Migration
  def change
    create_table :addresses do |t|
      t.references :user, index: true, foreign_key: true
      t.string :alt_name
      t.string :alt_business_name
      t.integer :gps_latitude_ref
      t.decimal :gps_latitude_point
      t.integer :gps_longitude_ref
      t.decimal :gps_longitude_point
      t.string :address1, null: false
      t.string :address2
      t.string :address3
      t.string :address4
      t.string :city, null: false
      t.string :state_name, null: false
      t.string :state_code
      t.string :full_zip_code, null: false
      t.string :country_name, null: false
      t.string :country_code
      t.boolean :verfied, null: false, default: false
      t.boolean :billing_address, null: false, default: false
      t.integer :created_by, null: false
      t.integer :modified_by, null: false

      t.timestamps null: false
    end
  end
end
