class AddStorageTermsToProducts < ActiveRecord::Migration
  def change
    add_column :products, :storage_terms, :text
  end
end
