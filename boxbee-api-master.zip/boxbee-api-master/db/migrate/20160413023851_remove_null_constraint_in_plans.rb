class RemoveNullConstraintInPlans < ActiveRecord::Migration
  def change
    change_column :plans, :description, :string, null: true
  end
end
