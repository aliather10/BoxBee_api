class AddFormFactors < ActiveRecord::Migration
  def change
    create_table :form_factors do |t|
      t.references :client, index: true, foreign_key: true
      
      t.string   :name,                                null: false
      t.integer  :wms_on_hand_qty,         default: 0, null: false
      t.integer  :min_threshold_qty,       default: 0, null: false
      t.integer  :booking_limit_qty,       default: 0, null: false
      t.integer  :created_by,                          null: false
      t.integer  :modified_by,                         null: false
      t.datetime :created_at,                          null: false
      t.datetime :updated_at,                          null: false
      t.boolean  :requires_empty_pickup,               null: false
      t.boolean  :requires_empty_delivery,             null: false
    end
  end
end
