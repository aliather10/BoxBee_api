class CreateUsers < ActiveRecord::Migration
  def change
    create_table :users do |t|
      t.references :client, index: true, foreign_key: true
      t.integer :prefix
      t.string :first_name, null: false
      t.string :middle_name
      t.string :last_name, null: false
      t.string :suffix
      t.date :birth_date
      t.integer :gender
      t.integer :created_by, null: false
      t.integer :modified_by, null: false

      t.timestamps null: false
    end
  end
end
