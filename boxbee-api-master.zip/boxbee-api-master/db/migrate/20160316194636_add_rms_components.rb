class AddRmsComponents < ActiveRecord::Migration
  def change
    add_column :clients, :stripe_account_id, :string, null: false
    add_column :products, :empty_delivery_price, :integer, default: 0, null: false
    add_column :products, :packed_pickup_price, :integer, default: 0, null: false
    add_column :products, :packed_delivery_price, :integer, default: 0, null: false
    add_column :products, :empty_pickup_price, :integer, default: 0, null: false
    add_column :products, :currency, :integer, null: false
    add_column :product_users, :stripe_account_id, :string, null: false
    add_column :active_plans, :price_per_plan, :string, null: false
    add_column :active_plans, :stripe_subcription_id, :string, null: false
    add_column :active_plans, :ceiling_subscription_quantity, :integer, null: false
    add_column :plans, :price_per_plan, :string, null: false
  end
end
