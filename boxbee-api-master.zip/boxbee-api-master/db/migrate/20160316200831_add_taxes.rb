class AddTaxes < ActiveRecord::Migration
  def change
    create_table :taxes do |t|
      t.references  :product, index: true, foreign_key: true

      t.string   :zip,                            null: false
      t.decimal  :tax_percent,      default: 0.0, null: false
      t.string   :accounting_codes, default: [],               array: true
      t.integer  :created_by,                     null: false
      t.integer  :modified_by,                    null: false
      t.datetime :created_at,                     null: false
      t.datetime :updated_at,                     null: false
    end
  end
end
