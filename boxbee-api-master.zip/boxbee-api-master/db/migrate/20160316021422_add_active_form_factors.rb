class AddActiveFormFactors < ActiveRecord::Migration
  def change
    create_table :active_form_factors do |t|
      t.belongs_to  :active_plan, index: true
      t.belongs_to  :form_factor, index: true
      t.integer  :form_factor_combo_id
      t.string   :tag_num
      t.string   :name
      t.string   :description
      t.integer  :status,               null: false
      t.decimal  :length
      t.decimal  :width
      t.decimal  :height
      t.decimal  :weight
      t.string   :wh_code
      t.integer  :created_by,           null: false
      t.integer  :modified_by,          null: false
      t.datetime :created_at,           null: false
      t.datetime :updated_at,           null: false
    end
    create_table :assets do |t|
      t.references :active_form_factor, index: true, foreign_key: true
      t.integer  :asset_type,            null: false
      t.string   :asset_value,           null: false
      t.integer  :sort_order,            null: false
      t.integer  :created_by,            null: false
      t.integer  :modified_by,           null: false
      t.datetime :created_at,            null: false
      t.datetime :updated_at,            null: false
    end
  end
end
