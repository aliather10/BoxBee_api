class AddActiveFormFactorHistories < ActiveRecord::Migration
  def change
    create_table :active_form_factor_histories do |t|
      t.references :active_form_factor, index: true, foreign_key: true
      t.string   :previous_status
      t.string   :current_status,        null: false
      t.integer  :booking_created_in_id
      t.integer  :created_by,            null: false
      t.integer  :modified_by,           null: false
      t.datetime :created_at,            null: false
      t.datetime :updated_at,            null: false
    end
  end
end
