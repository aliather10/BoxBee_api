class AddRequestedInviteToCompanyDetails < ActiveRecord::Migration
  def change
    add_column :company_details, :requested_invite, :boolean, default: false
  end
end
