class MoreMassNameChanges < ActiveRecord::Migration
  def change
    rename_table :appoitment_holds, :appointment_holds
    rename_table :item_type, :item_types
    rename_table :customer_item, :customer_items

    remove_column :customer_item_histories, :booking_created_in_id, :integer
    add_column :customer_item_histories, :appointment_id, :integer

    remove_column :customer_items, :length, :decimal
    remove_column :customer_items, :width, :decimal
    remove_column :customer_items, :height, :decimal
    remove_column :customer_items, :weight, :decimal
    remove_column :plans, :length, :decimal
    remove_column :plans, :width, :decimal
    remove_column :plans, :height, :decimal
    remove_column :plans, :weight, :decimal
    add_column :item_types, :length, :decimal
    add_column :item_types, :width, :decimal
    add_column :item_types, :height, :decimal
    add_column :item_types, :weight, :decimal

    remove_reference :address_note_options, :client
    add_reference :address_note_options, :company, index: true, foreign_key: true

    remove_reference :address_notes, :note_template
    add_reference :address_notes, :note_template, index: true
    remove_column :address_notes, :custom_note
    add_column :address_notes, :note, :string

    remove_reference :appointment_details, :booking
    remove_reference :appointment_details, :active_form_factor
    add_reference :appointment_details, :appointment, index: true
    add_reference :appointment_details, :customer_item, index: true

    remove_reference :appointment_notes, :booking
    add_reference :appointment_notes, :appointment, index: true

    remove_reference :assets, :active_form_factor
    add_reference :appointments, :customer_item, index: true

    remove_reference :barcodes, :client
    add_reference :barcodes, :company, index: true

    remove_reference :customer_fees, :booking
    add_reference :customer_fees, :appointment, index: true
    remove_reference :customer_fees, :product_user
    add_reference :customer_fees, :customer, index: true

    remove_reference :customer_items, :active_plan
    add_reference :customer_items, :subscription, index: true
    remove_reference :customer_items, :form_factor
    add_reference :customer_items, :item_type, index: true
    remove_column :customer_items, :form_factor_combo_id
    remove_column :customer_items, :wh_code

    remove_reference :customer_item_histories, :active_form_factor
    add_reference :customer_item_histories, :customer_item, index: true

    remove_column :customers, :standing_reason, :string

    remove_reference :employee_invitations, :client
    add_reference :employee_invitations, :company, index: true

    remove_column :failed_billings, :booking_id
    add_column :failed_billings, :appointment_id, :integer
    remove_column :failed_billings, :company_id
    add_column :failed_billings, :company_id, :integer

    remove_reference :holidays, :client
    add_reference :holidays, :company, index: true

    remove_reference :item_types, :client
    add_reference :item_types, :company, index: true
    remove_column :item_types, :wms_on_hand_qty, :integer
    remove_column :item_types, :min_threshold_qty, :integer

    remove_reference :payloads, :booking_action_detail
    add_reference :payloads, :appointment_detail, index: true
    remove_column :payloads, :staging_location_num, :string
    add_column :payloads, :staging_location_id, :integer
    remove_column :payloads, :group_name, :string

    remove_column :plans, :price_per_plan, :string
    add_column :plans, :price_per_plan, :integer

    remove_reference :products, :client
    remove_column :products, :company_id
    add_reference :products, :company, index: true

    # remove_reference :reports, :client
    # add_reference :reports, :company, index: true

    remove_reference :routes, :client
    add_reference :routes, :company, index: true

    remove_reference :schedule_adjustments, :operating_area_schedule
    add_reference :schedule_adjustments, :service_area_schedule, index: true

    remove_reference :service_area_schedules, :operating_area
    add_reference :service_area_schedules, :service_area, index: true

    remove_reference :service_areas, :client
    add_reference :service_areas, :company, index: true

    remove_reference :slots, :operating_area_schedule
    add_reference :slots, :service_area_schedule, index: true

    remove_reference :users, :client
    add_reference :users, :company, index: true
    remove_column :users, :prefix, :integer
    remove_column :users, :middle_name, :string
    remove_column :users, :suffix, :string
    remove_column :users, :birth_date, :date
    remove_column :users, :gender, :integer

    remove_reference :vehicles, :client
    add_reference :vehicles, :company, index: true

    remove_reference :warehouses, :client
    add_reference :warehouses, :company, index: true
  end
end
