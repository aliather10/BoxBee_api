class Onboarding < ActiveRecord::Migration
  def change
    add_column :company_details, :accepted_terms, :boolean
    add_column :company_details, :accepted_terms_ip, :string
    remove_column :products, :active, :boolean
    add_column :products, :status, :integer
  end
end
