class UpdateBookingsToAppointments < ActiveRecord::Migration
  def change
    remove_column :service_area_schedules, :max_bookings_per_slot
    add_column :service_area_schedules, :max_appointments_per_slot, :integer
    remove_column :customers, :last_booking_address_id
    add_column :customers, :last_appointment_address_id, :integer
  end
end
