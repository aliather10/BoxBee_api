class RemoveNullReqmtOnProducts < ActiveRecord::Migration
  def change
    change_column :products, :logo_image_url, :string
  end
end
