class CreateNoteTemplates < ActiveRecord::Migration
  def change
    create_table :note_templates do |t|
      t.references :client, index: true, foreign_key: true
      t.string :type, null: false
      t.boolean :active, null: false, default: true
      t.integer :created_by, null: false
      t.integer :modified_by, null: false
      t.timestamps null: false
    end
  end
end
