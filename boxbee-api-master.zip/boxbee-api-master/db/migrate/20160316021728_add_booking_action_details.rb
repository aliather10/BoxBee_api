class AddBookingActionDetails < ActiveRecord::Migration
  def change
    create_table :booking_action_details do |t|
      t.belongs_to  :booking, index: true
      t.belongs_to  :active_form_factor, index: true
      t.integer  :transit_type,          null: false
      t.integer  :request_type,          null: false
      t.integer  :created_by,            null: false
      t.integer  :modified_by,           null: false
      t.datetime :created_at,            null: false
      t.datetime :updated_at,            null: false
    end
  end
end
