class AddInternalToAppointmentNotes < ActiveRecord::Migration
  def change
    drop_table :route_notes
    add_column :appointment_notes, :internal, :boolean, default: false
  end
end
