class AddOperatingAreaCollections < ActiveRecord::Migration
  def change
    create_table :operating_area_collections do |t|
      t.references :operating_area, index: true, foreign_key: true
      t.integer  :operating_area_key,   null: false
      t.integer  :operating_area_value, null: false
      t.boolean  :active,               null: false
      t.integer  :created_by,           null: false
      t.integer  :modified_by,          null: false
      t.datetime :created_at,           null: false
      t.datetime :updated_at,           null: false
    end
  end
end
