class ChangeSubscriptionRefs < ActiveRecord::Migration
  def change
    remove_reference :subscriptions, :user
    add_reference :subscriptions, :customer, index: true
  end
end
