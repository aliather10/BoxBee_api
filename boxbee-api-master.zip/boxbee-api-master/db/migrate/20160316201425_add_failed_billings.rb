class AddFailedBillings < ActiveRecord::Migration
  def change
    create_table :failed_billings do |t|
      t.string   :date
      t.integer  :user_id
      t.integer  :booking_id
      t.integer  :company_id
      t.integer  :product_id
      t.string   :contextual_error_message
      t.datetime :created_at,               null: false
      t.datetime :updated_at,               null: false
    end
  end
end
