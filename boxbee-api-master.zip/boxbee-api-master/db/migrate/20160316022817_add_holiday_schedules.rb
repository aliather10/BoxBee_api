class AddHolidaySchedules < ActiveRecord::Migration
  def change
    create_table :holiday_schedules do |t|
      t.references :client, index: true, foreign_key: true
      
      t.string   :name,        null: false
      t.date     :date,        null: false
      t.date     :end_date
      t.integer  :created_by,  null: false
      t.integer  :modified_by, null: false
      t.datetime :created_at,  null: false
      t.datetime :updated_at,  null: false
    end
  end
end
