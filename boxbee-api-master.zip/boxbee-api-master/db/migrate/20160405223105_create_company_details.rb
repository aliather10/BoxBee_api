class CreateCompanyDetails < ActiveRecord::Migration
  def change
    create_table :company_details do |t|
      t.references :company, index: true, foreign_key: true
      t.string :ssn
      t.string :dob
      t.string :government_id
      t.integer :entity_type
      t.string :entity_name
      t.string :address1
      t.string :address2
      t.string :address3
      t.string :city
      t.string :state_name
      t.integer :zip_code
      t.integer :currency
      t.string :ein
      t.string :bank_routing_no
      t.string :bank_account_no 
      t.timestamps null: false
    end
  end
end
