class AddReferencesToAddressNoteTemplates < ActiveRecord::Migration
  def change
    add_belongs_to :address_note_templates, :address, index: true
    add_belongs_to :address_note_templates, :note_template, index: true
  end
end
