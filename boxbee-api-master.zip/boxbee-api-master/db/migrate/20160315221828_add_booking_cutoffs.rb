class AddBookingCutoffs < ActiveRecord::Migration
  def change
    create_table :booking_cutoffs do |t|
      t.references :product, index: true, foreign_key: true

      t.integer  :days_prior_to_appointment, default: 1,    null: false
      t.integer  :exact_time,                           null: false
      t.boolean  :active,                default: true, null: false
      t.integer  :created_by,                           null: false
      t.integer  :modified_by,                          null: false
      t.datetime :created_at,                           null: false
      t.datetime :updated_at,                           null: false
      t.integer  :cutoff_type
    end
  end
end
