class CreateProductsServiceAreas < ActiveRecord::Migration
  def change
    create_table :products_service_areas do |t|
      t.belongs_to :product, index: true
      t.belongs_to :service_area, index: true
    end
  end
end
