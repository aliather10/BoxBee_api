class ChangeZipInServiceAreaZips < ActiveRecord::Migration
  def change
    change_column :service_area_zips, :zip, :string
  end
end
