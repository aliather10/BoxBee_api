class AddPolymorphicToAddresses < ActiveRecord::Migration
  def change
    #Create reference column and index for polymorphism
    add_reference :addresses, :addressable, polymorphic: true, index: true

    #Migrate data as well
    warehouse_class_name = Warehouse.first.class.name
    Warehouse.all.each do |warehouse|
      address_id = warehouse.address_id
      address = Address.find(address_id)
      address.addressable_type = warehouse_class_name
      address.addressable_id = warehouse.id
      address.save!
    end

    user_class_name = User.first.class.name
    Address.select(&:user_id).each do |address|
      address.addressable_type = user_class_name
      address.addressable_id = address.user_id
      address.save!
    end

    remove_reference :addresses, :user, index: true, foreign_key: true
  end
end
