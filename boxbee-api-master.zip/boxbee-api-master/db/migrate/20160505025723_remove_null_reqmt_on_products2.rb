class RemoveNullReqmtOnProducts2 < ActiveRecord::Migration
  def change
    change_column :products, :logo_image_url, :string, null: true
  end
end
