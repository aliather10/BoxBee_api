class RemoveUnneededFields < ActiveRecord::Migration
  def change
    remove_column :clients, :client_code
    remove_column :clients, :billing_acct_code
  end
end
