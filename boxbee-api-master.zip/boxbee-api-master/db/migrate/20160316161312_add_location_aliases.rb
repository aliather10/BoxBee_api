class AddLocationAliases < ActiveRecord::Migration
  def change
    create_table :location_aliases do |t|
      t.references :warehouse,  index: true, foreign_key: true

      t.string   :location_type, null: false
      t.string   :area,          null: false
      t.string   :name,          null: false
      t.datetime :created_at,    null: false
      t.datetime :updated_at,    null: false
    end
  end
end
