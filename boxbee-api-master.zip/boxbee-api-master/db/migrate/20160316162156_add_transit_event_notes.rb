class AddTransitEventNotes < ActiveRecord::Migration
  def change
    create_table :transit_event_notes do |t|
      t.references :transit_event, index: true, foreign_key: true
      
      t.string   :note,             null: false
      t.boolean  :internal,         null: false
      t.integer  :created_by,       null: false
      t.integer  :modified_by,      null: false
      t.datetime :created_at,       null: false
      t.datetime :updated_at,       null: false
    end
  end
end
