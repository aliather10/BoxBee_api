class AddReports < ActiveRecord::Migration
  def change
    create_table :reports do |t|
      t.integer  :company_id,             null: false
      t.integer  :report_type,           null: false
      t.string   :name
      t.datetime :created_at,            null: false
      t.datetime :updated_at,            null: false
      t.string   :csv_file_file_name
      t.string   :csv_file_content_type
      t.integer  :csv_file_file_size
      t.datetime :csv_file_updated_at
      t.integer  :created_by
      t.integer  :modified_by
    end
  end
end
