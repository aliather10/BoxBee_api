class RemoveNullConstraintsInProduct < ActiveRecord::Migration
  def change
    change_column :products, :theme, :string, null: true
    change_column :products, :hero_text, :string, null: true
    change_column :products, :description_text, :text, null: true
    change_column :products, :what_we_store, :string, null: true
    change_column :products, :how_it_works1, :string, null: true
    change_column :products, :how_it_works2, :string, null: true
    change_column :products, :how_it_works3, :string, null: true
    change_column :products, :our_plans, :string, null: true
    change_column :products, :closing_cta, :string, null: true
    change_column :products, :about_us_title, :string, null: true
    change_column :products, :about_us_body, :text, null: true
    change_column :products, :terms_title, :string, null: true
    change_column :products, :terms_body, :text, null: true
    change_column :products, :faq_title, :string, null: true
  end
end
