class AddLocations < ActiveRecord::Migration
  def change
    create_table :locations do |t|
      t.references :warehouse, index: true, foreign_key: true

      t.string   :area,          null: false
      t.string   :aisle,         null: false
      t.string   :row,           null: false
      t.string   :section,       null: false
      t.string   :level,         null: false
      t.integer  :created_by,    null: false
      t.integer  :modified_by,   null: false
      t.datetime :created_at,    null: false
      t.datetime :updated_at,    null: false
      t.integer  :location_type, null: false
    end
  end
end
