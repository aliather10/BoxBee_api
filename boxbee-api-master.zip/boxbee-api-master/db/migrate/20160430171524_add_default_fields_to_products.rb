class AddDefaultFieldsToProducts < ActiveRecord::Migration
  def change
    add_column :products, :default_slot_duration, :integer
    add_column :products, :default_max_appointments_per_slot, :integer
    add_column :products, :default_daily_start, :integer
    add_column :products, :default_daily_end, :integer
    add_column :products, :default_days_of_week, :string, array: true, default: []
  end
end
