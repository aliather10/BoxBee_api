class AddAdjustments < ActiveRecord::Migration
  def change
    create_table :adjustments do |t|
      t.references :operating_area_schedule, index: true, foreign_key: true
      t.string   :name,                                       null: false
      t.date     :date,                                       null: false
      t.date     :end_date
      t.integer  :new_duration_value_mins
      t.integer  :new_max_bookings_per_slot,  default: 1,     null: false
      t.boolean  :active,                     default: false
      t.integer  :created_by,                                 null: false
      t.integer  :modified_by,                                null: false
      t.datetime :created_at,                                 null: false
      t.datetime :updated_at,                                 null: false
    end
  end
end
