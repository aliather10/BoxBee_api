class AddBookings < ActiveRecord::Migration
  def change
    create_table :bookings do |t|
      t.references :product, index: true, foreign_key: true
      
      t.integer  :user_id,               null: false
      t.string   :ship_to_first_name,    null: false
      t.string   :ship_to_last_name,     null: false
      t.string   :ship_to_business_name
      t.string   :ship_to_address1,      null: false
      t.string   :ship_to_address2
      t.string   :ship_to_address3
      t.string   :ship_to_address4
      t.string   :ship_to_city,          null: false
      t.string   :ship_to_state_name,    null: false
      t.string   :ship_to_state_code
      t.string   :ship_to_zip_code,      null: false
      t.string   :ship_to_country_name,  null: false
      t.string   :ship_to_country_code
      t.integer  :gps_latitude_ref
      t.decimal  :gps_latitude_point
      t.integer  :gps_longitude_ref
      t.decimal  :gps_longitude_point
      t.string   :preferred_phone,       null: false
      t.string   :preferred_email,       null: false
      t.integer  :status,                null: false
      t.datetime :window_start_datetime, null: false
      t.datetime :window_end_datetime,   null: false
      t.date     :canceled_timestamp
      t.integer  :created_by,            null: false
      t.integer  :modified_by,           null: false
      t.datetime :created_at,            null: false
      t.datetime :updated_at,            null: false
      t.integer  :address_id
    end
  end
end
