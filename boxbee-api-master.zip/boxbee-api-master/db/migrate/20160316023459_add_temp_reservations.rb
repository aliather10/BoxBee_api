class AddTempReservations < ActiveRecord::Migration
  def change
    create_table :temp_reservations do |t|
      t.references :slot, index: true, foreign_key: true
      t.string   :email
      t.datetime :created_at, null: false
      t.datetime :updated_at, null: false
    end
  end
end
