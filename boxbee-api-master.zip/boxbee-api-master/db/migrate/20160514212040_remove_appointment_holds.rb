class RemoveAppointmentHolds < ActiveRecord::Migration
  def change
    remove_reference :appointment_holds, :slot
    drop_table :appointment_holds
  end
end
