class AddInventories < ActiveRecord::Migration
  def change
    create_table :inventories do |t|
      t.references :location, index: true, foreign_key: true

      t.integer  :inventory_type, null: false
      t.string   :inventory_name, null: false
      t.string   :sku,            null: false
      t.integer  :quantity,       null: false
      t.integer  :created_by,     null: false
      t.integer  :modified_by,    null: false
      t.datetime :created_at,     null: false
      t.datetime :updated_at,     null: false
    end
  end
end
