class CreateWarehouses < ActiveRecord::Migration
  def change
    create_table :warehouses do |t|
      t.references :client, index: true, foreign_key: true
      t.string :code, null: false
      t.string :name, null: false
      t.integer :gps_latitude_ref
      t.decimal :gps_latitude_point
      t.integer :gps_longitude_ref
      t.decimal :gps_longitude_point
      t.string :address1, null: false
      t.string :address2
      t.string :address3
      t.string :address4
      t.string :city, null: false
      t.string :state_name, null: false
      t.string :state_code
      t.string :full_zip_code, null: false
      t.string :country_name, null: false
      t.string :country_code
      t.integer :created_by, null: false
      t.integer :modified_by, null: false


      t.timestamps null: false
    end
  end
end
