class AddInventoryHistories < ActiveRecord::Migration
  def change
    create_table :inventory_histories do |t|
      t.integer  :inventory_action,   null: false
      t.integer  :user_id
      t.string   :sku,                null: false
      t.integer  :created_by,         null: false
      t.datetime :created_at,         null: false
      t.datetime :updated_at,         null: false
      t.string   :inventory_type,     null: false
      t.integer  :quantity,           null: false
      t.integer  :location_id,        null: false
      t.integer  :warehouse_order_id
    end
  end
end
