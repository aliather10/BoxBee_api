class CreateAddressNoteTemplates < ActiveRecord::Migration
  def change
    create_table :address_note_templates do |t|
      t.text :custom_note
      t.integer :created_by, null: false
      t.integer :modified_by, null: false

      t.timestamps null: false
    end
  end
end
