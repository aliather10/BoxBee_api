class AddLicenseFeeToCompanies < ActiveRecord::Migration
  def change
    add_column :companies, :license_fee_percentage, :decimal, default: 0.0
  end
end
