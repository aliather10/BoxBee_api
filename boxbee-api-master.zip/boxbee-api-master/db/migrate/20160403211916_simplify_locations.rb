class SimplifyLocations < ActiveRecord::Migration
  def change
    drop_table :location_aliases
    remove_column :locations, :area, :string
    remove_column :locations, :aisle, :string
    remove_column :locations, :row, :string
    remove_column :locations, :section, :string
    remove_column :locations, :level, :string
    add_column :locations, :name, :string
  end
end
