class AdjustMiscFieldNamesAndReferences < ActiveRecord::Migration
  def change
    remove_reference :payloads, :appointment
    remove_column :appointments, :user_id
    add_reference :plans, :item_type, index: true
    # remove_reference :plans, :user
    add_reference :plans, :customer, index: true
    add_column :companies, :country, :integer, null: false
    remove_column :companies, :stripe_account_id
    add_column :companies, :stripe_account_id, :string
    remove_column :companies, :code
    drop_table :failed_billings
    remove_column :inventory_histories, :user_id
    add_column :inventory_histories, :customer_id, :integer
    remove_column :inventory_histories, :warehouse_order_id
    add_column :inventory_histories, :warehouse_task_id, :integer
    remove_column :route_histories, :history_key
    remove_column :route_histories, :history_value
    add_column :route_histories, :route_id, :integer
    remove_column :customers, :stripe_account_id
    add_column :customers, :stripe_customer_id, :string
    remove_column :warehouse_tasks, :order_type
    add_column :warehouse_tasks, :task_type,  :integer
  end
end
