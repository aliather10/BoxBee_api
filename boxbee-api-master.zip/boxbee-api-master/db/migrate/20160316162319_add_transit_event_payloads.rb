class AddTransitEventPayloads < ActiveRecord::Migration
  def change
    create_table :transit_event_payloads do |t|
      t.belongs_to :transit_event, index: true
      t.belongs_to :booking_action_detail, index: true

      t.string   :warehouse_id
      t.string   :group_name
      t.string   :active_plan_name,                         null: false
      t.string   :payload_name,                             null: false
      t.integer  :payload_status,                           null: false
      t.string   :staging_location_num
      t.boolean  :added_on_spot,            default: false, null: false
      t.integer  :created_by,                               null: false
      t.integer  :modified_by,                              null: false
      t.datetime :created_at,                               null: false
      t.datetime :updated_at,                               null: false
      t.string   :payload_value
    end
  end
end
