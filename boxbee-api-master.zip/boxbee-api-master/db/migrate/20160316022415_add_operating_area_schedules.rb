class AddOperatingAreaSchedules < ActiveRecord::Migration
  def change
    create_table :operating_area_schedules do |t|
      t.references :operating_area, index: true, foreign_key: true
      
      t.string   :name,                                  null: false
      t.integer  :day_of_week,                           null: false
      t.decimal  :allowed_break_hours,   default: 0.0
      t.integer  :max_break_count,       default: 0
      t.integer  :duration_value_mins
      t.integer  :max_bookings_per_slot, default: 1,     null: false
      t.date     :schedule_start_date
      t.date     :schedule_end_date
      t.boolean  :active,                default: false
      t.integer  :created_by,                            null: false
      t.integer  :modified_by,                           null: false
      t.datetime :created_at,                            null: false
      t.datetime :updated_at,                            null: false
      t.integer  :start_time,                            null: false
      t.integer  :end_time,                              null: false
    end
  end
end
