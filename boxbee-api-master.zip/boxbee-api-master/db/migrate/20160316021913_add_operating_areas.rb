class AddOperatingAreas < ActiveRecord::Migration
  def change
    create_table :operating_areas do |t|
      t.references :client, index: true, foreign_key: true
      
      t.string   :name,                        null: false
      t.boolean  :active,      default: false
      t.integer  :created_by,                  null: false
      t.integer  :modified_by,                 null: false
      t.datetime :created_at,                  null: false
      t.datetime :updated_at,                  null: false
      t.string   :time_zone
    end
  end
end
