class AddJobStates < ActiveRecord::Migration
  def change
    create_table :job_states do |t|
      t.integer  :job_type,                         null: false
      t.text     :completed_methods, default: [],                array: true
      t.text     :arguments,         default: [],                array: true
      t.boolean  :is_dry_run,        default: true
      t.datetime :created_at,                       null: false
      t.datetime :updated_at,                       null: false
    end
  end
end
