class RemoveGpsReferencesNsew < ActiveRecord::Migration
  def change
    remove_column :addresses, :gps_latitude_ref, :integer
    remove_column :addresses, :gps_longitude_ref, :integer
  end
end
