class AddUniquenessIndexToProductServiceAreas < ActiveRecord::Migration
  def change
    #First remove duplicates
    Product.all.each do |product|
      service_areas = product.service_areas
      duplicate_sas = service_areas.select{|sa| service_areas.map(&:id).count(sa.id) > 1}
      while duplicate_sas.length > 1
        puts "duplicate_sas #{duplicate_sas.inspect}"
        service_areas.delete(duplicate_sas.last)
        duplicate_sas = service_areas.select{|sa| service_areas.map(&:id).count(sa.id) > 1}
      end
    end
    #Then add validation
    add_index :products_service_areas, [:product_id, :service_area_id], unique: true
  end
end
