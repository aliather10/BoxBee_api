class AddAboutUsImageToProducts < ActiveRecord::Migration
  def change
    add_column :products, :about_us_image, :string, null: false
  end
end
