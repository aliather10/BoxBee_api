class AddDefaultMinimumTermToProducts < ActiveRecord::Migration
  def change
    add_column :products, :default_minimum_term, :integer, default: 0
    add_column :plans, :minimum_term, :integer
  end
end
