class AddPlanFormFactorAssets < ActiveRecord::Migration
  def change
    create_table :plan_form_factor_assets do |t|
      t.references :plan_form_factor, index: true, foreign_key: true
      t.integer  :asset_type,          null: false
      t.string   :asset_value,         null: false
      t.integer  :sort_order,          null: false
      t.integer  :created_by,          null: false
      t.integer  :modified_by,         null: false
      t.datetime :created_at,          null: false
      t.datetime :updated_at,          null: false
    end
  end
end
