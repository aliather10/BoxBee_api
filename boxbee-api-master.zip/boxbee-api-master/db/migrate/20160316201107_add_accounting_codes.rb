class AddAccountingCodes < ActiveRecord::Migration
  def change
    create_table :accounting_codes do |t|
      t.references  :product, index: true, foreign_key: true
      t.string   :name,             null: false
      t.integer  :code,             null: false
      t.string   :description
      t.integer  :created_by,       null: false
      t.integer  :modified_by,      null: false
      t.datetime :created_at,       null: false
      t.datetime :updated_at,       null: false
    end
  end
end
