class ChangeTaxesStructure < ActiveRecord::Migration
  def change
    remove_column :taxes, :zip
    add_column :taxes, :zips, :string, array: true, default: []
    remove_column :taxes, :accounting_codes
  end
end
