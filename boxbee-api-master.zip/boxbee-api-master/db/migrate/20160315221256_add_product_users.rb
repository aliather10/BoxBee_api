class AddProductUsers < ActiveRecord::Migration
  def change
    create_table :product_users do |t|
      t.belongs_to :product, index: true
      t.belongs_to :user, index: true

      t.string   :optional_business_name
      t.integer  :preferred_address_id,       null: false
      t.integer  :last_booking_address_id
      t.integer  :primary_communication_id
      t.integer  :secondary_communication_id
      t.integer  :standing,                   null: false
      t.string   :standing_reason
      t.integer  :created_by,                 null: false
      t.integer  :modified_by,                null: false
      t.timestamps                            null: false
      t.datetime :updated_at,                 null: false
    end
  end
end
