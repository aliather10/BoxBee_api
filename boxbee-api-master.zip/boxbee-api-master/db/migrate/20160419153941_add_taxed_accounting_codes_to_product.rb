class AddTaxedAccountingCodesToProduct < ActiveRecord::Migration
  def change
    add_column :products, :taxed_accounting_codes, :string, array: true, default: []
  end
end
