class ReplaceReportsFieldsForCarrierwaveFromPaperClip < ActiveRecord::Migration
  def change
    remove_column :reports, :csv_file_file_name
    remove_column :reports, :csv_file_content_type
    remove_column :reports, :csv_file_file_size
    remove_column :reports, :csv_file_updated_at
    add_column :reports, :csv_file, :string
  end
end
