class AddActivePlan < ActiveRecord::Migration
  def change
    create_table :active_plans do |t|
      t.belongs_to  :plan, index: true
      t.belongs_to  :user, index: true
      t.decimal  :length
      t.decimal  :width
      t.decimal  :height
      t.decimal  :weight
      t.boolean  :active,      null: false
      t.integer  :created_by,  null: false
      t.integer  :modified_by, null: false
      t.datetime :created_at,  null: false
      t.datetime :updated_at,  null: false
    end
  end
end
