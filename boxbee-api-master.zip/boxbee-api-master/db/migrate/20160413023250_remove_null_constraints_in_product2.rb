class RemoveNullConstraintsInProduct2 < ActiveRecord::Migration
  def change
    change_column :products, :about_us_image, :string, null: true
  end
end
