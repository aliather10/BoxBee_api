class AddRouteTransitHistories < ActiveRecord::Migration
  def change
    create_table :route_transit_histories do |t|
      t.integer  :history_key,     null: false
      t.integer  :history_value,   null: false
      t.string   :previous_status
      t.string   :current_status,  null: false
      t.integer  :created_by,      null: false
      t.integer  :modified_by,     null: false
      t.datetime :created_at,      null: false
      t.datetime :updated_at,      null: false
    end
  end
end
