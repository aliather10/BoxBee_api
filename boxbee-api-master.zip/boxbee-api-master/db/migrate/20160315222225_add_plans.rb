class AddPlans < ActiveRecord::Migration
  def change
    create_table :plans do |t|
      t.string   :name,                       null: false
      t.references :product, index: true, foreign_key: true
      t.decimal  :length
      t.decimal  :width
      t.decimal  :height
      t.decimal  :weight
      t.boolean  :active,      default: true, null: false
      t.integer  :created_by,                 null: false
      t.integer  :modified_by,                null: false
      t.datetime :created_at,                 null: false
      t.datetime :updated_at,                 null: false
      t.string   :description,                null: false
    end
  end
end
