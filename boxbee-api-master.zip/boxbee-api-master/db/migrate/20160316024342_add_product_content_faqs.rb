class AddProductContentFaqs < ActiveRecord::Migration
  def change
    create_table :product_content_faqs do |t|
      t.references :product, index: true, foreign_key: true
      t.string   :question,   null: false
      t.text     :answer,     null: false
      t.datetime :created_at, null: false
      t.datetime :updated_at, null: false
    end
  end
end
