class AddRoutes < ActiveRecord::Migration
  def change
    create_table :routes do |t|
      t.references :client, index: true, foreign_key: true
      
      t.string   :name,        null: false
      t.integer  :driver_id
      t.integer  :vehicle_id
      t.integer  :status,      null: false
      t.integer  :created_by,  null: false
      t.integer  :modified_by, null: false
      t.datetime :created_at,  null: false
      t.datetime :updated_at,  null: false
    end
  end
end
