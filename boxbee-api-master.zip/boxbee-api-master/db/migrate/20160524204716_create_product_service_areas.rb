class CreateProductServiceAreas < ActiveRecord::Migration
  def change
    create_table :product_service_areas do |t|
      t.belongs_to :product, index: true
      t.belongs_to :service_area, index: true
      t.timestamps null: false
    end
    Product.all.each do |product|
      product.service_areas.each do |service_area|
        psa = ProductServiceArea.create!(product: product, service_area: service_area)
      end
    end
    drop_table :products_service_areas
  end
end

#### Check to see if we can add service areas to products now
## Rewrite validations on PSA model to check for uniqueness
