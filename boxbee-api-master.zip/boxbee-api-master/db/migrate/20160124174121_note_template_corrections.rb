class NoteTemplateCorrections < ActiveRecord::Migration
  def change
    remove_column :note_templates, :type, :string
    add_column :note_templates, :note, :text, null: false
    remove_column :clients, :client_name, :string
    add_column :clients, :name, :string
    add_column :clients, :code, :string, null: false
  end
end
