# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20160524204716) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "accounting_codes", force: :cascade do |t|
    t.integer  "product_id"
    t.string   "name",        null: false
    t.integer  "code",        null: false
    t.string   "description"
    t.integer  "created_by",  null: false
    t.integer  "modified_by", null: false
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  add_index "accounting_codes", ["product_id"], name: "index_accounting_codes_on_product_id", using: :btree

  create_table "address_note_options", force: :cascade do |t|
    t.boolean  "active",      default: true, null: false
    t.integer  "created_by",                 null: false
    t.integer  "modified_by",                null: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.text     "note",                       null: false
    t.integer  "company_id"
  end

  add_index "address_note_options", ["company_id"], name: "index_address_note_options_on_company_id", using: :btree

  create_table "address_notes", force: :cascade do |t|
    t.integer  "created_by",             null: false
    t.integer  "modified_by",            null: false
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "address_id"
    t.string   "note"
    t.integer  "address_note_option_id"
  end

  add_index "address_notes", ["address_id"], name: "index_address_notes_on_address_id", using: :btree
  add_index "address_notes", ["address_note_option_id"], name: "index_address_notes_on_address_note_option_id", using: :btree

  create_table "addresses", force: :cascade do |t|
    t.string   "alt_business_name"
    t.decimal  "gps_latitude_point"
    t.decimal  "gps_longitude_point"
    t.string   "address1",                            null: false
    t.string   "address2"
    t.string   "address3"
    t.string   "address4"
    t.string   "city",                                null: false
    t.string   "state_name",                          null: false
    t.string   "state_code"
    t.string   "country_name",                        null: false
    t.string   "country_code"
    t.boolean  "verfied",             default: false, null: false
    t.boolean  "billing_address",     default: false, null: false
    t.integer  "created_by",                          null: false
    t.integer  "modified_by",                         null: false
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.string   "display_name"
    t.string   "zip_code"
    t.integer  "addressable_id"
    t.string   "addressable_type"
  end

  add_index "addresses", ["addressable_type", "addressable_id"], name: "index_addresses_on_addressable_type_and_addressable_id", using: :btree

  create_table "appointment_cutoffs", force: :cascade do |t|
    t.integer  "product_id"
    t.boolean  "active",      default: true, null: false
    t.integer  "created_by",                 null: false
    t.integer  "modified_by",                null: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "cutoff_type"
    t.integer  "lead_time"
  end

  add_index "appointment_cutoffs", ["product_id"], name: "index_appointment_cutoffs_on_product_id", using: :btree

  create_table "appointment_details", force: :cascade do |t|
    t.integer  "transit_type",     null: false
    t.integer  "request_type",     null: false
    t.integer  "created_by",       null: false
    t.integer  "modified_by",      null: false
    t.datetime "created_at",       null: false
    t.datetime "updated_at",       null: false
    t.integer  "appointment_id"
    t.integer  "customer_item_id"
  end

  add_index "appointment_details", ["appointment_id"], name: "index_appointment_details_on_appointment_id", using: :btree
  add_index "appointment_details", ["customer_item_id"], name: "index_appointment_details_on_customer_item_id", using: :btree

  create_table "appointment_notes", force: :cascade do |t|
    t.string   "note",                           null: false
    t.integer  "created_by",                     null: false
    t.integer  "modified_by",                    null: false
    t.datetime "created_at",                     null: false
    t.datetime "updated_at",                     null: false
    t.integer  "appointment_id"
    t.boolean  "internal",       default: false
  end

  add_index "appointment_notes", ["appointment_id"], name: "index_appointment_notes_on_appointment_id", using: :btree

  create_table "appointments", force: :cascade do |t|
    t.string   "preferred_phone",        null: false
    t.string   "preferred_email",        null: false
    t.integer  "status",                 null: false
    t.datetime "window_start_datetime",  null: false
    t.datetime "window_end_datetime",    null: false
    t.datetime "canceled_timestamp"
    t.integer  "created_by",             null: false
    t.integer  "modified_by",            null: false
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "address_id"
    t.datetime "event_start_time"
    t.datetime "event_end_time"
    t.integer  "route_sort_order"
    t.string   "approved_signature_url"
    t.integer  "route_id"
    t.integer  "customer_id"
  end

  add_index "appointments", ["customer_id"], name: "index_appointments_on_customer_id", using: :btree
  add_index "appointments", ["route_id"], name: "index_appointments_on_route_id", using: :btree

  create_table "assets", force: :cascade do |t|
    t.integer  "asset_type",       null: false
    t.string   "asset_value",      null: false
    t.integer  "sort_order",       null: false
    t.integer  "created_by",       null: false
    t.integer  "modified_by",      null: false
    t.datetime "created_at",       null: false
    t.datetime "updated_at",       null: false
    t.integer  "customer_item_id"
  end

  add_index "assets", ["customer_item_id"], name: "index_assets_on_customer_item_id", using: :btree

  create_table "barcodes", force: :cascade do |t|
    t.string   "code",       null: false
    t.integer  "created_by", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "company_id"
  end

  add_index "barcodes", ["company_id"], name: "index_barcodes_on_company_id", using: :btree

  create_table "companies", force: :cascade do |t|
    t.string   "contact_name",                         null: false
    t.string   "contact_number",                       null: false
    t.integer  "created_by",                           null: false
    t.integer  "modified_by",                          null: false
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.string   "token"
    t.string   "name"
    t.string   "logo"
    t.string   "contact_email"
    t.integer  "country",                              null: false
    t.string   "stripe_account_id"
    t.string   "custom_admin_url"
    t.decimal  "license_fee_percentage", default: 0.0
  end

  create_table "company_details", force: :cascade do |t|
    t.integer  "company_id"
    t.string   "ssn"
    t.string   "dob"
    t.string   "government_id"
    t.integer  "entity_type"
    t.string   "entity_name"
    t.string   "address1"
    t.string   "address2"
    t.string   "address3"
    t.string   "city"
    t.string   "state_name"
    t.integer  "zip_code"
    t.integer  "currency"
    t.string   "ein"
    t.string   "bank_routing_no"
    t.string   "bank_account_no"
    t.datetime "created_at",                                      null: false
    t.datetime "updated_at",                                      null: false
    t.boolean  "accepted_terms"
    t.string   "accepted_terms_ip"
    t.string   "country_name"
    t.boolean  "requested_invite",                default: false
    t.boolean  "currently_offer_storage"
    t.boolean  "currently_offer_pickup_delivery"
  end

  add_index "company_details", ["company_id"], name: "index_company_details_on_company_id", using: :btree

  create_table "contact_details", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "mode_key",                   null: false
    t.string   "mode_value",                 null: false
    t.boolean  "active",      default: true, null: false
    t.integer  "created_by",                 null: false
    t.integer  "modified_by",                null: false
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
  end

  add_index "contact_details", ["user_id"], name: "index_contact_details_on_user_id", using: :btree

  create_table "customer_fees", force: :cascade do |t|
    t.integer  "empty_delivery_price",  default: 0
    t.integer  "packed_pickup_price",   default: 0
    t.integer  "packed_delivery_price", default: 0
    t.integer  "empty_pickup_price",    default: 0
    t.integer  "created_by",                        null: false
    t.integer  "modified_by",                       null: false
    t.datetime "created_at",                        null: false
    t.datetime "updated_at",                        null: false
    t.integer  "appointment_id"
    t.integer  "customer_id"
  end

  add_index "customer_fees", ["appointment_id"], name: "index_customer_fees_on_appointment_id", using: :btree
  add_index "customer_fees", ["customer_id"], name: "index_customer_fees_on_customer_id", using: :btree

  create_table "customer_item_histories", force: :cascade do |t|
    t.string   "previous_status"
    t.string   "current_status",         null: false
    t.integer  "created_by",             null: false
    t.integer  "modified_by",            null: false
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
    t.integer  "appointment_id"
    t.integer  "customer_item_id"
    t.string   "current_filled_status"
    t.string   "previous_filled_status"
  end

  add_index "customer_item_histories", ["customer_item_id"], name: "index_customer_item_histories_on_customer_item_id", using: :btree

  create_table "customer_items", force: :cascade do |t|
    t.string   "name"
    t.string   "description"
    t.integer  "status",          null: false
    t.integer  "created_by",      null: false
    t.integer  "modified_by",     null: false
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.integer  "subscription_id"
    t.integer  "item_type_id"
    t.string   "barcode"
  end

  add_index "customer_items", ["item_type_id"], name: "index_customer_items_on_item_type_id", using: :btree
  add_index "customer_items", ["subscription_id"], name: "index_customer_items_on_subscription_id", using: :btree

  create_table "customers", force: :cascade do |t|
    t.integer  "product_id"
    t.integer  "user_id"
    t.string   "optional_business_name"
    t.integer  "preferred_address_id",        null: false
    t.integer  "standing",                    null: false
    t.integer  "created_by",                  null: false
    t.integer  "modified_by",                 null: false
    t.datetime "created_at",                  null: false
    t.datetime "updated_at",                  null: false
    t.string   "stripe_customer_id"
    t.integer  "last_appointment_address_id"
  end

  add_index "customers", ["product_id"], name: "index_customers_on_product_id", using: :btree
  add_index "customers", ["user_id"], name: "index_customers_on_user_id", using: :btree

  create_table "employee_invitations", force: :cascade do |t|
    t.string   "email",       null: false
    t.text     "roles",       null: false, array: true
    t.integer  "created_by",  null: false
    t.integer  "modified_by", null: false
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.string   "token"
    t.integer  "company_id"
  end

  add_index "employee_invitations", ["company_id"], name: "index_employee_invitations_on_company_id", using: :btree

  create_table "faqs", force: :cascade do |t|
    t.integer  "product_id"
    t.string   "question",   null: false
    t.text     "answer",     null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  add_index "faqs", ["product_id"], name: "index_faqs_on_product_id", using: :btree

  create_table "holidays", force: :cascade do |t|
    t.string   "name",        null: false
    t.date     "date",        null: false
    t.date     "end_date"
    t.integer  "created_by",  null: false
    t.integer  "modified_by", null: false
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "company_id"
  end

  add_index "holidays", ["company_id"], name: "index_holidays_on_company_id", using: :btree

  create_table "inventories", force: :cascade do |t|
    t.integer  "location_id"
    t.integer  "inventory_type", null: false
    t.string   "inventory_name", null: false
    t.string   "sku",            null: false
    t.integer  "quantity",       null: false
    t.integer  "created_by",     null: false
    t.integer  "modified_by",    null: false
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
  end

  add_index "inventories", ["location_id"], name: "index_inventories_on_location_id", using: :btree

  create_table "inventory_histories", force: :cascade do |t|
    t.integer  "inventory_action",  null: false
    t.string   "sku",               null: false
    t.integer  "created_by",        null: false
    t.datetime "created_at",        null: false
    t.datetime "updated_at",        null: false
    t.integer  "quantity",          null: false
    t.integer  "location_id",       null: false
    t.integer  "customer_id"
    t.integer  "warehouse_task_id"
    t.integer  "inventory_type",    null: false
  end

  create_table "item_types", force: :cascade do |t|
    t.string   "name",                                    null: false
    t.integer  "created_by",                              null: false
    t.integer  "modified_by",                             null: false
    t.datetime "created_at",                              null: false
    t.datetime "updated_at",                              null: false
    t.boolean  "requires_empty_pickup",                   null: false
    t.boolean  "requires_empty_delivery",                 null: false
    t.decimal  "length"
    t.decimal  "width"
    t.decimal  "height"
    t.decimal  "weight"
    t.integer  "company_id"
    t.integer  "appointment_max_qty"
    t.string   "image"
    t.boolean  "active",                  default: false
  end

  add_index "item_types", ["company_id"], name: "index_item_types_on_company_id", using: :btree

  create_table "job_states", force: :cascade do |t|
    t.integer  "job_type",                         null: false
    t.text     "completed_methods", default: [],                array: true
    t.text     "arguments",         default: [],                array: true
    t.boolean  "is_dry_run",        default: true
    t.datetime "created_at",                       null: false
    t.datetime "updated_at",                       null: false
  end

  create_table "locations", force: :cascade do |t|
    t.integer  "warehouse_id"
    t.integer  "created_by",    null: false
    t.integer  "modified_by",   null: false
    t.datetime "created_at",    null: false
    t.datetime "updated_at",    null: false
    t.integer  "location_type", null: false
    t.string   "name"
  end

  add_index "locations", ["warehouse_id"], name: "index_locations_on_warehouse_id", using: :btree

  create_table "payloads", force: :cascade do |t|
    t.boolean  "added_on_spot",         default: false, null: false
    t.integer  "created_by",                            null: false
    t.integer  "modified_by",                           null: false
    t.datetime "created_at",                            null: false
    t.datetime "updated_at",                            null: false
    t.integer  "appointment_detail_id"
    t.integer  "staging_location_id"
    t.string   "name",                                  null: false
    t.integer  "status",                                null: false
    t.string   "sku"
    t.integer  "warehouse_id"
  end

  add_index "payloads", ["appointment_detail_id"], name: "index_payloads_on_appointment_detail_id", using: :btree

  create_table "plans", force: :cascade do |t|
    t.string   "name",                          null: false
    t.integer  "product_id"
    t.boolean  "active",         default: true, null: false
    t.integer  "created_by",                    null: false
    t.integer  "modified_by",                   null: false
    t.datetime "created_at",                    null: false
    t.datetime "updated_at",                    null: false
    t.string   "description"
    t.string   "image"
    t.integer  "price_per_plan", default: 0
    t.integer  "item_type_id"
    t.integer  "minimum_term"
  end

  add_index "plans", ["item_type_id"], name: "index_plans_on_item_type_id", using: :btree
  add_index "plans", ["product_id"], name: "index_plans_on_product_id", using: :btree

  create_table "product_service_areas", force: :cascade do |t|
    t.integer  "product_id"
    t.integer  "service_area_id"
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
  end

  add_index "product_service_areas", ["product_id"], name: "index_product_service_areas_on_product_id", using: :btree
  add_index "product_service_areas", ["service_area_id"], name: "index_product_service_areas_on_service_area_id", using: :btree

  create_table "products", force: :cascade do |t|
    t.string   "name",                                            null: false
    t.string   "description"
    t.string   "logo_image_url"
    t.string   "support_phone",                                   null: false
    t.string   "support_email",                                   null: false
    t.integer  "created_by",                                      null: false
    t.integer  "modified_by",                                     null: false
    t.string   "customer_portal_url"
    t.string   "default_customer_portal_url"
    t.string   "meta_tags"
    t.string   "theme"
    t.string   "hero_text"
    t.text     "description_text"
    t.string   "what_we_store"
    t.string   "how_it_works1"
    t.string   "how_it_works2"
    t.string   "how_it_works3"
    t.string   "our_plans"
    t.string   "closing_cta"
    t.string   "about_us_title"
    t.text     "about_us_body"
    t.string   "terms_title"
    t.text     "terms_body"
    t.string   "faq_title"
    t.string   "twitter_url"
    t.string   "facebook_url"
    t.string   "instagram_url"
    t.string   "pinterest_url"
    t.string   "yelp_url"
    t.datetime "created_at",                                      null: false
    t.datetime "updated_at",                                      null: false
    t.integer  "empty_delivery_price",              default: 0,   null: false
    t.integer  "packed_pickup_price",               default: 0,   null: false
    t.integer  "packed_delivery_price",             default: 0,   null: false
    t.integer  "empty_pickup_price",                default: 0,   null: false
    t.integer  "currency",                                        null: false
    t.integer  "company_id"
    t.string   "list_of_service_areas",                           null: false
    t.string   "about_us_image"
    t.decimal  "default_tax",                       default: 0.0
    t.integer  "status"
    t.integer  "default_minimum_term",              default: 0
    t.string   "taxed_accounting_codes",            default: [],               array: true
    t.text     "storage_terms"
    t.integer  "default_slot_duration"
    t.integer  "default_max_appointments_per_slot"
    t.integer  "default_daily_start"
    t.integer  "default_daily_end"
    t.string   "default_days_of_week",              default: [],               array: true
  end

  add_index "products", ["company_id"], name: "index_products_on_company_id", using: :btree

  create_table "reports", force: :cascade do |t|
    t.integer  "company_id",  null: false
    t.integer  "report_type", null: false
    t.string   "name"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "created_by"
    t.integer  "modified_by"
    t.string   "csv_file"
  end

  create_table "roles", force: :cascade do |t|
    t.string   "name"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "description"
    t.boolean  "internal"
  end

  add_index "roles", ["name", "resource_type", "resource_id"], name: "index_roles_on_name_and_resource_type_and_resource_id", using: :btree
  add_index "roles", ["name"], name: "index_roles_on_name", using: :btree

  create_table "route_histories", force: :cascade do |t|
    t.string   "previous_status"
    t.string   "current_status",  null: false
    t.integer  "created_by",      null: false
    t.integer  "modified_by",     null: false
    t.datetime "created_at",      null: false
    t.datetime "updated_at",      null: false
    t.integer  "route_id"
  end

  create_table "routes", force: :cascade do |t|
    t.string   "name",        null: false
    t.integer  "driver_id"
    t.integer  "vehicle_id"
    t.integer  "status",      null: false
    t.integer  "created_by",  null: false
    t.integer  "modified_by", null: false
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "company_id"
  end

  add_index "routes", ["company_id"], name: "index_routes_on_company_id", using: :btree

  create_table "schedule_adjustments", force: :cascade do |t|
    t.string   "name",                                          null: false
    t.date     "date",                                          null: false
    t.date     "end_date"
    t.integer  "new_duration_value_mins"
    t.boolean  "active",                        default: false
    t.integer  "created_by",                                    null: false
    t.integer  "modified_by",                                   null: false
    t.datetime "created_at",                                    null: false
    t.datetime "updated_at",                                    null: false
    t.integer  "service_area_schedule_id"
    t.integer  "new_max_appointments_per_slot"
  end

  add_index "schedule_adjustments", ["service_area_schedule_id"], name: "index_schedule_adjustments_on_service_area_schedule_id", using: :btree

  create_table "service_area_schedules", force: :cascade do |t|
    t.string   "name",                                      null: false
    t.integer  "day_of_week",                               null: false
    t.integer  "duration_value_mins"
    t.date     "schedule_start_date"
    t.date     "schedule_end_date"
    t.boolean  "active",                    default: false
    t.integer  "created_by",                                null: false
    t.integer  "modified_by",                               null: false
    t.datetime "created_at",                                null: false
    t.datetime "updated_at",                                null: false
    t.integer  "start_time",                                null: false
    t.integer  "end_time",                                  null: false
    t.integer  "service_area_id"
    t.integer  "max_appointments_per_slot"
  end

  add_index "service_area_schedules", ["service_area_id"], name: "index_service_area_schedules_on_service_area_id", using: :btree

  create_table "service_area_zips", force: :cascade do |t|
    t.integer  "service_area_id"
    t.string   "zip",                            null: false
    t.boolean  "active",          default: true
    t.integer  "created_by",                     null: false
    t.integer  "modified_by",                    null: false
    t.datetime "created_at",                     null: false
    t.datetime "updated_at",                     null: false
  end

  add_index "service_area_zips", ["service_area_id"], name: "index_service_area_zips_on_service_area_id", using: :btree

  create_table "service_areas", force: :cascade do |t|
    t.string   "name",                        null: false
    t.boolean  "active",      default: false
    t.integer  "created_by",                  null: false
    t.integer  "modified_by",                 null: false
    t.datetime "created_at",                  null: false
    t.datetime "updated_at",                  null: false
    t.string   "time_zone"
    t.integer  "company_id"
  end

  add_index "service_areas", ["company_id"], name: "index_service_areas_on_company_id", using: :btree

  create_table "slots", force: :cascade do |t|
    t.datetime "start_datetime"
    t.datetime "end_datetime"
    t.integer  "created_by",               null: false
    t.integer  "modified_by",              null: false
    t.datetime "created_at",               null: false
    t.datetime "updated_at",               null: false
    t.integer  "service_area_schedule_id"
  end

  add_index "slots", ["service_area_schedule_id"], name: "index_slots_on_service_area_schedule_id", using: :btree

  create_table "subscriptions", force: :cascade do |t|
    t.integer  "plan_id"
    t.decimal  "length"
    t.decimal  "width"
    t.decimal  "height"
    t.decimal  "weight"
    t.boolean  "active",         null: false
    t.integer  "created_by",     null: false
    t.integer  "modified_by",    null: false
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.string   "price_per_plan", null: false
    t.integer  "customer_id"
    t.integer  "quantity"
  end

  add_index "subscriptions", ["customer_id"], name: "index_subscriptions_on_customer_id", using: :btree
  add_index "subscriptions", ["plan_id"], name: "index_subscriptions_on_plan_id", using: :btree

  create_table "taxes", force: :cascade do |t|
    t.integer  "product_id"
    t.decimal  "tax_percent", default: 0.0, null: false
    t.integer  "created_by",                null: false
    t.integer  "modified_by",               null: false
    t.datetime "created_at",                null: false
    t.datetime "updated_at",                null: false
    t.string   "zips",        default: [],               array: true
  end

  add_index "taxes", ["product_id"], name: "index_taxes_on_product_id", using: :btree

  create_table "users", force: :cascade do |t|
    t.string   "first_name",                          null: false
    t.string   "last_name",                           null: false
    t.integer  "created_by",                          null: false
    t.integer  "modified_by",                         null: false
    t.datetime "created_at",                          null: false
    t.datetime "updated_at",                          null: false
    t.string   "email",                  default: "", null: false
    t.string   "encrypted_password",     default: "", null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0,  null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet     "current_sign_in_ip"
    t.inet     "last_sign_in_ip"
    t.string   "token"
    t.integer  "failed_attempts",        default: 0
    t.string   "unlock_token"
    t.datetime "locked_at"
    t.integer  "company_id"
  end

  add_index "users", ["company_id"], name: "index_users_on_company_id", using: :btree
  add_index "users", ["email"], name: "index_users_on_email", unique: true, using: :btree
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree

  create_table "users_roles", id: false, force: :cascade do |t|
    t.integer "user_id"
    t.integer "role_id"
  end

  add_index "users_roles", ["user_id", "role_id"], name: "index_users_roles_on_user_id_and_role_id", using: :btree

  create_table "vehicles", force: :cascade do |t|
    t.string   "name",                             null: false
    t.integer  "year"
    t.string   "make"
    t.string   "model"
    t.string   "vin_num"
    t.string   "license_plate_num"
    t.integer  "created_by",                       null: false
    t.integer  "modified_by",                      null: false
    t.datetime "created_at",                       null: false
    t.datetime "updated_at",                       null: false
    t.boolean  "active",            default: true
    t.integer  "company_id"
  end

  add_index "vehicles", ["company_id"], name: "index_vehicles_on_company_id", using: :btree

  create_table "warehouse_tasks", force: :cascade do |t|
    t.integer  "location_id"
    t.integer  "inventory_type", null: false
    t.string   "inventory_name", null: false
    t.string   "sku",            null: false
    t.integer  "quantity",       null: false
    t.integer  "route_id"
    t.integer  "payload_id"
    t.integer  "created_by",     null: false
    t.integer  "modified_by",    null: false
    t.string   "po_number"
    t.datetime "created_at",     null: false
    t.datetime "updated_at",     null: false
    t.integer  "status",         null: false
    t.integer  "customer_id"
    t.integer  "task_type"
  end

  add_index "warehouse_tasks", ["location_id"], name: "index_warehouse_tasks_on_location_id", using: :btree

  create_table "warehouses", force: :cascade do |t|
    t.string   "name",        null: false
    t.integer  "created_by",  null: false
    t.integer  "modified_by", null: false
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "company_id"
    t.integer  "address_id"
  end

  add_index "warehouses", ["company_id"], name: "index_warehouses_on_company_id", using: :btree

  add_foreign_key "accounting_codes", "products"
  add_foreign_key "address_note_options", "companies"
  add_foreign_key "appointment_cutoffs", "products"
  add_foreign_key "company_details", "companies"
  add_foreign_key "contact_details", "users"
  add_foreign_key "faqs", "products"
  add_foreign_key "inventories", "locations"
  add_foreign_key "locations", "warehouses"
  add_foreign_key "plans", "products"
  add_foreign_key "service_area_zips", "service_areas"
  add_foreign_key "taxes", "products"
  add_foreign_key "warehouse_tasks", "locations"
end
