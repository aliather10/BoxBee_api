###Notes###
# To move appointments to confirmed status and assign to route, schedule the AppointmentModificationCutoffJob (should run automatically)
# Daily new appointments and routes will be seeded on a daily seeding schedule "rake seeding:refresh"
# Warehouse tasks will be created once routes are created, on a daily seeding schedule "rake seeding:refresh"
#Constants/Initialize
Stripe.api_key = Figaro.env.STRIPE_PLATFORM_SECRET_DEMO_KEY

#System access
master_company = FactoryGirl.create(:company, name:'Boxbee', contact_name:'Boxbee',
  contact_number:'888-888-8888', created_by:1, modified_by:1)
  #Create master item_types for master_company
  Seeding::PROTOTYPE_ITEM_TYPES.each do |name|
    file = File.open "#{Rails.root.join('lib', 'assets', 'item_types')}/#{name.parameterize}.png"
    ItemType.create!(company: master_company, name: name, requires_empty_pickup: false, requires_empty_delivery: false,
                     active: true, image: file, created_by: 1, modified_by: 1)
  end
system_user = FactoryGirl.create(:user, company_id: master_company.id, first_name:'System', last_name:'User',
  email: 'it@boxbee.com', password: 'password',
  password_confirmation: 'password')
system_user.add_role :system; system_user.save;

#Everyone else
2.times do
  company = FactoryGirl.create(:company, license_fee_percentage: 5.0)
  company.replicate_item_types
  company_detail = FactoryGirl.create(:company_detail, company: company)
  address_note_option = FactoryGirl.create(:address_note_option, company: company)
  #Addresses
  addresses = Seeding::Mapbox.generate_addresses(10001)
  addresses.select!{|addr| addr[:address1] && addr[:city] && addr[:state_name] && addr[:zip_code]}
  puts "addresses zips #{addresses.map{|addr| addr[:zip_code]}}"
  #Warehouses
  addr_ct = 0
  warehouse = FactoryGirl.create(:warehouse, company: company)
  address = FactoryGirl.create(:address, gps_latitude_point: addresses[addr_ct][:latitude],
                               gps_longitude_point: addresses[addr_ct][:longitude], address1: addresses[addr_ct][:address1],
                               city: addresses[addr_ct][:city], state_name: addresses[addr_ct][:state_name], zip_code: addresses[addr_ct][:zip_code])
  address.addressable_id = warehouse.id
  address.addressable_type = "Warehouse"
  address.save!
  permanent_loc = nil
  2.times do
    permanent_loc = FactoryGirl.create(:location, warehouse: warehouse, location_type: :permanent)
    # FactoryGirl.create(:inventory, location: permanent_loc, inventory_type: :container, sku: 1, quantity: 49)
  end
  staging_loc = FactoryGirl.create(:location, warehouse: warehouse, location_type: :staging)
  cart_loc = FactoryGirl.create(:location, warehouse: warehouse, location_type: :cart)
  #Customers
  5.times do
    user = FactoryGirl.create(:user, company_id: company.id)
    user.add_role :customer; user.save!
    ##Create address for a customer
    puts "addresses #{addresses.inspect}"
    address = FactoryGirl.create(:address, gps_latitude_point: addresses[addr_ct][:latitude],
      gps_longitude_point: addresses[addr_ct][:longitude], address1: addresses[addr_ct][:address1],
      city: addresses[addr_ct][:city], state_name: addresses[addr_ct][:state_name], zip_code: addresses[addr_ct][:zip_code])
    address.addressable_id = user.id
    address.addressable_type = "User"
    address.save!
    ##Create communication for a customer
    contact_detail = FactoryGirl.create(:contact_detail, user: user)
    ##Address note
    an = FactoryGirl.create(:address_note, address: address,
      address_note_option: AddressNoteOption.where(note: 'custom').first)
    addr_ct += 1
  end
  #Employees
  ##CS
  user = FactoryGirl.create(:user, company_id: company.id)
  user.add_role :customer_service; user.save!
  ##Client admin
  user = FactoryGirl.create(:user, company_id: company.id)
  user.add_role :admin; user.save!
  ##Supervisor
  user = FactoryGirl.create(:user, company_id: company.id)
  user.add_role :supervisor; user.add_role :driver; user.add_role :warehouse_staff; user.save!
  ##Driver and warehouse_staff
  2.times do
    user = FactoryGirl.create(:user, company_id: company.id)
    user.add_role :driver; user.add_role :warehouse_staff; user.save!
  end

  #Transportation and Warehousing
  3.times do
    vehicle = FactoryGirl.create(:vehicle, company: company)
  end

  #Product
  product = FactoryGirl.create(:product, company: company)
  FactoryGirl.create(:tax, product: product, zips: Address.by_company(product.company_id).map(&:zip_code))

  #Service areas and service_area_schedules
  service_area_schedule = nil
  2.times do
    service_area = FactoryGirl.create(:service_area, company: company)
    addresses.uniq{|addr| addr[:zip_code]}.each do |address| #Filter addresses by unique zip code
      service_area_zip = FactoryGirl.create(:service_area_zip,
                                            service_area: service_area, zip: address[:zip_code])
    end
    service_area_schedule = FactoryGirl.create(:service_area_schedule, service_area: service_area)
  end

  #FAQs
  5.times {FactoryGirl.create(:faq, product: product)}

  #Holiday
  holiday = FactoryGirl.create(:holiday, company: company)
  #Service area schedule, service area zips, taxes
  product.save #Creates default service_area_schedules

  puts "all SASs #{ServiceAreaSchedule.all.inspect}"
  puts "service_area_schedule #{service_area_schedule.inspect}"
  #Schedule adjustment
  sa = FactoryGirl.create(:schedule_adjustment, service_area_schedule: service_area_schedule)

  #Plan and item_types for this product and company, respectively:
  Onboarding.new(company.item_types.map(&:id), product)
  product.plans.each do |plan|
    plan.price_per_plan = rand(2000..4000)
    plan.save!
  end

  #Cutoffs
  creation_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :creation)
  modification_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :modification)
  cancellation_cutoff = FactoryGirl.create(:appointment_cutoff, product: product, cutoff_type: :cancellation)

  #Create customers
  company.users.select{|u| u.has_role? :customer}.each do |user|
    customer = FactoryGirl.create(:customer, product: product, user_id: user.id)
    #Token
    token = Stripe::Token.create(
      :card => {
        :number => "4242424242424242",
        :exp_month => 2,
        :exp_year => 2017,
        :cvc => "314"
      },
    )['id']
    #Stripe Customer and card
    stripe_customer = Stripe::Customer.create({source: token}, {stripe_account: product.company.stripe_account_id})
    customer.stripe_customer_id = stripe_customer['id']
    customer.save!
    Customer.sync(company.id)
    card_id = stripe_customer['sources']['data'].first['id']
    card = stripe_customer.sources.retrieve(card_id)
    card.metadata = {product_id: product['id']}
    card.save
    #Create invoice items for customer
    amounts = []
    2.times do
      amount = Faker::Number.between(1000,4000)
      amounts << amount
      invoice_item = Stripe::InvoiceItem.create(
        {
          :customer => stripe_customer['id'],
          :amount => amount,
          :currency => "usd",
          :description => Faker::Lorem.sentence,
          :metadata => {
            :product_id => product.id,
            :tax => (amount * product.default_tax * 0.01).to_i,
            :accounting_code => AccountingCode.where("name LIKE ?", "Misc Revenue")
              .where(product: product).first.code
          }
        },
        {
          stripe_account: product.company.stripe_account_id
        }
      )
      InvoiceItem.sync(company.id)
    end
    #Create invoice for customer and pay it
    invoice = Stripe::Invoice.create(
      {
        customer: stripe_customer['id'],
        metadata: {product_id: product.id},
        description: Faker::Lorem.sentence,
        tax_percent: product.default_tax,
        application_fee: (company.license_fee_percentage * amounts.sum).to_i
      },
      {
        stripe_account: product.company.stripe_account_id
      }
    )
    invoice.pay
    Invoice.sync(company.id)
    Charge.sync(company.id)
    #Refund for customer
    invoice_item_ids = invoice['lines']['data'].map {|ii| ii['id']}
    puts "invoice_item_ids #{invoice_item_ids}"
    invoice_items = [invoice_item_ids.first].map do |ii_id|
      Stripe::InvoiceItem.retrieve(ii_id,
        {
          stripe_account: product.company.stripe_account_id
        }
      )
    end
    puts "seeds invoice_items #{invoice_items}"

    refunds = Refund.refunder(invoice_items, product.company_id, 'requested_by_customer')
    puts "refunds #{refunds}"
    Refund.sync(company.id)

    #Plans (created in Onboarding.new above)
    plan = product.plans.first
    #Appointments
    address = user.addresses.first
    3.times do
      # Create several appointments per customer
      appointment = FactoryGirl.create(:appointment, customer: customer, address_id: address.id)
      customer.last_appointment_address_id = address.id
      customer.save!
      appointment_note = FactoryGirl.create(:appointment_note, appointment: appointment)
      cart = [{"action": "new_plan", "quantity": 1, "request_type": "packed", "transit_type": "pickup", "plan_id": plan.id}]
      # Create customer_items, subscriptions, appointment_details etc. via Appointment.process_cart() simulation
      appointment.process_cart(cart.as_json, customer.user_id, customer.user.company_id)
      # Log customer transit fees
      customer_fee = FactoryGirl.create(
        :customer_fee,
        customer: customer,
        appointment: appointment,
        empty_delivery_price: product.empty_delivery_price,
        packed_pickup_price: product.packed_pickup_price,
        packed_delivery_price: product.packed_delivery_price,
        empty_pickup_price: product.empty_pickup_price
      )
    end
  end
end
#Sync all stripe data and clean up old data from previous seeds
Company.all.each do |company|
  StripeSync.cleaner('balance_transaction', company.id)
  StripeSync.cleaner('charge', company.id)
  StripeSync.cleaner('refund', company.id)
  StripeSync.cleaner('invoice', company.id)
  StripeSync.cleaner('invoice_item', company.id)
end
Resque.enqueue(SyncStripeObjectsJob)
#Create slots for all products
Slot.create_future_slots(2.months, true)
